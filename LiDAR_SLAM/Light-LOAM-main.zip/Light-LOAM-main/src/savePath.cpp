#include <ros/ros.h>
#include <nav_msgs/Odometry.h>

#include <fstream>

void path_save(nav_msgs::Odometry odomAftMapped) {
    // 保存轨迹，path_save是文件目录,txt文件提前建好,/home/xxx/xxx.txt,
    std::ofstream fs_pose("/home/jlurobot/桌面/test_slam/src/Light-LOAM-main/results/path.txt", std::ios::app);
    // std::ofstream fs_pose("/mnt/1t/dataset/JORD/results/Light-LOAM/path.txt", std::ios::app);
    if (!fs_pose.is_open())
        std::cout << "轨迹输出文件打开失败！" << std::endl;
	fs_pose.setf(std::ios::scientific, std::ios::floatfield);  // 设置浮点数以科学计数法（即指数形式）显示
	fs_pose.precision(9);  // 设置精度，保留几位小数
	
	static double timeStart = odomAftMapped.header.stamp.toSec();
	auto T1 =ros::Time().fromSec(timeStart) ;
	fs_pose << odomAftMapped.header.stamp << " "
        << -odomAftMapped.pose.pose.position.y << " "
        << odomAftMapped.pose.pose.position.z << " "
        << odomAftMapped.pose.pose.position.x << " "
        << odomAftMapped.pose.pose.orientation.x << " "
        << odomAftMapped.pose.pose.orientation.y << " "
        << odomAftMapped.pose.pose.orientation.z << " "
        << odomAftMapped.pose.pose.orientation.w << std::endl;
    std::cout << odomAftMapped.header.stamp -T1<< " "
        << -odomAftMapped.pose.pose.position.y << " "
        << odomAftMapped.pose.pose.position.z << " "
        << odomAftMapped.pose.pose.position.x << " "
        << odomAftMapped.pose.pose.orientation.x << " "
        << odomAftMapped.pose.pose.orientation.y << " "
        << odomAftMapped.pose.pose.orientation.z << " "
        << odomAftMapped.pose.pose.orientation.w << std::endl;
	fs_pose.close();
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "path_save");
    ros::NodeHandle nh;

    // 保存轨迹，a_loam直接订阅话题/aft_mapped_to_init。
    ros::Subscriber save_path = nh.subscribe<nav_msgs::Odometry>("/aft_mapped_to_init", 100, path_save);

    ros::spin();
}
