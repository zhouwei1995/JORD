# Pkg2.1 编译安装

省流：
```shell
sudo apt update
sudo apt install git build-essential libpcl-dev libjpeg9-dev cmake ninja
cd pkg2.1
mkdir build 
cd build
cmake -G Ninja ..
ninja
```

> 没试过的，不保证能成功。

## 预先依赖库

| 序号 | 库名 | 安装 |
| :--: | :--: | :--: |
|0| git | sudo apt install git |
|   1  |  ROS Neotic(Ubuntu 22.04)|
|2| g++, ... | sudo apt install build-essential |
|3| PCL | sudo apt install libpcl-dev |
|4| libjpeg| sudo apt install libjpeg9-dev |
|5| cmake | sudo apt install cmake |
|*6| ninja | sudo apt install ninja|

> ninja 可选，可以不装。


## 下载代码

```shell
git clone http://192.168.3.201/YuChen/pkg2.1.git
```

> 如果你没有连接小二楼的网络，请使用 git clone http://202.198.23.118:8080/YuChen/pkg2.1.git.

# 编译

我安装了Ninja:
```shell
cd pkg2.1
mkdir build 
cd build
cmake -G Ninja ..
ninja
```

我没有安装ninja:

```shell
cd pkg2.1
mkdir build 
cd build
cmake ..
make -j6
```

# pkg2 指令简介：
## 播放数据包
```shell
./pkg2 play < 数据包文件名 | http://开头的url > [options]
```
可以用的options:
|命令行|含义|例子| 备注 |
| :--: | :--: | :--: | :--: |
| --speed | 播放速度 | --speed 0.5 | 速度太快可能解码速度跟不上 |
| --point-type | 点云数据类型 | --point-type XYZIRT | 可用 XYZ， XYZI， XYZIRT， XYZRGB， 默认XYZI|
|--rename | 改变topic | --rename /u2102 /velodyne_points

其他选项可以运行 ./pkg2 play --help 查看。

## 查看数据包信息
```shell
./pkg2 info < 数据包文件名 >
```

> pkg2 数据包中，实际播放的topic值和tag是一样的，npos220s数据除外。npos220s的topic是 **tag**/imu 和 **tag**/gps, **tag**/fix. 例如 /npos220s/imu, /npos220s/gps, /npos220s/fix.
