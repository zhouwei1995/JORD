#ifndef _CRC_H_
#define _CRC_H_

#include <stdint.h>

//external functions
uint16_t Crc_CalculateCRC16(const uint8_t* Crc_DataPtr, uint32_t Crc_Length, uint16_t Crc_StartValue16, bool Crc_IsFirstCall);
uint32_t Crc_CalculateCRC32(const uint8_t *Crc_DataPtr, uint32_t Crc_Length, uint32_t Crc_StartValue32, bool Crc_IsFirstCall);

namespace jlurobot
{
    class crc16
    {
    public:
        crc16(uint16_t seed = 0);

        // change function name from mcrf4xx_upd to mcrf4xx
        uint16_t operator()(const uint8_t *data, const uint16_t datalen); // Equivalent to _crc_ccitt_update() in crc16.h from avr_libc

    private:
        uint16_t seed_;
    };

    // ================= 32-BIT CRC ===================

    class crc32
    {
    public:
        crc32(uint32_t seed = 0);

        // change function name from crc32_upd to crc32
        uint32_t operator()(const uint8_t *data, uint16_t len); // Call for subsequent calculations with previous seed

    private:
        uint32_t seed_;
    };

    inline uint32_t make_crc32(const uint8_t *data, const uint32_t datalen)
    {
        return Crc_CalculateCRC32(data, datalen, 0, true);
    }

    inline uint16_t make_crc16(const uint8_t *data, const uint32_t datalen)
    {
        return Crc_CalculateCRC16(data, datalen, 0, true);
    }
}
#endif