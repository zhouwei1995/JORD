#ifndef __pkg2_libcatkin
#error "This file should only be included while catkin available"
#endif

#ifndef __CATKIN_BASE_H__
#define __CATKIN_BASE_H__

#include <ros/ros.h>
#include <chrono>

void catkin_init_once() ;

ros::NodeHandle& catkin_node();

ros::Time from_std(const std::chrono::system_clock::time_point& tp);

const char* check_ros_topic(const char* in);

void do_sync(ros::Time clock_time);

#endif
