#ifndef __VELODYNE_BASE_H__
#define __VELODYNE_BASE_H__

#include <pkg2_type.h>

const type_id Velodyne16 = 0x00000001;
const type_id Velodyne32 = 0x00000002;

#endif