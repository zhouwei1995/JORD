#include <stdlib.h>
#include <limits>
#include <stdint.h>
#include <string>
#include <optional>
#include <iostream>
#include <vector>
#include <memory>
#include <functional>
#include <string.h>
#include <chrono>
#include <string_view>

#include <service/misc.h>

constexpr double M_PI = 3.14159265358979323846;

inline bool is_white_char(char c)
{
    if (c == ' ')
        return true;
    return false;
}
inline bool is_terminal(char c)
{
    return c == ',' || c == ';' || c == '\r' || c == '*' || c == 0;
}

template <typename X1, typename X2, typename V>
inline bool compare_ignore_v(const X1 &x1, const X2 &x2, V v)
{
    for (size_t p = 0; x1[p] != 0 && x2[p] != 0; p++)
    {
        if (x1[p] == v || x2[p] == v)
            continue;
        if (x1[p] != x2[p])
            return false;
    }
    return true;
}

template <typename T>
struct basic_parser_traits
{
    using value_type = T;
};

template <typename T>
struct floating_parser : basic_parser_traits<T>
{
    static inline T parse(const char *str)
    {
        return static_cast<T>(atof(str));
    }
};

struct string_parser : basic_parser_traits<std::string>
{
    static inline std::string parse(const char *str)
    {
        const char *endp = str;
        while (*endp != 0 && !is_terminal(*endp))
            endp++;
        return {str, endp};
    }
};

template <typename T>
struct parser_traits;
template <>
struct parser_traits<std::string> : string_parser
{
};

template <>
struct parser_traits<double> : floating_parser<double>
{
};

template <>
struct parser_traits<float> : floating_parser<float>
{
};

template <typename T, size_t R, bool negable>
struct integer_parser : basic_parser_traits<T>
{

    static inline T parse(const char *str)
    {
        while (is_white_char(*str))
            str++;
        T result = 0;
        T sg = 1;
        if constexpr (negable)
        {
            if (str[0] == '-')
            {
                sg = -1;
                str++;
            }
        }

        while (!is_terminal(*str))
        {
            auto v = get_int_char(str[0]);
            if (v >= R)
            {
                std::string s = "Invalid integer value: ";
                s += str;
                throw std::runtime_error(s);
            }
            result = result * R + v;
            str++;
        }
        return result * sg;
    }

private:
    static inline T get_int_char(char value)
    {
        if (value >= '0' && value <= '9')
            return value - '0';
        if (value >= 'A' && value <= 'Z')
            return value - 'A' + 10;
        if (value >= 'a' && value <= 'z')
            return value - 'a' + 10;
        return std::numeric_limits<int>::max();
    }
};

template <>
struct parser_traits<char> : basic_parser_traits<char>
{
    static inline char parse(const char *str) { return str[0]; }
};

template <>
struct parser_traits<int> : integer_parser<int, 10, true>
{
};

template <>
struct parser_traits<size_t> : integer_parser<size_t, 10, false>
{
};

using hex = integer_parser<size_t, 16, false>;
using dec = integer_parser<int, 10, true>;

template <>
struct parser_traits<hex> : hex
{
};

template <>
struct parser_traits<dec> : dec
{
};

template <typename T, T... V>
struct oneof : basic_parser_traits<T>
{
    static inline T parse(const char *str)
    {
        T val = parser_traits<T>::parse(str);
        T vs[] = {V...};
        for (T t : vs)
        {
            if (val == t)
                return t;
        }
        throw std::exception("Bad character in one of");
    }
};
template <typename T, T... V>
struct parser_traits<oneof<T, V...>> : oneof<T, V...>
{
};

template <typename T>
struct opt : basic_parser_traits<std::optional<typename parser_traits<T>::value_type>>
{
    static inline std::optional<typename parser_traits<T>::value_type> parse(const char *str)
    {
        if (str[0] == ',' || str[0] == '*' || str[0] == '\r')
            return std::optional<typename parser_traits<T>::value_type>();
        return parser_traits<T>::parse(str);
    }
};

template <typename T>
struct parser_traits<opt<T>> : opt<T>
{
};

struct caller_base
{
    virtual bool do_parse(const char *str) = 0;
    virtual const char *name_match(const char *str) = 0;
};

template <typename... Sequence>
struct talker_parser
{
    using value_type = std::tuple<typename parser_traits<Sequence>::value_type...>;
    template <typename T1, typename... Rev>
    struct Parse
    {
        template <typename _Fx, typename _Str>
        static inline auto _P(_Fx &&fx, _Str &&str)
        {
            if constexpr (sizeof...(Rev) > 0)
            {
                return std::tuple_cat(std::make_tuple(parser_traits<T1>::parse(std::forward<_Str>(str))), Parse<Rev...>::
                                                                                                              template _P<_Fx>(std::forward<_Fx>(fx), std::invoke(std::forward<_Fx>(fx), std::forward<_Str>(str))));
            }
            else
            {
                return std::make_tuple(parser_traits<T1>::parse(str));
            }
        }
    };

    template <typename _Fx, typename Str>
    static inline auto do_parse(_Fx &&fx, Str &&str)
    {
        return Parse<Sequence...>::_P(std::forward<_Fx>(fx), std::forward<Str>(str));
    }
};

template <typename Callback, typename... Talker>
struct talker : caller_base
{
    using value_type = std::tuple<typename Talker::value_type...>;

    template <typename Str>
    talker(Callback &&cb, Str &&str) : cb(cb), name(str) {}

    bool do_parse(const char *str) override
    {
        try
        {
            value_type val;
            Parse(str, val, std::make_index_sequence<sizeof...(Talker)>());
            std::apply(cb, val);
        }
        catch (std::exception &e)
        {
            log_error("%s", e.what());
            fflush(stdout);
        }
        return true;
    }

    const char *name_match(const char *str) override
    {
        const char *end = str + strlen(str);
        const char *result = std::find(str, end, name[0]);
        if (result == end)
            return nullptr;
        if (compare_ignore_v(result, name, '?'))
            return result;
        return nullptr;
    }

    std::string name;
    Callback cb;

private:
    template <size_t... Index>
    void Parse(const char *str, value_type &tpl, std::index_sequence<Index...>)
    {
        auto split_pos = [](const char *in)
        {
            while (*in != ',' && *in != '\r' && *in != '\n' && *in != '*' && *in != ';' && *in != 0)
                in++;
            return *in == ',' ? in + 1 : in;
        };
        auto split_object = [](const char *in)
        {
            while (*in != '\r' && *in != '\n' && *in != ';' && *in != 0)
                in++;
            return *in == ';' ? in + 1 : in;
        };

        const char *splits[sizeof...(Index)] = {split_pos(str)};

        for (size_t i = 1; i < sizeof...(Index); i++)
        {
            splits[i] = split_object(splits[i - 1]);
        }
        tpl = std::make_tuple(Talker::do_parse(split_pos, splits[Index])...);
    }
};

using talker_ptr = std::shared_ptr<caller_base>;
using parse_error_handler = std::function<void(const char *)>;
using unknown_statement_handler = std::function<void(const char *)>;

struct parser
{
    std::vector<talker_ptr> talkers;
    parse_error_handler peh = nullptr;
    unknown_statement_handler ush = nullptr;

    std::string t;
    int state = 0;

    template <typename Handler>
    void set_error_handler(Handler &&h)
    {
        peh = h;
    }

    template <typename Handler>
    void set_rest_handler(Handler &&h)
    {
        ush = h;
    }

    void add_talker(talker_ptr ptr)
    {
        talkers.push_back(ptr);
    }

    void statement(const char *str)
    {
        bool Handled = false;
        for (const auto &ptr : talkers)
        {
            if (ptr->name_match(str))
            {
                Handled = true;
                if (!ptr->do_parse(str) && peh != nullptr)
                {
                    peh(str);
                }
            }
        }
        if (!Handled && ush != nullptr)
        {
            ush(str);
        }
    }

    void parse(const char *data, size_t len)
    {
        split(std::string_view(data, len), [&](std::string_view t)
              {
                // std::cout << t.data() << std::endl;
                statement(t.data()); });
    }

private:
    static int findNext(std::string_view str, size_t startIdx)
    {
        for (size_t i = startIdx; i < str.size(); ++i)
        {
            if (str[i] == '#' || str[i] == '$')
                return i;
        }
        return -1;
    }

    template <typename CallBack>
    void split(std::string_view str, CallBack &&call)
    {
        int offset = 0;
        while (1)
        {
            int result = findNext(str, offset);

            if (state == 0)
            {
                if (result == -1)
                    return;
                state = 1;
                t.assign(1, str[result]);
                offset = result + 1;
            }
            else if (state == 1)
            {
                if (result == -1)
                {
                    t += str.substr(offset);
                    return;
                }
                else
                {
                    t.append(str.begin() + offset, str.begin() + result);
                    std::invoke(std::forward<CallBack>(call), t);
                    t.assign(1, str[result]);
                    offset = result + 1;
                }
            }
        }
    }
};

namespace talkers
{
    template <typename Callback>
    using gga_talker = talker<Callback, talker_parser<double /*utc timestamp*/, double /*lat*/, oneof<char, 'N', 'S'>, double /*lon*/, oneof<char, 'W', 'E'>,
                                                      dec /*GPS status*/, dec /*Satellites count*/, float /*HDOP*/, double /*alt*/, char, double, char, opt<double>, opt<hex>>>;

    template <typename _Cb>
    talker_ptr GGATalker(_Cb &&cb)
    {
        return std::make_shared<gga_talker<_Cb>>(std::forward<_Cb>(cb), "$??GGA");
    }
    // more to come
}

using npos_header_takler = talker_parser<opt<std::string> /* port */, dec /* seq */, float /* Idle Time */,
                                         opt<std::string> /* Time Status */, opt<dec> /* gpsWeek */,
                                         opt<double> /*gps seconds */, opt<hex>, opt<hex>, opt<dec>>;

using inspvax_body_talker = talker_parser<
    /* 0 */ std::string, std::string, double /* lat */, double /* lon */, double /* alt */, double /* ? */,
    /* 6 */ double /* speed_n */, double /*speed_e */, double /* speed_u */,
    /* 9 */ double /* roll */, double /* pitch */, double /* yaw */,
    /* 12 */ double /* lat_convsq */, double /* lon_convsq */, double /* alt_convsq */,
    /* 15 */ double /* speend_n_convsq */, double /* speed_e_convsq */, double /* speed_u_convsq */,
    /* 18 */ double /* roll_convsq */, double /* pitch_convsq */, double /* yaw_convsq */,
    hex, dec>;

template <typename Callback>
using inspvax_talker = talker<Callback, npos_header_takler, inspvax_body_talker>;

template <typename Callback>
talker_ptr INSPVAXTakler(Callback &&callback)
{
    return std::make_shared<inspvax_talker<Callback>>(std::forward<Callback>(callback), "#INSPVAXA");
}

using corrimudata_body_talker = talker_parser<
    /* 0 */ dec, double,
    /* 2 */ double, double, double,  // RPY
    /* 5 */ double, double, double>; // Acceleration

template <typename Callback>
using corrimudata_talker = talker<Callback, npos_header_takler, corrimudata_body_talker>;

template <typename _Callback>
talker_ptr CORRIMUDATATalker(_Callback &&callback)
{
    return std::make_shared<corrimudata_talker<_Callback>>(std::forward<_Callback>(callback), "#CORRIMUDATAA");
}

using rawimu_body_talker = talker_parser<
    /* 0 */ dec, double, hex,
    /* 3 */ double, double, double,  // Z -Y X acceleration
    /* 6 */ double, double, double>; // Z -Y X angular velocity

template <typename Callback>
using rawimu_talker = talker<Callback, npos_header_takler, rawimu_body_talker>;

template <typename Callback>
talker_ptr RAWIMUTakler(Callback &&callback)
{
    return std::make_shared<rawimu_talker<Callback>>(std::forward<Callback>(callback), "#RAWIMUA");
}

#include <pkg2_type.h>
#include "npos220s-base.h"

struct npos220s_translator : translator {
    parser p;

    npos220s_trvalue* value;
    bool print_value = false;

    npos220s_translator() : value(nullptr) {
        p.add_talker(INSPVAXTakler([&](auto& header, auto& msg) {
            this->talk_gps(header, msg);
        }));

        p.add_talker(RAWIMUTakler([&](auto& header, auto& msg) {
            this->talk_imu(header, msg);
        }));

        const char* config_text = config_get("print-npos220s", "false");
        if(strcmp(config_text, "true") == 0) {
            print_value = true;
        } else if(strcmp(config_text, "false") == 0) {
            print_value = false;
        } else {
            log_error("invalid config for print-npos220s %s, true or false only. setting to true.", config_text);
            print_value = true;
        }
    }

    virtual translated_value* translate(byte_buffer buff, time_point references_time) override {

        if(value == nullptr) {
            value = new npos220s_trvalue();
        }

        if(print_value) {
            log_debug("%.*s", buff.size(), buff.data());
        }

        p.parse((const char*)buff.data(), buff.size());

        npos220s_trvalue* ret = nullptr;

        if(!value->value.empty()) {
            ret = value;
            value = nullptr;
        }

        return ret;
    }

    time_point from_gps_time(uint32_t gps_week, double seconds) {
        auto seconds_ = (int)seconds + gps_week * 604800 - 18 + 315936000 + 8 * 3600;
        auto nsec_ = int((seconds - (int)seconds) * 1e9);
        return time_point(std::chrono::seconds(seconds_) + std::chrono::nanoseconds(nsec_));
    }

    template<typename H, typename M>
    void talk_imu(H& header, M& msg) {
        npos220s_value v;
        v.type = npos220s_value_type::RAWIMU;
        
        if (std::get<4>(header).value() == 0)
            return;

        v.time = from_gps_time(std::get<4>(header).value(), std::get<5>(header).value());
    
        v.rawimu.gx = -std::get<7>(msg) * (0.008 / 65536) / (200) * M_PI / 180.0f * 200;
        v.rawimu.gy = std::get<8>(msg) * (0.008 / 65536) / (200) * M_PI / 180.0f * 200;
        v.rawimu.gz = -std::get<6>(msg) * (0.008 / 65536) / (200) * M_PI / 180.0f * 200;

        v.rawimu.ax = -std::get<4>(msg) * (0.2 / 65536) * (9.80665 / 1000) / 200 * 200;
        v.rawimu.ay = std::get<5>(msg) * (0.2 / 65536) * (9.80665 / 1000) / 200 * 200;
        v.rawimu.az = -std::get<3>(msg) * (0.2 / 65536) * (9.80665 / 1000) / 200 * 200;
        
        value->value.push_back(v);
    }

    std::string arg1 , arg2;

    template<typename H, typename M>
    void talk_gps(H& header, M& msg) {
        npos220s_value v;

        if (std::get<4>(header).value() == 0)
            return;

        std::string t1 = std::get<0>(msg);
        std::string t2 = std::get<1>(msg);

        if(t1 != arg1 || t2 != arg2) {
            if(t1 != "INS_SOLUTION_GOOD")
                log_warning("INS_Status change to %s, %s", t1.c_str(), t2.c_str());
            else
                log_info("INS_Status change to %s, %s", t1.c_str(), t2.c_str());
            arg1 = t1;
            arg2 = t2;
        }

        v.type = npos220s_value_type::INSPVAXA;
        v.time = from_gps_time(std::get<4>(header).value(), std::get<5>(header).value());

        v.inspvaxa.latitude = std::get<2>(msg);
        v.inspvaxa.longitude = std::get<3>(msg);
        v.inspvaxa.altitude = std::get<4>(msg);

        v.inspvaxa.roll = std::get<9>(msg) * M_PI / 180;
        v.inspvaxa.pitch = -std::get<10>(msg) * M_PI / 180;
        v.inspvaxa.heading = -std::get<11>(msg) * M_PI / 180;

        v.inspvaxa.cov_x = std::get<12>(msg);
        v.inspvaxa.cov_y = std::get<13>(msg);
        v.inspvaxa.cov_z = std::get<14>(msg);

        value->value.push_back(v);
    }
};

struct npos220s_translator_factory : translator_factory {

    virtual translator* create_translator(const char* init_string) {
        return new npos220s_translator();
    }

    virtual bool check_init_string(const char* init_string) {
        return true;
    }

    virtual translator_descriptor get_descriptor() const {
        translator_descriptor d;
        d.name = "npos220s";
        d.source_type = npos220s;
        d.target_type = npos220s_tr;
        d.tag = "npos220s";

        return d;
    }
};

__attribute__((constructor))
static void npos220s_translator_init() {
    register_translated_type("npos220s_value", npos220s_tr);
    register_translator_factory(new npos220s_translator_factory());

    set_configable_flags({config_range::app_play, config_range::app_capture}, "print-npos220s",  "print npos220s value to console");
}
