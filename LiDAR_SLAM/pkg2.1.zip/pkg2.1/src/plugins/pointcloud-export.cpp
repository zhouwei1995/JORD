#include "point_types.h"
#include <pkg2_type.h>
#include <filesystem>
#include <service/misc.h>
#include <pcl/io/pcd_io.h>

template<typename point_type>
struct point_cloud_exporter : exporter {
    std::string export_suffix;
    size_t exported_id = 0;

    FILE* timestamp_file = nullptr;

    point_cloud_exporter(const char* export_dir, const char* init_string) {
        char buf[1024];
        snprintf(buf, sizeof(buf), "%s/%s", export_dir, init_string);
        std::error_code ec;
        if(!std::filesystem::create_directories(buf, ec)) {
            log_warning("point_cloud_exporter: failed to create directory %s: %s", buf, ec.message().c_str());
        }
        export_suffix = buf;

        snprintf(buf, sizeof(buf), "%s/%s_timestamp.txt", export_dir, init_string);
        timestamp_file = fopen(buf, "w");
        if(timestamp_file == nullptr) {
            log_warning("point_cloud_exporter: failed to open file %s: %s", buf, strerror(errno));
        }
    }
    
    virtual ~point_cloud_exporter() {
        if(timestamp_file != nullptr) {
            fclose(timestamp_file);
        }
    }

    virtual void export_data(translated_value* value) override {
        if(value->id != point_type_id<point_type>::value) {
            log_warning("point_cloud_exporter: wrong point type");
        }

        auto tr = static_cast<PointCloudTr<point_type>*>(value);

        char buffer[1024];
        snprintf(buffer, sizeof(buffer), "%s/%zu.pcd", export_suffix.c_str(), exported_id++);

        try {
            int result = pcl::io::savePCDFileBinary(buffer, tr->cloud);
            if(result != 0) {
                log_warning("point_cloud_exporter: failed to save file %s", buffer);
            } 
        } catch(std::exception& e) {
            log_error("point_cloud_exporter: failed to save file %s: %s", buffer, e.what());
        }

        if(timestamp_file != nullptr) {
            fprintf(timestamp_file, "%zu %lld\n", exported_id, tr->references_time.time_since_epoch().count());
        }
    }
};

template<typename point_type>
struct point_cloud_exporter_factory : exporter_factory {
    virtual ~point_cloud_exporter_factory() = default;

    virtual exporter* create_exporter(const char* export_dir, const char* init_string) override {
        return new point_cloud_exporter<point_type>(export_dir, init_string);
    }

    virtual exporter_descriptor get_descriptor() const override {
        return exporter_descriptor {
            .name = point_type_id<point_type>::name,
            .target_type = point_type_id<point_type>::value
        };
    }
};


__attribute__((constructor)) static void pointcloud_exporter_init() {
    register_exporter_factory(new point_cloud_exporter_factory<XYZ>());
    register_exporter_factory(new point_cloud_exporter_factory<XYZI>());
    register_exporter_factory(new point_cloud_exporter_factory<XYZRGB>());
    register_exporter_factory(new point_cloud_exporter_factory<XYZIRT>());
}
