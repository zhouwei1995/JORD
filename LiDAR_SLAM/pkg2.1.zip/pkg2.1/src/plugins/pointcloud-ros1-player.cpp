#ifdef __pkg2_libcatkin

#include "catkin-base.h"
#include "point_types.h"

#include <pcl_conversions/pcl_conversions.h>
#include <sensor_msgs/PointCloud2.h>

template<typename point_type>
struct point_cloud_player : player {

    ros::Publisher pub;

    point_cloud_player(const char* topic) {
        pub = catkin_node().advertise<sensor_msgs::PointCloud2>(check_ros_topic(topic), 1);
    }

    virtual void play(translated_value* type) override {
        if(type->id != point_type_id<point_type>::value) {
            return;
        }
        PointCloudTr<point_type>* cloud = static_cast<PointCloudTr<point_type>*>(type);

        sensor_msgs::PointCloud2 msg;
        pcl::toROSMsg(cloud->cloud, msg);
        
        msg.header.stamp = from_std(cloud->references_time);
        msg.header.frame_id = "velodyne";
        pub.publish(msg);

        do_sync(msg.header.stamp);
    }
};

template<typename point_type>
struct velodyne_player_factory : player_factory {
    virtual player* create_player(const char* init_string) {
        catkin_init_once();
        return new point_cloud_player<point_type>(init_string);
    }

    virtual bool check_init_string(const char* init_string) {
        return true;
    }

    virtual player_descriptor get_descriptor() const {
        player_descriptor desc;
        desc.name = "velodyne-ros1-player";
        desc.target_type = point_type_id<point_type>::value;
        return desc;
    }
};

__attribute__((constructor))
static void velodyne_player_init() {
    register_player_factory(new velodyne_player_factory<XYZ>());
    register_player_factory(new velodyne_player_factory<XYZI>());
    register_player_factory(new velodyne_player_factory<XYZRGB>());
    register_player_factory(new velodyne_player_factory<XYZIRT>());
}

#endif
