#ifdef __pkg2_libcatkin

#include "catkin-base.h"

#include <launch/subcommand.h>
#include <mutex>
#include <service/misc.h>

#include <rosgraph_msgs/Clock.h>

static ros::NodeHandle* node = nullptr;

struct sync_status_t {
    ros::Time last_sync_time;
    std::chrono::system_clock::time_point last_sync_point;
    bool has_synced = false;
    bool clock_flag = false;

    ros::Publisher pub_clock;
    std::chrono::system_clock::time_point last_clock_pub_time;
};

static sync_status_t sync_status;

static void publish_clock(struct sync_status_t* s) {
    if(!s->clock_flag || !s->has_synced)
        return;
    
    auto now = std::chrono::system_clock::now();
    if(now - s->last_clock_pub_time < std::chrono::milliseconds(100))
        return;
    
    rosgraph_msgs::Clock clock;
    std::chrono::nanoseconds dur = now - s->last_sync_point;

    ros::Time clock_time = s->last_sync_time;
    clock_time.nsec += dur.count() % 1000000000;

    if(clock_time.nsec >= 1000000000) {
        clock_time.sec += 1;
        clock_time.nsec -= 1000000000;
    }

    clock_time.sec += dur.count() / 1000000000;

    clock.clock = clock_time;
    s->pub_clock.publish(clock);
}

static void init_clock(ros::NodeHandle* node) {
    auto clock_flag = config_get("clock", "false");
    if(strcmp(clock_flag, "true") == 0) {
        
        log_info("clock flag 在试运行，我不知道如何验证他的正确性，慎用.");
        sync_status.pub_clock = node->advertise<rosgraph_msgs::Clock>("/clock", 1);
        sync_status.clock_flag = true;
    } else {
        sync_status.clock_flag = false;
    }

    
}

void catkin_init_once()
{
    static std::once_flag flag;
    std::call_once(flag, []() {
        std::map<std::string, std::string> remappings;

        add_spin_source([](int ms, void* arg) {
            auto start_time = std::chrono::system_clock::now();
            auto end_time = start_time + std::chrono::milliseconds(ms);

            do {

                publish_clock(&sync_status);

                ros::spinOnce();
                if(should_stop())
                    break;
            } while(std::chrono::system_clock::now() < end_time);
            
        }, nullptr);

        add_stop_source([](void* arg) {
            bool ok = ros::ok();
            if(!ok) {
                log_info("ros_ok return false!");
            }
            return !ok;
        }, nullptr);

        ros::init(remappings, "pkg2", ros::InitOption::AnonymousName);

        node = new ros::NodeHandle("~");
        init_clock(node);
    });
}

ros::NodeHandle& catkin_node() {
    catkin_init_once();
    return *node;
}

ros::Time from_std(const std::chrono::system_clock::time_point& tp) {
    auto dur_us = std::chrono::duration_cast<std::chrono::microseconds>(tp.time_since_epoch());

    return ros::Time(dur_us.count() / 1000000, dur_us.count() % 1000000 * 1000);
}

const char* check_ros_topic(const char* in) {
    static char topic_buf[128];

    if(in[0] == '/') {
        return in;
    } else {
        snprintf(topic_buf, sizeof(topic_buf), "/%s", in);
        return topic_buf;
    }
}

void do_sync(ros::Time clock_time)
{
    if(!sync_status.clock_flag)
        return;
    
    sync_status.has_synced = true;
    sync_status.last_sync_time = clock_time;
    sync_status.last_sync_point = std::chrono::system_clock::now();
}

__attribute__((constructor)) static void catkin_base_init() {
    set_configable_flags(config_range::app_play, "clock", "添加一个clock topic, 用于同步时间(ROS1 player)");
}

#endif
