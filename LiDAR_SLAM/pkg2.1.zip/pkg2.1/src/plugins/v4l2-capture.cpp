#include "v4l2-base.h"

#include <service/v4l2_video.h>

struct v4l2_capture : capture_source {
    jlurobot::v4l2_capture vcapture;

    ~v4l2_capture() override {
        vcapture.close_video();
    }

    virtual void start() override {
        vcapture.start_capturing();
    }

    virtual void stop() override {
        vcapture.stop_capturing();
    }

    virtual waitable_object get_waitable_object() {
        return vcapture.fd;
    } 

    virtual result_of<byte_buffer, std::string> capture() override {
        return ok(vcapture.read_image());
    }

    virtual type_id get_type() const override {
        return JPEG;
    }
};

struct v4l2_capture_factory : capture_factory {

    v4l2_capture_factory() {
        dev.name = "Video for Linux 2";
        dev.command_line = "v4l2";
        dev.command_line_description = "v4l2 init_string: device name(/dev/video0, ...)";
    }

    virtual result_of<capture_source*, std::string> create_capture_source(const char* init_string) override  {
        v4l2_capture* capture = new v4l2_capture();

        if(!capture->vcapture.open_video(init_string)) {
            delete capture;
            return fail("Failed to open video device");
        }

        if(!capture->vcapture.init_video()) {
            delete capture;
            return fail("Failed to init video device");
        }
        return ok(capture);
    }

    virtual bool check_init_string(const char* init_string) override {
        return true;
    }

    virtual const capture_device& get_device() const override {
        return dev;
    }
    capture_device dev;
};

__attribute__((constructor))
static void v4l2_capture_init() {
    register_type("jpeg", JPEG);

    register_capture_factory(new v4l2_capture_factory());
}
