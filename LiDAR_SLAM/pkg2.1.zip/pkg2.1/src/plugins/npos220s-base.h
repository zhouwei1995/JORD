#ifndef __NPOS220S_BASE_H__
#define __NPOS220S_BASE_H__

#include <pkg2_type.h>
#include <math.h>

constexpr type_id npos220s = 4;
constexpr type_id npos220s_tr = 55;

enum class npos220s_value_type {
    INSPVAXA, RAWIMU,
};

struct npos220s_inspvaxa {
    double latitude, longitude, altitude;
    float cov_x, cov_y, cov_z;
    float roll, pitch, heading;
};

struct npos220s_rawimu {
    float ax, ay, az;
    float gx, gy, gz;
};


struct npos220s_value {
    npos220s_value_type type;
    time_point time;
    
    union {
        npos220s_inspvaxa inspvaxa;
        npos220s_rawimu rawimu;
    };
};

struct npos220s_trvalue : translated_value {
    std::vector<npos220s_value> value;
    npos220s_trvalue() {
        id = npos220s_tr;
    }
};

struct origin_info {
    double ecef_x;
    double ecef_y;
    double ecef_z;
};

inline void wgs84_to_ecef(double latitude, double longitude, double altitude, double* x, double* y, double* z) {
    constexpr double a = 6378137.0;
    constexpr double b = 6356752.3142;
    constexpr double e2 = (a * a - b * b) / (a * a);

    latitude = latitude / 180.0 * M_PI;
    longitude = longitude / 180.0 * M_PI;

    double N = a / sqrt(1 - e2 * sin(latitude) * sin(latitude));
    *x = (N + altitude) * cos(latitude) * cos(longitude);
    *y = (N + altitude) * cos(latitude) * sin(longitude);
    *z = (N * (1 - e2) + altitude) * sin(latitude);
}

inline void wgs84_to_local_tangent(const origin_info* o, double latitude, double longitude, double altitude, double* local_x, double* local_y, double* local_z) {
    double ecef_x, ecef_y, ecef_z;
    wgs84_to_ecef(latitude, longitude, altitude, &ecef_x, &ecef_y, &ecef_z);

    double dx = o->ecef_x - ecef_x;
    double dy = o->ecef_y - ecef_y;
    double dz = o->ecef_z - ecef_z;

    double sin_lat = sin(latitude / 180.0 * M_PI);
    double cos_lat = cos(latitude / 180.0 * M_PI);
    double sin_lon = sin(longitude / 180.0 * M_PI);
    double cos_lon = cos(longitude / 180.0 * M_PI);

    *local_x = -sin_lon * dx + cos_lon * dy;
    *local_y = -sin_lat * cos_lon * dx - sin_lat * sin_lon * dy + cos_lat * dz;
    *local_z = cos_lat * cos_lon * dx + cos_lat * sin_lon * dy + sin_lat * dz;
}

#endif