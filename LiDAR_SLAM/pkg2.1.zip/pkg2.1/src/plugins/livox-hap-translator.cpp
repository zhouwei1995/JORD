#include <pkg2_type.h>
#include "point_types.h"
#include <service/misc.h>

namespace details {
#pragma pack(push, 1)
    typedef struct {
        int32_t x;            /**< X axis, Unit:mm */
        int32_t y;            /**< Y axis, Unit:mm */
        int32_t z;            /**< Z axis, Unit:mm */
        uint8_t reflectivity; /**< Reflectivity */
        uint8_t tag;          /**< Tag */
    } LivoxLidarCartesianHighRawPoint;

    typedef struct {
        int16_t x;            /**< X axis, Unit:cm */
        int16_t y;            /**< Y axis, Unit:cm */
        int16_t z;            /**< Z axis, Unit:cm */
        uint8_t reflectivity; /**< Reflectivity */
        uint8_t tag;          /**< Tag */
    } LivoxLidarCartesianLowRawPoint;

    typedef struct {
        uint32_t depth;
        uint16_t theta;
        uint16_t phi;
        uint8_t reflectivity;
        uint8_t tag;
    } LivoxLidarSpherPoint;

    typedef struct {
        uint8_t version;
        uint16_t length;
        uint16_t time_interval;
        uint16_t dot_num;
        uint16_t udp_cnt;
        uint8_t frame_cnt;
        uint8_t data_type;
        uint8_t time_type;
        uint8_t rsvd[12];
        uint32_t crc32;
        uint8_t timestamp[8];
        uint8_t data[1];              /**< Point cloud data. */
    } LivoxLidarEthernetPacket;

    typedef struct {
        float gyro_x;
        float gyro_y;
        float gyro_z;

        float acc_x;
        float acc_y;
        float acc_z;
    } LivoxLidarImuRawPoint;
#pragma pack(pop)

    typedef enum {
        // until now(2021-09-05), our livox hap lidar do not support imu data
        kLivoxLidarImuData = 0,

        kLivoxLidarCartesianCoordinateHighData = 0x01,
        kLivoxLidarCartesianCoordinateLowData = 0x02,
        kLivoxLidarSphericalCoordinateData = 0x03
    } LivoxLidarPointDataType;
}

using hap_callback = void (*)(std::string_view data, const unsigned int sender_ip,  void* data_ptr);

struct hap_value {
    int command_port = -1;
    mutable size_t sequence = 0;
    uint32_t host_ip = 0;
};

typedef enum {
  kTimestampTypeNoSync = 0, /**< No sync signal mode. */
  kTimestampTypeGptpOrPtp = 1,    /**< gPTP or PTP sync mode */
  kTimestampTypeGps = 2,   /**< GPS sync mode. */
  kTimestampTypeUnknown = 3,   /**< PPS sync mode. */
} TimestampType;

static inline const char* timestamp_type_to_string(TimestampType type) {
    switch (type) {
        case kTimestampTypeNoSync:
            return "NoSync";
        case kTimestampTypeGptpOrPtp:
            return "GptpOrPtp";
        case kTimestampTypeGps:
            return "Gps";
        case kTimestampTypeUnknown:
            return "Unknown";
        default:
            return "Unknown";
    }
}

template<typename point_type>
static inline void write_time(point_type& point, size_t time_ns) {
    if constexpr (has_time<point_type>::value) {
        if constexpr (std::is_integral_v<decltype(point.time)>) {
            point.time = time_ns;
        } else {
            point.time = time_ns/1e9;
        }
    }
}

template<typename Container>
struct hap_decoder {
    using point_type = typename Container::value_type;
    using time_point = std::chrono::system_clock::time_point;

    TimestampType timestamp_type = kTimestampTypeUnknown;

    Container this_frame, last_frame;
    time_point frame_start = time_point::min();
    size_t last_frame_first_time = 0;

    time_point::duration frame_duration = std::chrono::milliseconds(100);

    template<typename Dur>
    explicit hap_decoder(Dur dur = std::chrono::milliseconds(100)) {
        frame_duration = std::chrono::duration_cast<time_point::duration>(dur);
    }

    bool operator()(byte_buffer sv, time_point references_time) {
        auto data = reinterpret_cast<const details::LivoxLidarEthernetPacket*>(sv.data());
        size_t time_ns = 0;

        if(data->time_type != timestamp_type) {
            timestamp_type = static_cast<TimestampType>(data->time_type);
            std::cout << "timestamp type changed to " << timestamp_type_to_string(timestamp_type) << std::endl;
        }

        if(data->time_type == kTimestampTypeGptpOrPtp) {
            time_ns = *reinterpret_cast<const uint64_t*>(data->timestamp);
        } else {
            time_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(references_time.time_since_epoch() - frame_duration).count() ;
        }

        if (data->data_type == details::kLivoxLidarCartesianCoordinateHighData) {
            auto p_point_data = (details::LivoxLidarCartesianHighRawPoint*)data->data;

            // printf("{dot_num = %d, time = %zd, interval = %d}\r\n", data->dot_num, time_ns, data->time_interval);
            for (uint32_t i = 0; i < data->dot_num; i++) {
                if(p_point_data[i].x == 0 && p_point_data[i].y == 0 && p_point_data[i].z == 0) {
                    continue;
                }
                point_type pts;
                pts.x = (float)p_point_data[i].x * 0.001f;
                pts.y = (float)p_point_data[i].y * 0.001f;
                pts.z = (float)p_point_data[i].z * 0.001f;

                if constexpr(has_intensity<point_type>::value) {
                    pts.intensity = p_point_data[i].reflectivity;
                }
                if constexpr(has_label<point_type>::value) {
                    pts.label = p_point_data[i].tag;
                }
                if constexpr(has_ring<point_type>::value) {
                    pts.ring = 0;
                }

                write_time(pts, time_ns + i * data->time_interval);
                
                this_frame.push_back(pts);
            }
        } else if (data->data_type == details::kLivoxLidarCartesianCoordinateLowData) {
            auto p_point_data = (details::LivoxLidarCartesianLowRawPoint*)data->data;
            for (uint32_t i = 0; i < data->dot_num; i++) {
                point_type pts;
                if(p_point_data[i].x == 0 && p_point_data[i].y == 0 && p_point_data[i].z == 0) {
                    continue;
                }
                pts.x = (float)p_point_data[i].x * 0.01f;
                pts.y = (float)p_point_data[i].y * 0.01f;
                pts.z = (float)p_point_data[i].z * 0.01f;

                if constexpr(has_intensity<point_type>::value) {
                    pts.intensity = p_point_data[i].reflectivity;
                }

                if constexpr(has_label<point_type>::value) {
                    pts.label = p_point_data[i].tag;
                }

                if constexpr(has_ring<point_type>::value) {
                    pts.ring = i % 6;
                }

                write_time(pts, time_ns + i * data->time_interval);

                this_frame.push_back(pts);
            }
        } else if (data->data_type == details::kLivoxLidarSphericalCoordinateData) {
            auto p_point_data = (details::LivoxLidarSpherPoint*)data->data;
            for(uint32_t i = 0; i < data->dot_num; i++) {
                point_type pts;
                if(p_point_data[i].depth == 0) {
                    continue;
                }
                pts.x = cosf((float)p_point_data[i].phi) * cosf((float)p_point_data[i].theta) * (float)p_point_data[i].depth;
                pts.y = cosf((float)p_point_data[i].phi) * sinf((float)p_point_data[i].theta) * (float)p_point_data[i].depth;
                pts.z = sinf((float)p_point_data[i].theta) * (float)p_point_data[i].depth;

                if constexpr(has_intensity<point_type>::value) {
                    pts.intensity = p_point_data[i].reflectivity;
                }
                if constexpr(has_label<point_type>::value) {
                    pts.label = p_point_data[i].tag;
                }
                if constexpr(has_ring<point_type>::value) {
                    pts.ring = 0;
                }

                write_time(pts, time_ns + i * data->time_interval);
                this_frame.push_back(pts);
            }
        }

        if(frame_start == time_point ::min()) {
            frame_start = references_time;
        } else {
            if(references_time - frame_start > frame_duration) {
                last_frame_first_time = std::chrono::duration_cast<std::chrono::microseconds>(frame_start.time_since_epoch()).count();
                frame_start = references_time;
                std::swap(this_frame, last_frame);
                this_frame.clear();
                return true;
            }
        }
        return false;
    }

    const Container* get_last_frame() const {
        return &last_frame;
    }
};

template<typename X>
struct hap_translator : translator {
    using point_type = X;
    hap_decoder<pcl::PointCloud<point_type>> decoder;

    template<typename Dur>
    hap_translator(Dur dur) : decoder(dur) {}

    virtual translated_value* translate(byte_buffer buff, time_point references_time) override {
        if(decoder(buff, references_time)) {
            auto container = decoder.get_last_frame();
            PointCloudTr<point_type>* cloud = new PointCloudTr<point_type>();
            cloud->references_time = time_point(std::chrono::microseconds(decoder.last_frame_first_time));
            cloud->cloud = std::move(*container);
            return cloud;
        }
        return nullptr;
    }
};

template<typename translator_type>
struct livox_hap_translator_factory : translator_factory {
    using point_type = typename translator_type::point_type;

    virtual translator* create_translator(const char* init_string) {
        const char* frame_time = config_get("livox-frametime", "100");
        int frame_time_ms = atoi(frame_time);
        if(frame_time_ms <= 0) {
            log_error("livox-frametime must be positive");
            frame_time_ms = 100;
        }

        if(frame_time_ms != 100) {
            log_debug("livox-frametime set to %d", frame_time_ms);
        }
        return new translator_type(std::chrono::milliseconds(frame_time_ms));
    }

    virtual bool check_init_string(const char* init_string) {
        return true;
    }

    virtual translator_descriptor get_descriptor() const override {
        translator_descriptor desc;
        desc.name = "livox_hap_translator";
        desc.source_type = 5;
        desc.target_type = point_type_id<point_type>::value;
        desc.tag = point_type_id<point_type>::name;
        return desc;
    }
};

__attribute__((constructor))
static void register_hap_translator() {
    register_translator_factory(new livox_hap_translator_factory<hap_translator<XYZ>>());
    register_translator_factory(new livox_hap_translator_factory<hap_translator<XYZI>>());
    register_translator_factory(new livox_hap_translator_factory<hap_translator<XYZIRT>>());
    register_translator_factory(new livox_hap_translator_factory<hap_translator<XYZRGB>>());

    set_configable_value({config_range::app_capture, config_range::app_play}, "livox-frametime", "milliseconds", "set livox frame time, default is 100ms");

}
