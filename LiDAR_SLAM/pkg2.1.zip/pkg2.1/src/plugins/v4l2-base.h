#ifndef __V4L2_BASE_H__
#define __V4L2_BASE_H__

#include <pkg2_type.h>

const type_id JPEG = 6;

struct string_translated_value : public translated_value {
    byte_buffer value;
    time_point time;

    string_translated_value() {
        id = JPEG;
    }
};

#endif