#ifndef __POINT_TYPES_H__
#define __POINT_TYPES_H__

#include <pkg2_type.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>

constexpr type_id PointCloudXYZ = 51;
constexpr type_id PointCloudXYZI = 52;
constexpr type_id PointCloudXYZRGB = 53;
constexpr type_id PointCloudXYZIRT = 54;

struct XYZIRT {
    PCL_ADD_POINT4D;
    PCL_ADD_INTENSITY;
    uint16_t ring;
    double time;
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
} EIGEN_ALIGN16;

POINT_CLOUD_REGISTER_POINT_STRUCT(XYZIRT, (float, x, x)(float, y, y)(float, z, z)(float, intensity, intensity)(std::uint16_t, ring, ring)(double, time, time));

using XYZ = pcl::PointXYZ;
using XYZI = pcl::PointXYZI;
using XYZRGB = pcl::PointXYZRGB;

#define _SFINAE_FOR(field_name)                                                                                                                                                                        \
    template<typename X>                                                                                                                                                                               \
    struct has_##field_name {                                                                                                                                                                          \
        template<typename T>                                                                                                                                                                           \
        static auto check(T*) -> decltype(std::declval<T>().field_name, std::true_type());                                                                                                             \
        template<typename>                                                                                                                                                                             \
        static std::false_type check(...);                                                                                                                                                             \
        static constexpr bool value = decltype(check<X>(nullptr))::value;                                                                                                                              \
    }

_SFINAE_FOR(ring);
_SFINAE_FOR(time);
_SFINAE_FOR(intensity);
_SFINAE_FOR(label);

_SFINAE_FOR(r);
_SFINAE_FOR(g);
_SFINAE_FOR(b);
_SFINAE_FOR(a);

#undef _SFINAE_FOR

template<typename T>
struct has_rgb : std::conjunction<has_r<T>, has_g<T>, has_b<T>> {};

template<typename point_type>
struct point_type_id {};

template<>
struct point_type_id<XYZ> {
    static constexpr type_id value = PointCloudXYZ;
    static constexpr const char* name = "XYZ";
};

template<>
struct point_type_id<XYZI> {
    static constexpr type_id value = PointCloudXYZI;
    static constexpr const char* name = "XYZI";
};

template<>
struct point_type_id<XYZRGB> {
    static constexpr type_id value = PointCloudXYZRGB;
    static constexpr const char* name = "XYZRGB";
};

template<>
struct point_type_id<XYZIRT> {
    static constexpr type_id value = PointCloudXYZIRT;
    static constexpr const char* name = "XYZIRT";
};


template<typename T>
struct PointCloudTr : translated_value {

    PointCloudTr() {
        id = point_type_id<T>::value;
    }
    time_point references_time;
    pcl::PointCloud<T> cloud;

};


using PointCloudXYZTr = PointCloudTr<XYZ>;
using PointCloudXYZITr = PointCloudTr<XYZI>;
using PointCloudXYZRGBTr = PointCloudTr<XYZRGB>;
using PointCloudXYZIRTTr = PointCloudTr<XYZIRT>;

#endif

