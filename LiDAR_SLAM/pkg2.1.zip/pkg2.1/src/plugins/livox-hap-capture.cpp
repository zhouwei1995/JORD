#include <pkg2_type.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <utils/crc.h>
#include <mutex>
#include <set>
#include <service/misc.h>
#include <launch/subcommand.h>

struct address {
    constexpr explicit address(uint8_t c1 = 0, uint8_t c2 = 0, uint8_t c3 = 0, uint8_t c4 = 0, uint16_t port = 0) :
            ip_address((c1 << 0) | (c2 << 8) | (c3 << 16) | (c4 << 24)), port(port) {}

    uint32_t ip_address;
    uint16_t port;

    static constexpr auto broadcast(unsigned short port) {
        return address{255, 255, 255, 255, port};
    }

    [[nodiscard]] std::string name() const {
        char buffer[32];
        sprintf(buffer, "%d.%d.%d.%d:%d",
                ip_address & 0xFF,
                (ip_address >> 8) & 0xFF,
                (ip_address >> 16) & 0xFF,
                (ip_address >> 24) & 0xFF,
                port);
        return buffer;
    }
};

namespace jlurobot::livox::details
{
    // https://www.livox.com/documents/Livox_HAP_API_V1.0.pdf
    typedef enum
    {
        /**
         * Lidar command set, set the working mode and sub working mode of a LiDAR.
         */
        kCommandIDLidarSearch = 0x0000,
        // kCommandIDLidarPreconfig = 0x01,

        kCommandIDLidarWorkModeControl = 0x0100,
        kCommandIDLidarGetInternalInfo = 0x0101,
        kCommandIDLidarPushMsg = 0x0102,

        kCommandIDLidarRebootDevice = 0x0200,
        kCommandIDLidarResetDevice = 0x0201,
        kCommandIDLidarSetPPSSync = 0x0202,

        kCommandIDLidarPushLog = 0x0300,
        kCommandIDLidarCollectionLog = 0x0301,
        kCommandIDLidarLogSysTimeSync = 0x0302,

        kCommandIDGeneralRequestUpgrade = 0x0400,
        kCommandIDGeneralXferFirmware = 0x0401,
        kCommandIDGeneralCompleteXferFirmware = 0x0402,
        kCommandIDGeneralRequestUpgradeProgress = 0x0403,
        kCommandIDGeneralRequestFirmwareInfo = 0xFF,
    } LidarCommandID;



    enum class SdkVersion
    {
        kSdkVerNone,
        kSdkVer0,
        kSdkVer1
    };

    typedef enum
    {
        /** command type, which requires response from the receiver. */
        kCommandTypeCmd = 0,
        /** acknowledge type, which is the response of command type. */
        kCommandTypeAck = 1,
    } CommandType;

    typedef enum
    {
        /** command type, which requires response from the receiver. */
        kHostSend = 0,
        /** acknowledge type, which is the response of command type. */
        kLidarSend = 1,
    } SendType;

#pragma pack(1)

    typedef struct
    {
        uint8_t sof;
        uint8_t version;
        uint16_t length;
        uint32_t seq_num;
        uint16_t cmd_id;
        uint8_t cmd_type;
        uint8_t sender_type;
        char rsvd[6];
        uint16_t crc16_h;
        uint32_t crc32_d;
    } SdkPreamble;

    typedef struct
    {
        uint8_t sof;
        uint8_t version;
        uint16_t length;
        uint32_t seq_num;
        uint16_t cmd_id;
        uint8_t cmd_type;
        uint8_t sender_type;
        char rsvd[6];
        uint16_t crc16_h;
        uint32_t crc32_d;
        uint8_t data[1];
    } SdkPacket;

    typedef struct {
        uint16_t key;                /*< Key, refer to \ref DeviceParamKeyName. */
        uint16_t length;             /*< Length of value. */
        uint8_t value[1];            /*< Value. */
    } LivoxLidarKeyValueParam;

    typedef struct
    {
        uint8_t ret_code;
        uint8_t dev_type;
        char sn[16];
        uint8_t lidar_ip[4];
        uint16_t cmd_port;
    } DetectionData;

#pragma pack()

    size_t fill_sdk_pack(SdkPacket* packet, uint16_t seq, uint16_t cmd_id, uint8_t cmd_type, uint8_t sender_type, const uint8_t* data, uint32_t data_len) {
        memset(packet, 0, sizeof(SdkPacket) - 1);
        packet->sof = 0xAA;
        packet->version = 0x00;
        packet->length = uint16_t(data_len + sizeof(SdkPacket) - 1);
        packet->seq_num = seq;
        packet->cmd_id = cmd_id;
        packet->cmd_type = cmd_type;
        packet->sender_type = sender_type;
        packet->crc16_h = make_crc16(reinterpret_cast<const uint8_t*>(packet), 18);
        memcpy(packet->data, data, data_len);
        if(data_len == 0) {
            packet->crc32_d = 0xffffffff;
        } else {
            packet->crc32_d = make_crc32(data, data_len);
        }

        return sizeof(SdkPacket) + data_len - 1;
    }

};

namespace jlurobot::livox {


    struct hap_ports {
        static constexpr unsigned short default_cmd_port = 56000;
        static constexpr unsigned short default_data_port = 57000;
        static constexpr unsigned short default_imu_port = 58000;
        static constexpr unsigned short default_log_port = 59000;
        static constexpr unsigned short default_push_msg_port = 50000;

        static constexpr unsigned short detection_port = 56000;
    };
}


static bool send_command(int fd, size_t sequence, jlurobot::livox::details::LidarCommandID command_id, const address& address, const void* cdata, size_t clen)
{
    unsigned char data[1500];
    size_t len = jlurobot::livox::details::fill_sdk_pack(
            reinterpret_cast<jlurobot::livox::details::SdkPacket*>(data),
            (uint16_t)sequence,
            command_id,
            jlurobot::livox::details::kCommandTypeCmd,
            jlurobot::livox::details::kHostSend,
            (const uint8_t*)cdata, (uint32_t)clen);

    sockaddr_in addr {};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(address.port);
    addr.sin_addr.s_addr = address.ip_address;
    return sendto(fd, data, len, 0, (sockaddr*)&addr, sizeof(addr)) > 0;
}

static bool sample_send_config(int fd, unsigned int host_ip, const address& addr, size_t sequence)
{
    unsigned char buffer[] = {
        0x02,0x00,0x00,0x00,0x06,0x00,
        0x08,0x00,0x00,0x00,0x00,0x00,
        0x90,0xe2,0x90,0xe2,0x07,0x00,
        0x08,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00
    };

    ((unsigned int*)(buffer + 8))[0] = ((unsigned int*)(buffer + 20))[0] = host_ip;

    return send_command(
            fd,sequence,
            jlurobot::livox::details::kCommandIDLidarWorkModeControl,
            addr,
            buffer,
            sizeof(buffer));
}

static bool sample_control(int fd, size_t sequence, const address&  addr, char value) {
    char buffer[] = {
            0x01,0x00,0x00,0x00,0x1A,0x00,0x01,0x00, value
    };
    return send_command(fd, sequence,
            jlurobot::livox::details::kCommandIDLidarWorkModeControl,
            addr,
            buffer,
            sizeof(buffer)
    );
}

static int create_and_bind(unsigned int ipaddr, unsigned short port) {
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) {
        return -1;
    }

    struct sockaddr_in addr = { 0 };
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = ipaddr;
    addr.sin_port = htons(port);

    if (bind(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(fd);
        return -1;
    }

    return fd;
}

struct hap_device {
    std::string ip;
    std::string sn;
    uint32_t ipaddr;
};

using device_list = std::vector<hap_device>;

static result_of<device_list, std::string> hap_detect_device(uint32_t host_ip, int sequence)
{
    int detect_fd = create_and_bind(host_ip, jlurobot::livox::hap_ports::detection_port);
    if (detect_fd < 0) {
        return fail(string_format("Create detection socket failed : %s", strerror(errno)));
    }

    int detect_result_fd = create_and_bind(INADDR_BROADCAST, jlurobot::livox::hap_ports::detection_port);
    if(detect_result_fd < 0) {
        close(detect_fd);
        return fail(string_format("Create detection result socket failed : %s", strerror(errno)));
    }

    int opt = 1;
    if (setsockopt(detect_fd, SOL_SOCKET, SO_BROADCAST, &opt, sizeof(opt)) < 0) {
        close(detect_fd);
        return fail(string_format("Set detection socket to broadcast mode failed: %s", strerror(errno)));
    }

    int buf = 0;
    if(!send_command(detect_fd, sequence,
                    jlurobot::livox::details::kCommandIDLidarSearch,
                    address::broadcast(jlurobot::livox::hap_ports::detection_port),
                    &buf, 1)) {
        close(detect_fd);
        return fail(string_format("Send detection command failed: %s", strerror(errno)));
    }
    close(detect_fd);

    std::vector<hap_device> devices;

    // set timeout
    struct timeval tv;
    tv.tv_sec = 2;
    tv.tv_usec = 0;

    if (setsockopt(detect_result_fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
        close(detect_result_fd);
        
        return fail(string_format("Set detection socket timeout failed: %s", strerror(errno)));
    }

    sockaddr_in addr;
    socklen_t addr_len = sizeof(addr);

    auto start_detect_time = std::chrono::system_clock::now();
    std::set<std::string> sn_set;
    while(std::chrono::system_clock::now() - start_detect_time < std::chrono::seconds(2)) {
        unsigned char buffer[1500];
        int len = recvfrom(detect_result_fd, buffer, sizeof(buffer), 0, (sockaddr*)&addr, &addr_len);
        if (len < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) {
                continue;
            } else {
                close(detect_result_fd);
                return fail(string_format("Receive detection response failed: %s", strerror(errno)));
            }
        }

        if(len < sizeof(jlurobot::livox::details::SdkPacket)) {
            continue;
        }

        auto packet = reinterpret_cast<const jlurobot::livox::details::SdkPacket*>(buffer);
        if(packet->sender_type == jlurobot::livox::details::kLidarSend &&
            packet->cmd_id == jlurobot::livox::details::kCommandIDLidarSearch) {

            auto detection_data = (jlurobot::livox::details::DetectionData*)packet->data;
            if(detection_data->ret_code >= 0) {
                hap_device result;
                char buffer[32];
                auto ip_address = addr.sin_addr.s_addr;
                sprintf(buffer, "%d.%d.%d.%d",
                    ip_address & 0xFF,
                    (ip_address >> 8) & 0xFF,
                    (ip_address >> 16) & 0xFF,
                    (ip_address >> 24) & 0xFF);
                result.ip = buffer;
                result.sn = detection_data->sn;
                result.ipaddr = ip_address;
                if(sn_set.find(result.sn) == sn_set.end()) {
                    log_info("livox device(%s) at %s", result.sn.c_str(), result.ip.c_str());
                    devices.push_back(result);
                    sn_set.insert(result.sn);
                }
            } else {
                log_warning("detection_data->ret_code = %d", detection_data->ret_code);
            }
        }
    }

    close(detect_result_fd);
    return ok(devices);
}

struct hap_device_manager {
    device_list devices;
    size_t packet_sequence;
    int command_fd;
    int host_ip;
    int data_fd;

    void start_all_device() {
        for(auto& device : devices) {
            address device_address;
            device_address.ip_address = device.ipaddr;
            device_address.port = jlurobot::livox::hap_ports::default_cmd_port;

            if(!sample_control(command_fd, packet_sequence++, device_address, 1))
            {
                log_error("Send config command to device failed: %s", device.ip.c_str());
            }
        }
    }

    void stop_all_device() {
        for(auto& device : devices) {
            address device_address;
            device_address.ip_address = device.ipaddr;
            device_address.port = jlurobot::livox::hap_ports::default_cmd_port;

            if(!sample_control(command_fd, packet_sequence++, device_address, 2))
            {
                log_error("Send stop command to device failed : %s", device.ip.c_str());
            }
        }
    }

    static result_of<uint32_t, std::string> check_host_addr() {
        char hostname[256];
        hostent* hostinfo;
        gethostname(hostname, sizeof(hostname));

        hostinfo = gethostbyname(hostname);

        if(hostinfo == nullptr) {
            return fail(string_format("Get host ip address failed: %s", hstrerror(h_errno)));
        }

        uint32_t addr = 0;
        // find the first ipv4 address with 192.168.x.x
        for(int i = 0; hostinfo->h_addr_list[i] != nullptr; i++) {
            auto ip = *(uint32_t*)hostinfo->h_addr_list[i];
            if(addr == 0 && (ip & 0x0000FFFF) == 0x0000A8C0) {
                addr = ip;
            }

            log_info("host ip: %d.%d.%d.%d",
                ip & 0xFF,
                (ip >> 8) & 0xFF,
                (ip >> 16) & 0xFF,
                (ip >> 24) & 0xFF);
        }
        if(addr != 0) {
            log_info("select host ip: %d.%d.%d.%d",
                addr & 0xFF,
                (addr >> 8) & 0xFF,
                (addr >> 16) & 0xFF,
                (addr >> 24) & 0xFF);
            return ok(addr);
        }

        return fail("No valid host ip address found");
    }
};

static hap_device_manager hap_manager;

static bool init_hap_manager(const char* host_addr) {
    uint32_t host = 0;
    if(host_addr == nullptr || strcmp(host_addr, "auto") == 0) {
        auto result = hap_device_manager::check_host_addr();
        if(!result.ok()) {
            log_error("Get host ip address failed: %s", result.error().c_str());
            return false;
        }
        host = result.value();
    } else {
        host = inet_addr(host_addr);
        if (host == INADDR_NONE) {
            log_error("Invalid host ip address: %s", host_addr);
            return false;
        }
    }
    hap_manager.packet_sequence = 0;
    auto detect_result = hap_detect_device(host, hap_manager.packet_sequence++);
    
    if(detect_result.ok()) {
        hap_manager.devices = detect_result.value();
    } else {
        log_error("Detect device failed: %s", detect_result.error().c_str());
        return false;
    }

    hap_manager.host_ip = host;
    hap_manager.command_fd = create_and_bind(host, jlurobot::livox::hap_ports::default_cmd_port);
    if(hap_manager.command_fd < 0) {
        log_error("create command socket failed: %s", strerror(errno));
        return false;
    }

    hap_manager.data_fd = create_and_bind(host, jlurobot::livox::hap_ports::default_data_port);

    add_cleanup([](void* arg) {
        hap_manager.stop_all_device();
    }, nullptr);
    return true;
}

static bool hap_init(const char* host) {
    static std::once_flag flag;
    static bool result = false;
    std::call_once(flag, [host]() {
        result = init_hap_manager(host);
        if(!result) {
            log_error("init hap manager failed");
        }
    });
    return result;
}

constexpr type_id LIVOX_HAP = 5;
constexpr type_id LIVOX_HAP_LOG = 101;

struct hap_capture : capture_source {

    virtual ~hap_capture() {
    }

    virtual void start() {
        hap_manager.start_all_device();
    }

    virtual void stop() {
        hap_manager.stop_all_device();
    }

    virtual waitable_object get_waitable_object() {
        return hap_manager.data_fd;
    }

    virtual result_of<byte_buffer, std::string> capture() {
        byte_buffer buffer = byte_storage::create(1500);
        sockaddr_in addr;
        socklen_t addr_len = sizeof(addr);
        auto len = recvfrom(hap_manager.data_fd, buffer.data(),
            buffer.size(), 0, (sockaddr*)&addr, &addr_len);
        if(len < 0) {
            return fail(string_format("recvfrom failed: %s", strerror(errno)));
        }
        buffer.shrink(len);
        return ok(buffer);
    }

    virtual type_id get_type() const {
        return LIVOX_HAP;
    }

};

struct hap_capture_factory : capture_factory {
    virtual result_of<capture_source*, std::string> create_capture_source(const char* init_string) override {
        hap_init(init_string);
        return ok(new hap_capture());
    }

    virtual bool check_init_string(const char* init_string) override{
        if(init_string == nullptr || strcmp(init_string, "auto") == 0) {
            return true;
        }

        uint32_t host = inet_addr(init_string);
        return host != INADDR_NONE;
    }

    virtual const capture_device& get_device() const override {
        static capture_device device {
            "livox-hap",
            "Livox HAP init_string: <host_address>|auto, auto will use the first host address with 192.168.x.x",
            "Livox HAP Lidar capture source",
        };
        return device;
    }

};

struct hap_log_capture_device : capture_source {

    virtual void start() override {

    }

    virtual void stop() override {

    }

    virtual waitable_object get_waitable_object() override {
        return hap_manager.command_fd;
    }

    virtual result_of<byte_buffer, std::string> capture() override {
        byte_buffer buffer = byte_storage::create(256);
        sockaddr_in addr;
        socklen_t addr_len = sizeof(addr);
        auto len = recvfrom(hap_manager.command_fd, buffer.data(),
            buffer.size(), 0, (sockaddr*)&addr, &addr_len);
        if(len < 0) {
            return fail(string_format("recvfrom failed: %s", strerror(errno)));
        }
        buffer.shrink(len);
        return ok(buffer);
    }

    virtual type_id get_type() const override {
        return LIVOX_HAP_LOG;
    }
};


struct hap_log_capture_factory : capture_factory {
    virtual result_of<capture_source*, std::string> create_capture_source(const char* init_string) override {
        hap_init(init_string);
        return ok(new hap_log_capture_device());
    }

    virtual bool check_init_string(const char* init_string) override{
        if(init_string == nullptr || strcmp(init_string, "auto") == 0) {
            return true;
        }

        uint32_t host = inet_addr(init_string);
        return host != INADDR_NONE;
    }

    virtual const capture_device& get_device() const override {
        static capture_device device {
            "livox-hap-log",
            "Livox HAP Log init_string: <host_address>|auto, auto will use the first host address with 192.168.x.x",
            "Livox HAP Log capture source",
        };
        return device;
    }
};

__attribute__((constructor))
static void register_hap_capture() {
    register_type("livox-hap", LIVOX_HAP);
    register_type("livox-hap-log", LIVOX_HAP_LOG, true);

    register_capture_factory(new hap_capture_factory());
    register_capture_factory(new hap_log_capture_factory());
}
