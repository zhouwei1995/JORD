#ifdef __pkg2_libcatkin

#include "catkin-base.h"
#include "npos220s-base.h"

#include <sensor_msgs/Imu.h>
#include <sensor_msgs/NavSatFix.h>
#include <nav_msgs/Odometry.h>
#include <tf/tf.h>

#include <pkg2_type.h>
#include <service/misc.h>

struct npos220s_player : player {

    ros::Publisher pub_imu;
    ros::Publisher pub_gps;
    ros::Publisher pub_odom;

    bool odom_first_frame_init = false;
    origin_info odom_origin;
    
    size_t imu_seq = 0;
    size_t gps_seq = 0;
    size_t odom_seq = 0;

    npos220s_player(const char* topic) {
        auto handle = catkin_node();
        topic = check_ros_topic(topic);
        try {
            pub_imu = handle.advertise<sensor_msgs::Imu>(string_format("%s/imu", topic), 1);
            pub_gps = handle.advertise<sensor_msgs::NavSatFix>(string_format("%s/fix", topic), 1);
            pub_odom = handle.advertise<nav_msgs::Odometry>(string_format("%s/odom", topic), 1);
        } catch(std::exception& e) {
            log_fatal("Failed to advertise topic: %s", e.what());
        }
    }

    virtual void play(translated_value* type) override {

        if(type->id != npos220s_tr) {
            return;
        }
        auto tr = static_cast<npos220s_trvalue*>(type);

        for(auto var : tr->value) {
            switch(var.type) {
            case npos220s_value_type::RAWIMU:
                play_imu(var.time, var.rawimu);
                break;
            case npos220s_value_type::INSPVAXA:
                play_gps(var.time, var.inspvaxa);
                play_odom(var.time, var.inspvaxa);
                break;
            default:
                break;
            }
        }
    }

    void play_gps(time_point tp, const npos220s_inspvaxa& v) {
        sensor_msgs::NavSatFix fix;
        fix.altitude = v.altitude;
        fix.latitude = v.latitude;
        fix.longitude = v.longitude;

        fix.position_covariance[0] = v.cov_x;
        fix.position_covariance[4] = v.cov_y;
        fix.position_covariance[8] = v.cov_z;

        fix.header.frame_id = "npos220s";
        fix.header.stamp = from_std(tp);
        fix.header.seq = gps_seq++;


        // TODO: set status from npos220s
        // fix.status.service = sensor_msgs::NavSatStatus::SERVICE_GPS;
        // fix.status.status = sensor_msgs::NavSatStatus::STATUS_FIX;
        
        pub_gps.publish(fix);

        do_sync(fix.header.stamp);
    }

    void play_odom(time_point tp, const npos220s_inspvaxa& v) {
        if(odom_first_frame_init == false) {
            odom_first_frame_init = true;
            wgs84_to_ecef(v.latitude, v.longitude, v.altitude, &odom_origin.ecef_x, &odom_origin.ecef_y, &odom_origin.ecef_z);
        }
        nav_msgs::Odometry odom;
        odom.header.frame_id = "npos220s";
        odom.header.stamp = from_std(tp);
        odom.header.seq = odom_seq++;

        wgs84_to_local_tangent(&odom_origin, v.latitude, v.longitude, v.altitude, 
            &odom.pose.pose.position.x, &odom.pose.pose.position.y, &odom.pose.pose.position.z);

        tf::Quaternion q = tf::createQuaternionFromRPY(v.roll, v.pitch, v.heading);
        odom.pose.pose.orientation.x = q.x();
        odom.pose.pose.orientation.y = q.y();
        odom.pose.pose.orientation.z = q.z();
        odom.pose.pose.orientation.w = q.w();

        odom.pose.covariance[0] = v.cov_x;
        odom.pose.covariance[7] = v.cov_y;
        odom.pose.covariance[14] = v.cov_z;

        pub_odom.publish(odom);

        do_sync(odom.header.stamp);
    }

    void play_imu(time_point tp, const npos220s_rawimu& v) {
        sensor_msgs::Imu imu;
        imu.header.frame_id = "npos220s";
        imu.header.stamp = from_std(tp);
        imu.header.seq = imu_seq++;

        imu.orientation.x = 0;
        imu.orientation.y = 0;
        imu.orientation.z = 0;
        imu.orientation.w = 1;

        imu.angular_velocity.x = v.gx;
        imu.angular_velocity.y = v.gy;
        imu.angular_velocity.z = v.gz;

        imu.linear_acceleration.x = v.ax;
        imu.linear_acceleration.y = v.ay;
        imu.linear_acceleration.z = v.az;

        pub_imu.publish(imu);

        do_sync(imu.header.stamp);
    }
};

struct npos220s_player_factory : player_factory {
    virtual player* create_player(const char* init_string) {
        return new npos220s_player(init_string);
    }

    virtual bool check_init_string(const char* init_string) {
        return true;
    }

    virtual player_descriptor get_descriptor() const {
        player_descriptor desc;
        desc.name = "npos220s-ros1-player";
        desc.target_type = npos220s_tr;
        return desc;
    }
};

__attribute__((constructor))
static void npos220s_player_init() {
    register_player_factory(new npos220s_player_factory());
}

#endif
