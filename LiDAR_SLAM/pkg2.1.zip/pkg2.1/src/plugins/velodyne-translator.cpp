#include "point_types.h"

#include <pkg2_type.h>
#include <cmath>
#include <string>
#include <string_view>

#include "velodyne-base.h"
#include <service/misc.h>

inline float deg2rad(float value)
{
    return value / 180.0f * 3.141592f;
}

struct as_t
{
    const unsigned char *ptr;

    template <typename T>
    operator T() const
    {
        return *reinterpret_cast<const T *>(ptr);
    }
};

template <typename P>
as_t as(const P *ptr, size_t off)
{
    return as_t{reinterpret_cast<const unsigned char *>(ptr) + off};
}

struct rgb_writer
{
    template <typename C, typename point_type>
    inline static void write(const C *c, point_type &p, int it, int block_id, int ring_id)
    { // RGB
        (void)c;
        p.r = it;
        p.g = ring_id * 16;
        p.b = block_id;
        if constexpr (has_a<point_type>::value)
            p.a = 255;
    }
};

struct irt_writer
{
    template <typename C, typename point_type>
    static inline void write(const C *c, point_type &p, int it, int block_id, int ring_id)
    { // RGB
        if constexpr (has_ring<point_type>::value)
            p.ring = ring_id;

        if constexpr (has_time<point_type>::value)
        {
            p.time = (float(c->package_stamp - c->frame_stamp) + float(block_id) * 45.2f + 1.15f * float(ring_id)) * 1e-6f;
        }
        if constexpr (has_intensity<point_type>::value)
            p.intensity = it;
    }
};

struct point_writer
{
    template <typename C, typename point_type>
    static inline void write_point(const C *c, point_type &p, int it, int block_id, int ring_id)
    {
        if constexpr (has_rgb<point_type>::value)
            rgb_writer::write(c, p, it, block_id, ring_id);
        irt_writer::write(c, p, it, block_id, ring_id);
    }
};

template <typename Container>
struct vlp16_decoder
{
    using point_type = typename Container::value_type;
    unsigned short last_block_angle = 0;
    char last_block[100] = {0};
    uint64_t last_frame_first_time = 0, this_frame_time = 0;
    vlp16_decoder() = default;
    float vertical_angle(int channel)
    {
        const float vlp16_vertical_angle_c[] = {
            -15.0f, 1.0f, -13.0f, 3.0f, -11.0f, 5.0f, -9.0f, 7.0f, -7.0f, 9.0f, -5.0f, 11.0f, -3.0f, 13.0f, -1.0f, 15.0f};
        return deg2rad(vlp16_vertical_angle_c[channel]);
    }

    uint32_t package_stamp = 0, frame_stamp = 0;
    bool operator()(const byte_buffer &udp_package, std::chrono::system_clock::time_point reference_time = std::chrono::system_clock::now())
    {
        if (udp_package.size() != 1206)
        {
            return false;
        }
        //
        const char *last_processed_ptr = last_block;
        bool got_zero = false;
        for (int i = 0; i < 12; i++)
        {
            const char *block_ptr = reinterpret_cast<const char *>(udp_package.data() + i * 100);
            unsigned short this_angle = as(block_ptr, 2);
            float p2_angle = 0.0f;
            if (this_angle < last_block_angle)
            {
                // zero !
                p2_angle = (36000.0f + float(this_angle) + last_block_angle) / 200.0f;
                if (p2_angle > 360.0f)
                    p2_angle -= 360.0f;
            }
            else
            {
                p2_angle = ((float)this_angle + last_block_angle) / 200.0f;
            }
            package_stamp = (uint32_t)as(udp_package.data(), 1200);
            read_channels(last_processed_ptr + 4, last_block_angle / 100.0f, i == 0 ? 23 : i * 2 - 1);
            read_channels(last_processed_ptr + 52, p2_angle, i == 0 ? 24 : i * 2);
            last_processed_ptr = block_ptr;
            if (this_angle < last_block_angle && last_block_angle > 35900)
            {
                last_frame_first_time = this_frame_time;
                auto hours = std::chrono::duration_cast<std::chrono::hours>(
                                 reference_time.time_since_epoch())
                                 .count();
                auto minutes = std::chrono::duration_cast<std::chrono::minutes>(
                                   reference_time.time_since_epoch() - std::chrono::hours(hours))
                                   .count();
                if(minutes > 50 && package_stamp < 10 * 60 * 1000000) {
                    hours++;
                }

                this_frame_time = package_stamp + hours * 3600000000;
                frame_stamp = package_stamp;
                got_zero = true;
            }
            last_block_angle = this_angle;
        }
        memcpy(last_block, udp_package.data() + 1100, 100);
        return got_zero && (container_last_frame.size() > 0);
    }

    Container *get_last_frame()
    {
        return &container_last_frame;
    }

private:
    float last_channel_angle = 0.0f;
    Container container_last_frame, container_this_frame;
    bool write_to_container = false;

    bool read_channels(const char *channel, float angle, int block_id)
    {
        bool last_frame_got_zero = false;
        // ROS_INFO("ang = %f, last_chan_ang = %f", angle, last_channel_angle);
        {
            auto ang = angle;
            if (ang < 1.00f && last_channel_angle > 350.0f)
                ang += 360.00;
            if (ang - last_channel_angle > 2.00f)
                printf("\033[32m[velodyne] angle difference is too big: %f %f %f\033[0m\n", ang - last_channel_angle, angle, last_channel_angle);
        }

        if (angle < last_channel_angle && angle < 100)
        {
            if (container_this_frame.size() > 0)
            {
                container_last_frame.swap(container_this_frame);
                container_this_frame.clear();
            }
            last_frame_got_zero = true;
            write_to_container = true;
        }
        for (int i = 0; i < 16; i++)
        {
            unsigned short distance_mm = as(channel, i * 3);
            if (distance_mm == 0)
                continue;

            auto distance = float(distance_mm) * 2e-3f;
            point_type p;
            p.z = distance * sinf(vertical_angle(i));
            p.x = distance * cosf(vertical_angle(i)) * cosf(deg2rad(angle));
            p.y = -distance * cosf(vertical_angle(i)) * sinf(deg2rad(angle));

            point_writer::write_point(this, p, channel[i * 3 + 2], block_id, i);

            if (write_to_container)
            {
                container_this_frame.push_back(p);
            }
        }
        last_channel_angle = angle;
        return last_frame_got_zero;
    }
};

template <typename Container>
struct hdl32_decoder
{
    using point_type = typename Container::value_type;

    int64_t last_frame_first_time = 0, this_frame_time = 0;
    uint64_t frame_stamp = 0, package_stamp = 0;

    hdl32_decoder()
    {
    }

    float vertical_angle(int channel)
    {
        const float vlp16_vertical_angle_c[] = {
            -30.67f, -9.33f, -29.33f, -8.00f, -28.00f, -6.67f, -26.67f, -5.33f, -25.33f,
            -4.00f, -24.00f, -2.67f, -22.67f, -1.33f, -21.33f, 0.00f, -20.00f,
            1.33f, -18.67f, 2.67f, -17.33f, 4.00f, -16.00f, 5.33f,
            -14.67f, 6.67f, -13.33f, 8.00f, -12.00f, 9.33f, -10.67f, 10.67f};
        return deg2rad(vlp16_vertical_angle_c[channel]);
    }

    bool operator()(const byte_buffer &udp_package,
                    std::chrono::system_clock::time_point reference_time = std::chrono::system_clock::now())
    {
        if (udp_package.size() != 1206)
        {
            return false;
        }
        package_stamp = (uint32_t)as(udp_package.data(), 1200);
        bool got_zero = false;
        for (int i = 0; i < 12; i++)
        {
            const char *block_ptr = reinterpret_cast<const char *>(udp_package.data() + i * 100);
            unsigned short this_angle = as(block_ptr, 2);
            if (read_channels(block_ptr + 4, this_angle / 100.0f, i))
            {
                last_frame_first_time = this_frame_time;
                auto hours = std::chrono::duration_cast<std::chrono::hours>(
                                 reference_time.time_since_epoch())
                                 .count();
                auto minutes = std::chrono::duration_cast<std::chrono::minutes>(
                                   reference_time.time_since_epoch() - std::chrono::hours(hours))
                                   .count() ;
                
                if (minutes > 50 && package_stamp < 10 * 60 * 1000000) {
                    hours += 1;
                }

                frame_stamp = package_stamp;
                this_frame_time = package_stamp + hours * 3600000000;
                got_zero = true;
            }
        }
        return got_zero && (container_last_frame.size() > 0);
    }

    Container *get_last_frame()
    {
        return &container_last_frame;
    }

private:
    float last_channel_angle = 0.0f;
    Container container_last_frame, container_this_frame;
    bool write_to_container = false;

    bool read_channels(const char *channel, float angle, int block_id)
    {
        bool last_frame_got_zero = false;
        {
            auto ang = angle;
            if (ang < 1.00f && last_channel_angle > 350.0f)
                ang += 360.0f;
            if (ang - last_channel_angle > 200)
                log_debug("\033[32m[vlp16_decoder] angle difference is too big: %f %f %f\n\033[0m", ang - last_channel_angle, angle, last_channel_angle);
        }

        if (angle < last_channel_angle && angle < 100)
        {
            if (container_this_frame.size() > 0)
            {
                container_last_frame.swap(container_this_frame);
                container_this_frame.clear();
            }
            last_frame_got_zero = true;
            write_to_container = true;
        }
        for (int i = 0; i < 32; i++)
        {
            unsigned short distance_mm = as(channel, i * 3);
            if (distance_mm == 0)
                continue;

            float distance = distance_mm * 2e-3f;
            point_type p;
            p.z = distance * sin(vertical_angle(i));
            p.y = -distance * cos(vertical_angle(i)) * cosf(deg2rad(angle));
            p.x = -distance * cos(vertical_angle(i)) * sinf(deg2rad(angle));

            point_writer::write_point(this, p, channel[i * 3 + 2], block_id, i);

            if (write_to_container)
            {
                container_this_frame.push_back(p);
            }
        }
        last_channel_angle = angle;
        return last_frame_got_zero;
    }
};

template<typename xpoint_type>
struct vlp16_translator : translator {
    using point_type = xpoint_type;

    static constexpr type_id source_type_id = 1;
    vlp16_decoder<pcl::PointCloud<point_type>> decoder;

    virtual translated_value* translate(byte_buffer buff, time_point references_time) override {
        if (decoder(buff, references_time)) {
            auto container = decoder.get_last_frame();
            PointCloudTr<point_type>* cloud = new PointCloudTr<point_type>();
            cloud->references_time = time_point(std::chrono::microseconds(decoder.last_frame_first_time));
            cloud->cloud = std::move(*container);
            return cloud;
        }
        return nullptr;
    }

};

template<typename xpoint_type>
struct hdl32_translator : translator {
    using point_type = xpoint_type;

    static constexpr type_id source_type_id = Velodyne32;
    hdl32_decoder<pcl::PointCloud<point_type>> decoder;

    virtual translated_value* translate(byte_buffer buff, time_point references_time) override {
        if (decoder(buff, references_time)) {
            auto container = decoder.get_last_frame();
            PointCloudTr<point_type>* cloud = new PointCloudTr<point_type>();
            cloud->references_time = time_point(std::chrono::microseconds(decoder.last_frame_first_time));
            cloud->cloud = std::move(*container);
            return cloud;
        }
        return nullptr;
    }

};

template<typename translator_type>
struct velodyne_translator_factory : translator_factory {
    using point_type = typename translator_type::point_type;

    virtual translator* create_translator(const char* init_string) {
        return new translator_type();
    }

    virtual bool check_init_string(const char* init_string) {
        return true;
    }

    virtual translator_descriptor get_descriptor() const override {
        translator_descriptor desc;
        desc.name = "velodyne_translator";
        desc.source_type = translator_type::source_type_id;
        desc.target_type = point_type_id<point_type>::value;
        desc.tag = point_type_id<point_type>::name;
        return desc;
    }
};

__attribute__((constructor))
static void velodyne_translator_init() {
    register_translator_factory(new velodyne_translator_factory<vlp16_translator<XYZ>>());
    register_translator_factory(new velodyne_translator_factory<vlp16_translator<XYZI>>());
    register_translator_factory(new velodyne_translator_factory<vlp16_translator<XYZRGB>>());
    register_translator_factory(new velodyne_translator_factory<vlp16_translator<XYZIRT>>());

    register_translator_factory(new velodyne_translator_factory<hdl32_translator<XYZ>>());
    register_translator_factory(new velodyne_translator_factory<hdl32_translator<XYZI>>());
    register_translator_factory(new velodyne_translator_factory<hdl32_translator<XYZRGB>>());
    register_translator_factory(new velodyne_translator_factory<hdl32_translator<XYZIRT>>());
}
