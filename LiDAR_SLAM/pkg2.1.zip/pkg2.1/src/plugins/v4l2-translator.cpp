#include "v4l2-base.h"

struct v4l2_translator : translator {
    
    virtual translated_value* translate(byte_buffer buff, time_point references_time) {
        string_translated_value* value = new string_translated_value();
        value->value = buff;
        value->time = references_time;
        return value;
    }
};

struct v4l2_translator_factory : translator_factory {
    virtual translator* create_translator(const char* init_string){
        return new v4l2_translator();
    }

    virtual bool check_init_string(const char* init_string) {
        return true;
    }

    virtual translator_descriptor get_descriptor() const {
        static translator_descriptor desc = {
            "v4l2-translator",
            "direct",
            JPEG,
            JPEG
        };
        return desc;
    }
};

__attribute__((constructor))
static void v4l2_translator_init() {
    register_translator_factory(new v4l2_translator_factory());
}
