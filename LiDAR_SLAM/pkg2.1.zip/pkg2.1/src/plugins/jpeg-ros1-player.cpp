#include <service/misc.h>
#ifdef __pkg2_libcatkin

#include "catkin-base.h"
#include "v4l2-base.h"

#include <sensor_msgs/Image.h>

#include <pkg2_type.h>


#ifdef __pkg2_libturbojpeg
#include <turbojpeg.h>

bool decode_jpeg(byte_buffer buffer, sensor_msgs::Image* image) {
    static tjhandle jpeg_decompressor = tjInitDecompress();
    if (!jpeg_decompressor) {
        log_error("Failed to initialize jpeg decompressor");
        return false;
    }

    auto res = tjDecompressHeader(jpeg_decompressor, (unsigned char*)buffer.data(), buffer.size(), (int*)&image->width, (int*)&image->height);
    if (res != 0) {
        log_error("Failed to decompress jpeg header");
        return false;
    }

    image->data.resize(image->width * image->height * 3);
    res = tjDecompress2(jpeg_decompressor, (unsigned char*)buffer.data(), buffer.size(), image->data.data(), image->width, 0, image->height, TJPF_RGB, TJFLAG_FASTDCT);
    if (res != 0) {
        log_error("Failed to decompress jpeg");
        return false;
    }
    image->encoding = "rgb8";
    image->step = image->width * 3;
    return true;
}
#elif defined(__pkg2_libjpeg)
#include <jpeglib.h>
#include <setjmp.h>
struct jpeg_error_handler {
    struct jpeg_error_mgr pub;
    jmp_buf setjmp_buffer;
};

bool decode_jpeg(byte_buffer buffer, sensor_msgs::Image* image) {
    struct jpeg_decompress_struct cinfo;
    struct jpeg_error_handler jerr;
    cinfo.err = jpeg_std_error(&jerr.pub);

    jerr.pub.error_exit = [](j_common_ptr cinfo) {
        jpeg_error_handler* myerr = (jpeg_error_handler*)cinfo->err;
        longjmp(myerr->setjmp_buffer, 1);
    };

    if(setjmp(jerr.setjmp_buffer)) {
        log_error("\033[31mFailed to decompress jpeg: %s\033[0m\n", jerr.pub.jpeg_message_table[jerr.pub.msg_code]);
        jpeg_destroy_decompress(&cinfo);
        return false;
    }
    jpeg_create_decompress(&cinfo);

    if(buffer.size() == 0) {
        log_warning("buffer size is 0");
        return false;
    }
    jpeg_mem_src(&cinfo, (unsigned char*)buffer.data(), buffer.size());
    if(jpeg_read_header(&cinfo, TRUE) != JPEG_HEADER_OK) {
        log_error("\033[31mFailed to read jpeg header\033[0m\n");
        return false;
    }
    if(jpeg_start_decompress(&cinfo) != TRUE) {
        log_error("\033[31mFailed to start decompress\033[0m\n");
        return false;
    }
    image->width = cinfo.output_width;
    image->height = cinfo.output_height;
    image->encoding = "rgb8";
    image->step = image->width * 3;
    image->data.resize(image->width * image->height * 3);
    while (cinfo.output_scanline < cinfo.output_height) {
        auto row = cinfo.output_scanline;
        unsigned char* ptr = image->data.data() + row * image->step;
        jpeg_read_scanlines(&cinfo, (JSAMPARRAY)&ptr, 1);
    }
    jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
    return true;
}

#else
#include <atomic>
bool decode_jpeg(byte_buffer buffer, sensor_msgs::Image* image) {
    static atomic_flag warned = false;
    if(warned.test_and_set()) {
        printf("\033[31mjpeg support not compiled in\033[0m\n");
    }
    return false;
}
#endif

struct jpeg_player : player {
    ros::Publisher pub;
    size_t seq = 0;

    jpeg_player(const char* topic) {
        auto handle = catkin_node();
        pub = handle.advertise<sensor_msgs::Image>(check_ros_topic(topic), 1);
    }

    virtual void play(translated_value* type) override {
        if(type->id != JPEG) {
            return;
        }
        auto tr = static_cast<string_translated_value*>(type);
        sensor_msgs::Image image;

        if(decode_jpeg(tr->value, &image)) {
            image.header.frame_id = "jpeg";
            image.header.stamp = from_std(tr->time);
            image.header.seq = seq++;
            pub.publish(image);

            do_sync(image.header.stamp);
        }
    }
};

struct jpeg_player_factory : player_factory {
    virtual player* create_player(const char* init_string) {
        return new jpeg_player(init_string);
    }

    virtual bool check_init_string(const char* init_string) {
        return true;
    }

    virtual player_descriptor get_descriptor() const {
        player_descriptor desc;
        desc.name = "jpeg-ros1-player";
        desc.target_type = JPEG;
        return desc;
    }
};

__attribute__((constructor))
static void npos220s_player_init() {
    register_player_factory(new jpeg_player_factory());
}

#endif
