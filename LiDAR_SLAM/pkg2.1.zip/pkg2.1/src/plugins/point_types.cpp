#include "point_types.h"

__attribute__((constructor)) static void init() {
    register_translated_type("PointCloudXYZ", PointCloudXYZ);
    register_translated_type("PointCloudXYZI", PointCloudXYZI);
    register_translated_type("PointCloudXYZRGB", PointCloudXYZRGB);
    register_translated_type("PointCloudXYZIRT", PointCloudXYZIRT);
}

