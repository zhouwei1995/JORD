#include <pkg2_type.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include "velodyne-base.h"  
#include <thread>
#include <mutex>
#include <map>
#include <launch/subcommand.h>
#include <service/misc.h>

struct report_status {
    int last_pps_status = -1;
    int last_gprmc_status = -1;
    std::chrono::system_clock::time_point last_report_time = std::chrono::system_clock::now();
};

struct velodyne_position_listener {
    int listen_fd;
    int available_capture_count;
    volatile bool should_stop;
    std::thread listen_thread;

    std::map<std::string, report_status> lidar_status;
};

static void parse_velodyne_position_packet(const char* lidar_name, const char* bytes, size_t packet_len, report_status* ls) {
    if(packet_len != 512) {
        return;
    }

    auto now = std::chrono::system_clock::now();
    // check for pps status
    unsigned char status = bytes[198 + 4];
    bool previous_ok = ls->last_pps_status == 2 && ls->last_gprmc_status == 0;
    switch(status) {
    case 0:
        if(ls->last_pps_status != 0 || now - ls->last_report_time > std::chrono::seconds(5)) {
            log_warning("no available pps detected on lidar %s", lidar_name);
            ls->last_report_time = now;
            ls->last_pps_status = 0;
        }
        return;
    case 1:
        // lidar synchronizing, ignore
        if(ls->last_pps_status != 1) {
            ls->last_report_time = now;
            ls->last_pps_status = 1;
            break;
        }

        if(now - ls->last_report_time > std::chrono::seconds(5)) {
            log_warning("lidar %s has synchronized for more than 5 seconds!", lidar_name);
            ls->last_report_time = now;
        }
        break;
    case 2:
        // pps locked, ok
        ls->last_pps_status = 2;
        break;
    case 3:
        if(ls->last_pps_status != 0 || now - ls->last_report_time > std::chrono::seconds(5)) {
            log_error("pps error on lidar %s", lidar_name);
            ls->last_report_time = now;
            ls->last_pps_status = 3;
        }
        return;
    }

    const char* statement = bytes + 198 + 8;
    if(strncmp(statement, "$GPRMC,", 7) != 0) {
        const char* statement_name = statement;
        while(*statement_name != ',' && *statement_name != '\0') {
            ++statement_name;
        }
        if(ls->last_gprmc_status !=  2 || now - ls->last_report_time > std::chrono::seconds(5)) {
            log_warning("statement %.*s on lidar %s, not $GPRMC !", (int)(statement_name - statement), statement, lidar_name);
            ls->last_report_time = now;
            ls->last_gprmc_status = 2;
        }
        return;
    }

    // check for valid statement
    const char* statement_end = statement + 7;
    while(*statement_end != '\0' && *statement_end != ',') {
        ++statement_end;
    }

    if(statement_end[0] != ',' && statement_end[1] != 'A') {
        if(ls->last_gprmc_status != 1 || now - ls->last_report_time > std::chrono::seconds(5)) {
            log_warning("velodyne lidar %s report a $GPRMC with invalid status ", lidar_name);
            ls->last_report_time = now;
            ls->last_gprmc_status = 1;
        }
        return;
    }

    ls->last_gprmc_status = 0;
    if(!previous_ok) {
        log_info("lidar %s has available pps and $GPRMC", lidar_name);
    }
}


static void velodyne_position_listener_thread(velodyne_position_listener* listener) {
    while(!listener->should_stop) {
        char buff[1500];
        sockaddr_in addr;
        socklen_t addr_len = sizeof(addr);
        int recv_length = recvfrom(listener->listen_fd, buff, sizeof(buff), 0, (sockaddr*)&addr, &addr_len);
        if(recv_length < 0) {
            log_error("cannot recv velodyne packet: %s\n", strerror(errno));
            continue;
        }

        char lidar_ipaddr[32];
        sprintf(lidar_ipaddr, "%d.%d.%d.%d", 
            addr.sin_addr.s_addr & 0xff, 
            (addr.sin_addr.s_addr >> 8) & 0xff, 
            (addr.sin_addr.s_addr >> 16) & 0xff, 
            (addr.sin_addr.s_addr >> 24) & 0xff);
        report_status* ptr = &listener->lidar_status[lidar_ipaddr];
        parse_velodyne_position_packet(lidar_ipaddr, buff, recv_length, ptr);
    }
}

static velodyne_position_listener* listener = nullptr;

static void velodyne_listener_cleanup(void* args) {
    if(listener) {
        listener->should_stop = true;
        listener->listen_thread.join();
        close(listener->listen_fd);
        delete listener;
        listener = nullptr;
    }
}

static void __startup_listener() {
    listener = new velodyne_position_listener;

    // create fd listen udp on 8308
    listener->listen_fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(listener->listen_fd < 0) {
        log_error("cannot create socket for velodyne packet: %s\n", strerror(errno));
        delete listener;
        return;
    }

    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(8308);
    addr.sin_addr.s_addr = INADDR_ANY;

    if(bind(listener->listen_fd, (sockaddr*)&addr, sizeof(addr)) < 0) {
        log_error("cannot bind socket on :8308 for velodyne packet: %s\n", strerror(errno));
        delete listener;
        return;
    }

    listener->available_capture_count = 0;
    listener->should_stop = false;
    listener->listen_thread = std::thread(velodyne_position_listener_thread, listener);

    add_cleanup(&velodyne_listener_cleanup, nullptr);
}

static void startup_listener() {
    static std::once_flag flag;
    std::call_once(flag, __startup_listener);
}



struct udp_capture : capture_source {

    int fd;

    virtual ~udp_capture() override {
        close(fd);
    }

    virtual void start() override {

    }

    virtual void stop() override {

    }

    virtual waitable_object get_waitable_object() override {
        return fd;
    }

    virtual result_of<byte_buffer, std::string> capture() override {
        byte_buffer buff { byte_storage::create(1500) };
        int recv_length = recvfrom(fd, buff.data(), buff.size(), 0, nullptr, nullptr);
        if(recv_length < 0) {
            return fail(strerror(errno));
        }
        buff.shrink(recv_length);
        return ok(buff);
    }

};

static bool is_port_string(const char* str) {
    while(*str) {
        if(*str < '0' || *str > '9') {
            return false;
        }
        str++;
    }
    return true;
}

template<typename capture_type>
struct udp_capture_factory : capture_factory {
    virtual ~udp_capture_factory() override {

    }

    virtual result_of<capture_source*, std::string> create_capture_source(const char* init_string) override {
        const char* p = config_get("no-velodyne-position", "false");
        if(strcmp(p, "true") != 0) {
            log_debug("start velodyne position listener");
            startup_listener();
        }
        
        int port = atoi(init_string);

        int fd = socket(AF_INET, SOCK_DGRAM, 0);
        if(fd < 0) {
            return fail(string_format("cannot create socket : %s", strerror(errno)));
        }

        sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_port = htons(port);
        addr.sin_addr.s_addr = INADDR_ANY;

        if(bind(fd, (sockaddr*)&addr, sizeof(addr)) < 0) {
            return fail(string_format("cannot bind socket : %s", strerror(errno)));
        }

        capture_type* ret = new capture_type();
        ret->fd = fd;
        return ok(ret);
    }

    virtual bool check_init_string(const char* init_string) override {
        return is_port_string(init_string);
    }
};


struct velodyne16_capture : udp_capture {
    virtual type_id get_type() const override {
        return Velodyne16;
    }
};

struct velodyne32_capture : udp_capture {
    virtual type_id get_type() const override {
        return Velodyne32;
    }
};

struct velodyne16_factory : udp_capture_factory<velodyne16_capture> {
    virtual const capture_device& get_device() const override {
        static capture_device ret = {
            "velodyne16",
            "velodyne16 init_string: <udp port>",
            "Velodyne VLP-16"
        };
        return ret;
    }
};

struct velodyne32_factory : udp_capture_factory<velodyne32_capture> {
    virtual const capture_device& get_device() const override {
        static capture_device ret = {
            "velodyne32",
            "velodyne32 init_string: <port>",
            "Velodyne HDL-32"
        };
        return ret;
    }
};


__attribute__((constructor))
static void __velodyne_capture_init__() {
    register_type("velodyne16", Velodyne16);
    register_type("velodyne32", Velodyne32);

    register_capture_factory(new velodyne16_factory());
    register_capture_factory(new velodyne32_factory());
    
    set_configable_flags(config_range::app_capture, "no-velodyne-position", "disable velodyne position listener(if no pps signal, use this)");
}

