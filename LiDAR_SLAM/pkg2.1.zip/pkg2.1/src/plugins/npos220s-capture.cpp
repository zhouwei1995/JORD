#include <unistd.h>
#include <termios.h>
#include <string.h>
#include <fcntl.h>

#include "npos220s-base.h"

result_of<int, std::string> open_serial(const char* dev) 
{
    int fd = open(dev, O_RDONLY | O_NOCTTY);
    if(fd < 0) {
        return fail(strerror(errno));
    }

    struct termios options;
    tcgetattr(fd, &options);
    // 115200, 8N1

    options.c_cflag = (options.c_cflag & ~CSIZE) | CS8;
    options.c_iflag &= ~IGNBRK;
    options.c_lflag = 0;
    options.c_oflag = 0;
    options.c_cc[VMIN] = 10;
    options.c_cc[VTIME] = 0;


    cfsetospeed(&options, B115200);

    options.c_cflag |= (CLOCAL | CREAD);
    options.c_cflag &= ~(PARENB | PARODD);
    options.c_cflag &= ~CSTOPB;
    options.c_cflag &= ~CRTSCTS;

    if (tcsetattr(fd, TCSANOW, &options) != 0) {
        return fail(strerror(errno));
    }

    return ok(fd);
}

struct serial_capture_source : capture_source {
    
    int serial_fd;

    ~serial_capture_source() override {
        close(serial_fd);
    }

    virtual void start() override  {
        
    }

    virtual void stop() override {

    }

    virtual waitable_object get_waitable_object() {
        return serial_fd;
    }

    virtual result_of<byte_buffer, std::string> capture() {
        byte_buffer buff { byte_storage::create(1500) };
        int recv_length = read(serial_fd, buff.data(), buff.size());
        if(recv_length < 0) {
            if(errno == EAGAIN || errno == EINTR)   
            {
                buff.shrink(0);
                return ok(buff);
            }
            return fail(strerror(errno));
        }
        buff.shrink(recv_length);
        return ok(buff);
    }

    virtual type_id get_type() const {
        return npos220s;
    }

};

struct serial_capture_factory : capture_factory {
    virtual ~serial_capture_factory() override {

    }

    virtual result_of<capture_source*, std::string> create_capture_source(const char* init_string) override {
        auto fd = open_serial(init_string);
        if(!fd.ok()) {
            return fail(fd.error());
        }
        serial_capture_source* source = new serial_capture_source();
        source->serial_fd = fd.value();
        return ok(source);
    }

    virtual bool check_init_string(const char* init_string) override {
        return true;
    }

    virtual const capture_device& get_device() const override {
        static capture_device device = {
            "npos220s",
            "npos220s init_string: serial port(dev/ttyS0, dev/ttyUSB0, ...)",
            "npos220s device"
        };
        return device;
    }
};

__attribute__((constructor))
static void register_factory() {
    register_type("npos220s", npos220s);
    register_capture_factory(new serial_capture_factory());
}
