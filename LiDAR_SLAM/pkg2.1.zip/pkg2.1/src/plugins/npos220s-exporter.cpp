#include "npos220s-base.h"
#include <pkg2_type.h>
#include <stdio.h>
#include <service/misc.h>
#include <string.h>
#include <filesystem>

struct npos220s_exporter_base : exporter {
    FILE* file_gps;
    FILE* file_imu;
    int gpsc = 0, imuc = 0;
    time_point last_time_point = time_point::min();

    char gps_filename[1024];
    char imu_filename[1024];

    npos220s_rawimu last_exported_imu = { 0 };
    npos220s_exporter_base(const char* export_dir, const char* init_string) {
        while(*init_string == '/') init_string++;
        if(*init_string == 0) {
            log_warning("npos220s_exporter_xyz: empty init string! use default(npos220s)");
            init_string = "npos220s";
        }
        snprintf(gps_filename, sizeof(gps_filename), "%s/gps_%s", export_dir, init_string);
        file_gps = fopen(gps_filename, "w");
        if(file_gps == nullptr) {
            log_warning("npos220s_exporter_xyz: failed to open file %s, %s", gps_filename, strerror(errno));
        }

        snprintf(imu_filename, sizeof(imu_filename), "%s/imu_%s", export_dir, init_string);
        file_imu = fopen(imu_filename, "w");
        if(file_imu == nullptr) {
            log_warning("npos220s_exporter_xyz: failed to open file %s: %s", imu_filename, strerror(errno));
        }
    }

    ~npos220s_exporter_base() override {
        if(file_gps != nullptr) {
            fclose(file_gps);
        }
        if(file_imu != nullptr) {
            fclose(file_imu);
        }
    }

    virtual void export_data(translated_value* value) override {
        if(value == nullptr || value->id != npos220s_tr) {
            return;
        }

        auto tr = static_cast<npos220s_trvalue*>(value);
        
        for(const auto& item : tr->value) {
            if(last_time_point == time_point::min()) {
                last_time_point = item.time;
            }

            if(item.time - last_time_point > std::chrono::seconds(1)) {
                log_warning("npos220s_exporter: time gap too large, previous data will be dropped");

                // reopen files
                if(file_gps != nullptr) {
                    fclose(file_gps);
                }
                if(file_imu != nullptr) {
                    fclose(file_imu);
                }

                std::filesystem::remove(gps_filename);
                std::filesystem::remove(imu_filename);

                file_gps = fopen(gps_filename, "w");
                if(file_gps == nullptr) {
                    log_warning("npos220s_exporter_xyz: failed to open file %s: %s", gps_filename, strerror(errno));
                }

                file_imu = fopen(imu_filename, "w");
                if(file_imu == nullptr) {
                    log_warning("npos220s_exporter_xyz: failed to open file %s : %s", imu_filename, strerror(errno));
                }

                gpsc = imuc = 0;
            }

            switch(item.type) {
            case npos220s_value_type::RAWIMU:
                export_imu(item.time.time_since_epoch().count() / 1e9, item.rawimu, imuc == 0);
                imuc++;
                break;
            case npos220s_value_type::INSPVAXA:
                export_gps(item.time.time_since_epoch().count() / 1e9, item.inspvaxa, gpsc == 0);
                gpsc++;
                break;
            default:
                break;
            }

            last_time_point = item.time;
        }
    }

    virtual void export_imu(double time, const npos220s_rawimu& imu, bool is_first) {
        if(file_imu == nullptr)
            return;
        if(!is_first && is_the_same(imu, last_exported_imu))
            return;
        last_exported_imu = imu;
        fprintf(file_imu, "%lf,%f,%f,%f,%f,%f,%f\n", 
            time,
            imu.ax,
            imu.ay,
            imu.az,
            imu.gx,
            imu.gy,
            imu.gz);
    } 

    virtual void export_gps(double time, const npos220s_inspvaxa& msg, bool) {
        if(file_gps == nullptr)
            return;
        fprintf(file_gps, "%lf,%lf,%lf,%lf,%f,%f,%f,%f,%f,%f\n",
            time,
            msg.latitude,
            msg.longitude,
            msg.altitude,
            msg.roll,
            msg.pitch,
            msg.heading,
            msg.cov_x,
            msg.cov_y,
            msg.cov_z);
    }

    static bool fequal(float a, float b) {
        return fabs(a - b) < 1e-6;
    }

    bool is_the_same(const npos220s_rawimu& a, const npos220s_rawimu& b) {
        return fequal(a.ax, b.ax) && fequal(a.ay, b.ay) && fequal(a.az, b.az) &&
            fequal(a.gx, b.gx) && fequal(a.gy, b.gy) && fequal(a.gz, b.gz);
    }
};


struct npos220s_exporter_xyz : npos220s_exporter_base {
    origin_info origin;

    npos220s_exporter_xyz(const char* export_dir, const char* init_string) : npos220s_exporter_base(export_dir, init_string) {
    }

    virtual void export_gps(double time, const npos220s_inspvaxa& msg, bool is_first) override {
        if(is_first) {
            wgs84_to_ecef(msg.latitude, msg.longitude, msg.altitude, &origin.ecef_x, &origin.ecef_y, &origin.ecef_z);
        }
        double x,y,z;
        wgs84_to_local_tangent(&origin, msg.latitude, msg.longitude, msg.altitude, &x, &y, &z);

        if(file_gps == nullptr)
            return;
        fprintf(file_gps, "%lf,%lf,%lf,%lf,%f,%f,%f,%f,%f,%f\n",
            time,
            x,
            y,
            z,
            msg.roll,
            msg.pitch,
            msg.heading,
            msg.cov_x,
            msg.cov_y,
            msg.cov_z);
    }
};

using npos220s_exporter_fix = npos220s_exporter_base;

struct npos220s_exporter_factory : exporter_factory {
    virtual ~npos220s_exporter_factory() = default;

    virtual exporter* create_exporter(const char* export_dir, const char* init_string) override {
        const char* type = config_get("npos220s-exporter-type", "fix");
        if(strcmp(type, "fix") == 0)
            return new npos220s_exporter_fix(export_dir, init_string);
        else if(strcmp(type, "xyz") == 0)
            return new npos220s_exporter_xyz(export_dir, init_string);
        log_warning("npos220s_exporter: unknown type %s, use default(fix)", type);
        return new npos220s_exporter_fix(export_dir, init_string);
    }

    virtual exporter_descriptor get_descriptor() const override {
        return exporter_descriptor {
            .name = "npos220s_exporter",
            .target_type = npos220s_tr
        };
    }
};

__attribute__((constructor)) static void npos220s_exporter_init() {
    register_exporter_factory(new npos220s_exporter_factory());

    set_configable_value(config_range::app_export, "npos220s-exporter-type", "type", "select data type, canbe fix(default)/xyz");
}
