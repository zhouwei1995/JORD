#include <pkg2_type.h>
#include "v4l2-base.h"
#include <filesystem>
#include <stdio.h>
#include <service/misc.h>
#include <string.h>

struct jpeg_exporter : exporter {

    std::string export_suffix;
    size_t exported_id = 0;
    FILE* timestamp_file = nullptr;

    jpeg_exporter(const char* export_dir, const char* init_string) {
        char buf[1024];
        snprintf(buf, sizeof(buf), "%s/%s", export_dir, init_string);
        std::error_code ec;
        if(!std::filesystem::create_directories(buf, ec)) {
            log_warning("jpeg_exporter: failed to create directory %s", buf);
        }
        export_suffix = buf;

        snprintf(buf, sizeof(buf), "%s/%s_timestamp.txt", export_dir, init_string);
        timestamp_file = fopen(buf, "w");
        if(timestamp_file == nullptr) {
            log_warning("jpeg_exporter: failed to open file %s: %s", buf, strerror(errno));
        }
    }
    
    virtual ~jpeg_exporter() {
        if(timestamp_file != nullptr) {
            fclose(timestamp_file);
        }
    }

    virtual void export_data(translated_value* value) override {
        if(value->id != JPEG) {
            log_warning("jpeg_exporter: wrong point type");
        }

        auto tr = static_cast<string_translated_value*>(value);

        char buffer[1024];
        snprintf(buffer, sizeof(buffer), "%s/%zu.jpg", export_suffix.c_str(), exported_id++);

        FILE* file = fopen(buffer, "wb");
        if(file == nullptr) {
            log_warning("jpeg_exporter: failed to open file %s, %s", buffer, strerror(errno));
            return;
        }

        size_t writted = fwrite(tr->value.data(), 1, tr->value.size(), file);
        if(writted != tr->value.size()) {
            log_warning("jpeg_exporter: failed to write file %s, %s", buffer, strerror(errno));
        }
        fclose(file);

        if(timestamp_file != nullptr) {
            fprintf(timestamp_file, "%zu %ld\n", exported_id, tr->time.time_since_epoch().count());
        }
    }
};

struct jpeg_exporter_factory : exporter_factory {
    virtual exporter* create_exporter(const char* export_dir, const char* init_string) override {
        return new jpeg_exporter(export_dir, init_string);
    }

    virtual exporter_descriptor get_descriptor() const override {
        return exporter_descriptor {
            .name = "jpeg",
            .target_type = JPEG
        };
    }
};

__attribute__((constructor)) static void jpeg_exporter_init() {
    register_exporter_factory(new jpeg_exporter_factory());
}
