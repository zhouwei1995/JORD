#include "pkg2_type.h"
#include <stdarg.h>
#include <service/misc.h>

template<typename T>
auto vector_for_type() -> std::vector<T>& {
    static std::vector<T> ret;
    return ret;
}

void register_capture_factory(capture_factory* factory)
{
    auto& factories = vector_for_type<capture_factory*>();
    factories.push_back(factory);
}

capture_factory* find_capture_factory(const char* name) {
    auto& factories = vector_for_type<capture_factory*>();
    for(auto f : factories) {
        if(f->get_device().command_line == name)
            return f;
    }
    return nullptr;
}

std::vector<capture_factory*> get_capture_devices() {
    return vector_for_type<capture_factory*>();
}


void register_translator_factory(translator_factory* factory) {
    auto& factories = vector_for_type<translator_factory*>();
    factories.push_back(factory);
}

translator_factory* find_translator_factory(type_id source_type, const char* tag) {
    std::vector<translator_factory*> candidates;
    std::vector<translator_factory*>& translators = vector_for_type<translator_factory*>();
    for(int i = 0; i < translators.size(); ++i) {
        auto desc = translators[i]->get_descriptor();
        if(desc.source_type == source_type) {
            candidates.push_back(translators[i]);

            if(desc.tag == tag) {
                return translators[i];
            }
        }
    }

    if(candidates.size() == 1) {
        return candidates[0];
    }

    if(candidates.size() == 0) {
        log_warning("no translator for (%s, %s)", get_type_name(source_type), tag);
        return nullptr;
    }

    log_warning("ambiguous translator (%s, %s)", get_type_name(source_type), tag);
    log_info("candidates:");
    for(auto c : candidates) {
        log_info("  %s(%s)", c->get_descriptor().name.c_str(), c->get_descriptor().tag.c_str());
    }

    log_info("%s is selected", candidates[0]->get_descriptor().name.c_str(), candidates[0]->get_descriptor().tag.c_str());
    return candidates[0];
}

void register_player_factory(player_factory* factory)
{
    auto& factories = vector_for_type<player_factory*>();
    factories.push_back(factory);
}

player_factory* find_player_factory(type_id target_type) {
    auto& factories = vector_for_type<player_factory*>();
    for(int i = 0; i < factories.size(); ++i) {
        if(factories[i]->get_descriptor().target_type == target_type)
            return factories[i];
    }
    return nullptr;
}

struct type_info {
    type_id id;
    std::string name;
    bool custom;
};


void register_type(const char* name, type_id id, bool custom) {
    auto& types = vector_for_type<type_info>();

    // check for duplicates
    for(int i = 0; i < types.size(); ++i) {
        if(types[i].id == id) {
            log_fatal("duplicate type id %d", id);
            exit(1);
        }
        if(types[i].name == name) {
            log_fatal("duplicate type name %s", name);
            exit(1);
        }
    }

    types.push_back({id, name, custom});
}

const char* get_type_name(type_id id)
{
    auto& rtypes = vector_for_type<type_info>();
    for(int i = 0; i < rtypes.size(); ++i) {
        if(rtypes[i].id == id)
            return rtypes[i].name.c_str();
    }
    return "unknown";
}

type_id get_type_id(const char* name)
{
    auto& rtypes = vector_for_type<type_info>();
    for(int i = 0; i < rtypes.size(); ++i) {
        if(rtypes[i].name == name)
            return rtypes[i].id;
    }
    return 0;
}

bool is_custom_type(type_id id)
{
    auto& rtypes = vector_for_type<type_info>();
    for(int i = 0; i < rtypes.size(); ++i) {
        if(rtypes[i].id == id)
            return rtypes[i].custom;
    }
    return false;
}


std::string string_format(const char* format, ...) {
    va_list args;
    va_start(args, format);
    size_t size = vsnprintf(nullptr, 0, format, args) + 1;
    va_end(args);
    std::string result(size, '\0');
    va_start(args, format);
    vsnprintf(result.data(), size , format, args);
    va_end(args);
    result.resize(size - 1);
    return result;
}

void register_translated_type(const char* name, type_id id) {
    register_type(name, id);
}


void register_exporter_factory(exporter_factory* factory)
{
    auto& factories = vector_for_type<exporter_factory*>();
    factories.push_back(factory);
}

exporter_factory* find_exporter_factory(type_id target_type) {
    auto& factories = vector_for_type<exporter_factory*>();
    for(int i = 0; i < factories.size(); ++i) {
        if(factories[i]->get_descriptor().target_type == target_type)
            return factories[i];
    }
    return nullptr;
}
