#ifndef __TYPE_H__
#define __TYPE_H__

#include <string>
#include <chrono>
#include <vector>

#include <utils/result_of>
#include <utils/buffer>

using type_id = unsigned int;

void register_type(const char* name, type_id id, bool custom = false);
const char* get_type_name(type_id id);
type_id get_type_id(const char* name);
bool is_custom_type(type_id id);

using waitable_object = int;

struct capture_source {
    virtual ~capture_source() = default;

    virtual void start() = 0;
    virtual void stop() = 0;

    virtual waitable_object get_waitable_object() = 0;
    virtual result_of<byte_buffer, std::string> capture() = 0;

    virtual type_id get_type() const = 0;
};

struct capture_device {
    std::string command_line;
    std::string command_line_description;
    std::string name;
};

struct capture_factory {
    virtual ~capture_factory() = default;

    virtual result_of<capture_source*, std::string> create_capture_source(const char* init_string) = 0;
    virtual bool check_init_string(const char* init_string) = 0;

    virtual const capture_device& get_device() const = 0;
};

void register_capture_factory(capture_factory* factory);

capture_factory* find_capture_factory(const char* name);
std::vector<capture_factory*> get_capture_devices();

struct translated_value {
    type_id id;
    virtual ~translated_value() = default;
};

void register_translated_type(const char* name, type_id id);

using time_point = std::chrono::system_clock::time_point;

struct translator {
    virtual ~translator() = default;

    virtual translated_value* translate(byte_buffer buff, time_point references_time) = 0;
};

struct translator_descriptor {
    std::string name;
    std::string tag;
    type_id source_type;
    type_id target_type;
};

struct translator_factory {
    virtual ~translator_factory() = default;

    virtual translator* create_translator(const char* init_string) = 0;
    virtual bool check_init_string(const char* init_string) = 0;

    virtual translator_descriptor get_descriptor() const = 0;
};

void register_translator_factory(translator_factory* factory);

translator_factory* find_translator_factory(type_id source_type, const char* tag);

struct player {
    virtual ~player() = default;

    virtual void play(translated_value* type) = 0;
};

struct player_descriptor {
    std::string name;
    type_id target_type;
};

struct player_factory {
    virtual ~player_factory() = default;

    virtual player* create_player(const char* init_string) = 0;
    virtual bool check_init_string(const char* init_string) = 0;

    virtual player_descriptor get_descriptor() const = 0;
};

void register_player_factory(player_factory* factory);

player_factory* find_player_factory(type_id target_type);

struct exporter {
    virtual ~exporter() = default;

    virtual void export_data(translated_value* value) = 0;
};

struct exporter_descriptor {
    std::string name;
    type_id target_type;
};

struct exporter_factory {
    virtual ~exporter_factory() = default;

    virtual exporter* create_exporter(const char* export_dir, const char* init_string) = 0;

    virtual exporter_descriptor get_descriptor() const = 0;
};

void register_exporter_factory(exporter_factory* factory);

exporter_factory* find_exporter_factory(type_id target_type);

#define REGISTER_CAPTURE_FACTORY(factory) \
    static struct ___register_capture_factory_##factory { \
        ___register_capture_factory_##factory() { \
            register_capture_factory(new factory()); \
        } \
    } ___register_capture_factory_##factory##_instance;

#define REGISTER_TRANSLATOR_FACTORY(factory) \
    static struct ___register_translator_factory_##factory { \
        ___register_translator_factory_##factory() { \
            register_translator_factory(new factory()); \
        } \
    } ___register_translator_factory_##factory##_instance;

#define REGISTER_PLAYER_FACTORY(factory) \
    static struct ___register_player_factory_##factory { \
        ___register_player_factory_##factory() { \
            register_player_factory(new factory()); \
        } \
    } ___register_player_factory_##factory##_instance;

#define REGISTER_TYPE(name, id) \
    static struct ___register_type_##id { \
        ___register_type_##id() { \
            register_type(name, id); \
        } \
    } ___register_type_##id##_instance;

std::string string_format(const char* format, ...);

#endif