#include <launch/subcommand.h>
#include <service/misc.h>
#include <utils/result_of>
#include <string.h>
#include <vector>
#include <memory>
#include <pkg2_type.h>
#include <map>
#include <set>
#include <filesystem>
#include <core/pkg2.h>

static void print_export_usage(const char *cmd)
{
    printf("usage : %s <pkg2 file> [options]... \n", cmd);
    printf("options : \n");
    printf("  -h, --help : print this message\n");
    printf("\t--point-type <type> : point types, XYZ XYZIRT XYZRGB XYZI(default)\n");
    printf("\t--topic <tag> : export messages with <tag>\n");
    printf("\t--output <dir> : export directory\n");
    printf("\t--yes, -y : remove existing directory\n");

    print_configable_values(config_range::app_export);
}

struct export_options
{
    std::string pkg2_file;
    std::string output_dir;
    std::string point_type;
    std::set<std::string> topics;
    bool yes = false;
    bool help = false;
};

std::string default_export_dir_from_pkg2(const std::string &pkg2_file)
{
    auto slash_pos = pkg2_file.find_last_of('/');
    auto pos = pkg2_file.find_last_of('.');
    if (pos == std::string::npos || slash_pos > pos)
    {
        return pkg2_file + "_export";
    }

    return pkg2_file.substr(0, pos) + "_export";
}

result_of<export_options, std::string> parse_export_args(int argc, const char *const *argv)
{
    export_options options;
    options.point_type = "XYZI";

    for (int i = 1; i < argc; i++)
    {
        if (strcmp(argv[i], "--point-type") == 0)
        {
            if (i + 1 >= argc)
            {
                return fail("missing argument for --point-type");
            }
            options.point_type = argv[++i];
        }
        else if (strcmp(argv[i], "--topic") == 0)
        {
            if (i + 1 >= argc)
            {
                return fail("missing argument for --topic");
            }
            options.topics.insert(argv[++i]);
        }
        else if (strcmp(argv[i], "--output") == 0)
        {
            if (i + 1 >= argc)
            {
                return fail("missing argument for --output");
            }
            options.output_dir = argv[++i];
        }
        else if (strcmp(argv[i], "--yes") == 0 || strcmp(argv[i], "-y") == 0)
        {
            options.yes = true;
        }
        else if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0)
        {
            if (argc == 2)
            {
                options.help = true;
                return ok(options);
            }
            else
            {
                return fail("--help or -h cannot combined with other options");
            }
        }
        else if (argv[i][0] == '-' && argv[i][1] == '-')
        {
            int r = config_check(config_range::app_export, argc - i, argv + i);
            if (r <= 0)
            {
                return fail(string_format("invalid argument for %s", argv[i]));
            }
            i += r - 1;
        }
        else
        {
            if (options.pkg2_file.empty())
            {
                options.pkg2_file = argv[i];
            }
            else
            {
                return fail(string_format("too many arguments (%s)!", argv[i]));
            }
        }
    }

    if (options.pkg2_file.empty())
    {
        return fail("missing pkg2 file");
    }

    if (options.output_dir.empty())
    {
        options.output_dir = default_export_dir_from_pkg2(options.pkg2_file);
    }

    return ok(options);
}

struct export_pipe
{
    std::shared_ptr<translator> tr;
    std::shared_ptr<exporter> ex;
};

struct pipes
{
    std::map<std::string, export_pipe> ps;
    std::set<std::string> failed_types;
    std::string point_type;
    std::string output_dir;
};

static void copy_init_string(char* buffer, size_t max_len, const char* tag) {
    if(tag == nullptr) {
        return;
    }

    while(tag[0] == '/') tag++;

    while(*tag != 0 && max_len > 1) {
        if(*tag == '/') {
            *buffer++ = '_';
            tag++;
        } else {
            *buffer++ = *tag++;
        }
        max_len--;
    }

    *buffer = 0;
}

static bool join_pipe(pipes &p, const char *tag, type_id type)
{
    if (p.failed_types.find(tag) != p.failed_types.end())
    {
        return false;
    }

    // create a new type
    auto trf = find_translator_factory(type, p.point_type.c_str());
    if (trf == nullptr)
    {
        log_warning("export: no translator for type %s", get_type_name(type));
        p.failed_types.insert(tag);
        return false;
    }

    auto exf = find_exporter_factory(trf->get_descriptor().target_type);
    if (exf == nullptr)
    {
        log_warning("export: no exporter for type %s", get_type_name(type));
        p.failed_types.insert(tag);
        return false;
    }

    char init_string[128];
    copy_init_string(init_string, sizeof(init_string), tag);

    auto tr = trf->create_translator("");
    auto ex = exf->create_exporter(p.output_dir.c_str(), init_string);

    p.ps[tag] = export_pipe{
        .tr = std::shared_ptr<translator>(tr),
        .ex = std::shared_ptr<exporter>(ex)};
    return true;
}

static void call_pipe(pipes &p, const char *tag, type_id type, time_point time, byte_buffer data)
{
    if (p.ps.find(tag) == p.ps.end() && !join_pipe(p, tag, type))
    {
        return;
    }

    auto &pipe = p.ps[tag];
    auto trv = pipe.tr->translate(data, time);
    if (trv != nullptr)
    {
        pipe.ex->export_data(trv);
        delete trv;
    }
}

static void init_pipes(pipes* p, const export_options& options)
{
    p->point_type = options.point_type;
    p->output_dir = options.output_dir;
}

static void destroy_pipes(pipes* p)
{
    p->ps.clear();
    p->failed_types.clear();
}


int export_main(int argc, const char* const * argv)
{
    export_options options;
    auto r = parse_export_args(argc, argv);
    if(!r.ok()) {
        log_error("%s", r.error().c_str());
        print_export_usage(argv[0]);
        return -1;
    }

    options = r.value();

    if(options.help) {
        print_export_usage(argv[0]);
        return 0;
    }

    if(std::filesystem::exists(options.output_dir)) {
        if(!options.yes) {
            log_error("output directory %s already exists, use --yes to overwrite", options.output_dir.c_str());
            return -1;
        }

        std::error_code ec;
        std::filesystem::remove_all(options.output_dir, ec);
        if(ec) {
            log_error("failed to remove directory %s: %s", options.output_dir.c_str(), ec.message().c_str());
            return -1;
        }
    }

    std::error_code ec;
    std::filesystem::create_directories(options.output_dir, ec);

    if(ec) {
        log_error("failed to create directory %s: %s", options.output_dir.c_str(), ec.message().c_str());
        return -1;
    }

    pipes p;
    init_pipes(&p, options);

    pkg2::pkg2_reader reader;
    auto result = reader.open(options.pkg2_file.c_str());
    if(result != pkg2::pkg2_error::success) {
        log_error("failed to open pkg2 file %s(%s)", options.pkg2_file.c_str(), pkg2::error_str(result));
        return -1;
    }

    for(auto [tag, type, time, data] : reader){
        if(should_stop())
            break;
        if(options.topics.empty() || options.topics.find(tag) != options.topics.end()) {
            time_point tp { std::chrono::microseconds(time) };
            call_pipe(p, tag, type, tp, data);
        }
    }

    reader.close();
    destroy_pipes(&p);
    return 0;
}

REGISTER_SUBCOMMAND(export, &export_main);
