#include <core/pkg2.h>
#include <launch/subcommand.h>
#include <set>

struct split_config {
    size_t form_seconds = 0;
    size_t to_seconds = (size_t) -1;
    std::set<std::string> topics;
    std::string input_bag_name;
    std::string output_bag_name;
};

static std::string create_output_bag_name(std::string input) {
    std::string output = input;
    if(output.find_last_of(".") != std::string::npos) {
        output.insert(output.find_last_of("."), "_split");
    } else {
        output += "_split.pkg2";
    }
    return output;
}

static void print_split_usage() {
    std::cout << "Usage: split <input_bag> [options]" << std::endl;
    std::cout << " options:" << std::endl;
    std::cout << "  -s, --start <milliseconds>  Start time of the split pkg2 file" << std::endl;
    std::cout << "  -e, --end <milliseconds>    End time of the split pkg2 file" << std::endl;
    std::cout << "  -t, --topic <name>     topic of the split pkg2 file" << std::endl;
    std::cout << "  -o, --output <name>    Output pkg2 file name" << std::endl;
    std::cout << "  -h, --help             Print this help message" << std::endl << std::endl; 
    std::cout << "Default output file name is <input_bag>_split.pkg2" << std::endl;
}

static int parse_split_argv(int argc, char *argv[], split_config &config) {
    for(int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if(argv[i][0] != '-') {
            config.input_bag_name = argv[i];
        } else if(arg == "-s" || arg == "--start") {
            if(i + 1 < argc) {
                config.form_seconds = std::stoi(argv[++i]);
            } else {
                std::cerr << "--start option requires one argument." << std::endl;
                print_split_usage();
                return -1;
            }
        } else if(arg == "-e" || arg == "--end") {
            if(i + 1 < argc) {
                config.to_seconds = std::stoi(argv[++i]);
            } else {
                std::cerr << "--end option requires one argument." << std::endl;
                print_split_usage();
                return -1;
            }
        } else if(arg == "-t" || arg == "--topic") {
            if(i + 1 < argc) {
                config.topics.insert(argv[++i]);
            } else {
                std::cerr << "--topic option requires one argument." << std::endl;
                print_split_usage();
                return -1;
            }
        } else if(arg == "-o" || arg == "--output") {
            if(i + 1 < argc) {
                config.output_bag_name = argv[++i];
            } else {
                std::cerr << "--output option requires one argument." << std::endl;
                print_split_usage();
                return -1;
            }
        } else if(arg == "-h" || arg == "--help") {
            print_split_usage();
            return 1;
        } else {
            if(config.input_bag_name.empty())
                config.input_bag_name = arg;
            else {
                std::cerr << "Unknown argument: " << arg << std::endl;
                print_split_usage();
                return -1;
            }
        }
    }
    if(config.input_bag_name.empty()) {
        std::cerr << "Bagfile name is required." << std::endl;
        print_split_usage();
        return -1;
    }
    if(config.to_seconds < config.form_seconds) {
        std::cerr << "End time must be greater than start time." << std::endl;
        print_split_usage();
        return -1;
    }

    if(config.output_bag_name.empty()) {
        config.output_bag_name = create_output_bag_name(config.input_bag_name);
    }
    return 0;
}

int split_main(int argc, const char* const * argv)
{
    split_config config;
    if(parse_split_argv(argc, (char**)argv, config) != 0)
        return -1;

    pkg2::pkg2_reader r(config.input_bag_name.c_str());
    if(r.is_open() == false) {
        std::cerr << "Failed to open " << config.input_bag_name << std::endl;
        return -1;
    }
    pkg2::pkg2_writter w(config.output_bag_name.c_str());
    size_t start_time = 0;
    for(const auto& [tag, type, time, data] : r) {
        if(start_time == 0) {
            start_time = time;
        }
        size_t stime = (time - start_time) / 1000;
        if(config.topics.empty() || config.topics.find(tag) != config.topics.end()) {
            if(stime >= config.form_seconds && stime <= config.to_seconds) {
                w.write_data(tag, type, time, data.data(), data.size());
            }
        }
        if(stime > config.to_seconds)
            break;
    }
    r.close();
    w.close();
    return 0;
}

REGISTER_SUBCOMMAND(split, &split_main);
