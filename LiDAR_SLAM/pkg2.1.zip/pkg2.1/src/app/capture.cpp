#include <string>
#include <utils/flags>
#include <utils/result_of>
#include <string.h>
#include <memory>
#include <pkg2_type.h>
#include <core/pkg2.h>
#include <launch/subcommand.h>
#include <service/misc.h>
#include <filesystem>

enum class action_flags {
    save,
    play,  
};

struct action_string {
    std::string capture_string;
    flags<action_flags> actions;
    std::string capture_tags;
};

static result_of<action_string, std::string> parse_action_string(const char* command_line) {
    const char *first_comma = strchr(command_line, ',');
    if (first_comma == nullptr) {
        return fail("invalid command line, no comma found\n");
    }

    auto device = std::string(command_line, first_comma);
    auto action = first_comma + 1;

    first_comma = strchr(action, ',');
    if (first_comma == nullptr) {
        first_comma = action + strlen(action);
    }

    flags<action_flags> action_flags;
    while (action != first_comma) {
        switch (*action) {
            case 'S':
            case 's':
                action_flags |= action_flags::save;
                break;
            case 'P':
            case 'p':
                action_flags |= action_flags::play;
                break;
        }
        action++;
    }

    if (*first_comma != ',') {
        return fail("invalid command line, no topic name found.\n");
    }

    std::string topic_name = first_comma + 1;
    if (topic_name.size() < 2) {
        return fail("invalid command line, topic name too short.\n");
    }
    
    action_string result;
    result.capture_string = device;
    result.actions = action_flags;
    result.capture_tags = topic_name;

    return ok(result);
}

struct capture_object {
    capture_factory* factory;
    std::string translator_tag;
    action_string action;
};

static std::string generate_time_filename() {
    time_t t = time(nullptr);
    char buf[64];
    strftime(buf, sizeof(buf), "%Y%m%d_%H%M%S.pkg2", localtime(&t));
    return {buf};
}

static void print_capture_usage(const char* command_name) {
    printf("usage: %s [options]... [<capture_name> <action_string>]...\n", command_name);
    printf("or     %s --help\n\r\n", command_name);
    printf("options:\n");
    printf("\t--point-type <XYZ|XYZIRT|XYZI|XYZRGB>  set point type\n");
    printf("\t--output <filename>  set output filename\n");
    printf("\t--help  print this message\n\n");
    printf("\t--yes, -y  force overwrite output file\n\n");

    print_configable_values(config_range::app_capture);

    printf("\n");
    printf("action_string: <capture_init>,<action>,<topic name>\n");
    printf("\tcapture_init: capture device specific initialization string\n");
    printf("\taction: S - save, P - play\n");
    printf("\ttopic name: name of the topic to capture\n\n");
    printf("capture_name:\n\n");
    auto capture_devices = get_capture_devices();
    for(auto var : capture_devices) {
        capture_device dev = var->get_device();
        printf("%s: %s\n", dev.command_line.c_str(), dev.name.c_str());
        printf("\t%s\n", dev.command_line_description.c_str());
        printf("\n");
    }
}


struct capture_configs {
    std::string output_filename;
    int livox_frametime;
    bool yes_mode;
    std::vector<capture_object> capture_objects;
};

static result_of<capture_configs, std::string>
    parse_capture_command_line(int argc, const char* const * argv) {
    capture_configs result;
    result.yes_mode = false;
    result.livox_frametime = 100;
    std::string translator_tag = "XYZI";

    if (argc < 2) {
        print_capture_usage(argv[0]);
        return ok(result);
    }

    for (int i = 1; i < argc; i++) {
        if(strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            if(argc == 2) {
                print_capture_usage(argv[0]);
                return ok(result);
            }
            return fail("invalid command line, --help or -h with capture request\n");
        } else if(strcmp(argv[i], "--point-type") == 0) {
            if (i + 1 >= argc) {
                return fail("invalid command line, no point type specified\n");
            }
            translator_tag = argv[i + 1];
            i++;
            continue;
        } else if(strcmp(argv[i], "--output") == 0 || strcmp(argv[i], "-o") == 0) {
            if (i + 1 >= argc) {
                return fail("invalid command line, no output filename specified\n");
            }
            if(result.output_filename != "") {
                return fail("invalid command line, output filename already specified\n");
            }
            result.output_filename = argv[i + 1];
            i++;
            continue;
        } else if(strcmp(argv[i], "--livox-frametime") == 0) {
            if (i + 1 >= argc) {
                return fail("invalid command line, no livox frametime specified\n");
            }
            result.livox_frametime = atoi(argv[i + 1]);
            i++;
            continue;
        } else if(strcmp(argv[i], "--yes") == 0 || strcmp(argv[i], "-y") == 0) {
            result.yes_mode = true;
            continue;
        } else if(argv[i][0] == '-' && argv[i][1] == '-') {
            int r = config_check(config_range::app_capture, argc - i, argv + i);
            if(r <= 0) {
                return fail(string_format("invalid command line, %s\n", argv[i]));
            }
            i += r - 1;
            continue;
        }

        auto factory = find_capture_factory(argv[i]);

        if(factory == nullptr) {
            return fail(string_format("unknown capture device: %s\n", argv[i]));
        }

        if(i + 1 >= argc) {
            return fail(string_format("invalid command line, no action string for %s\n", argv[i]));
        }
        auto parse_result = parse_action_string(argv[i + 1]);

        if(parse_result.ok()) {
            capture_object obj;
            obj.factory = factory;
            obj.action = parse_result.value();
            obj.translator_tag = translator_tag;
            result.capture_objects.push_back(obj);
        } else{
            return fail(string_format("invalid command line, %s\n", parse_result.error()));
        }
        i++;
    }

    return ok(result);
}

static void print_capture_error(const char* command_name, const char* error) {
    printf("%s: %s\n", command_name, error);
    printf("Try '%s --help' for more information.\n", command_name);
}

enum class capture_config_result {
    output_required,
    play_only,
    failed
};

static capture_config_result check_capture_config(capture_configs& config) {
    bool output = false;
    for(auto& obj : config.capture_objects) {
        if(obj.factory->check_init_string(obj.action.capture_string.c_str()) == false) {
            print_capture_error("capture", "invalid capture string");
            return capture_config_result::failed;
        }

        if(obj.action.actions & action_flags::save) {
            output = true;
        }
    }
    if(output && config.output_filename == "") {
        if(config.output_filename == "") {
            config.output_filename = generate_time_filename();
        } 
    }

    if(output) {
        return capture_config_result::output_required;
    } else {
        return capture_config_result::play_only;
    }
}

struct capture_pipe {
    std::string tag;
    type_id type;

    std::shared_ptr<capture_source> source;
    std::shared_ptr<translator> trans;
    std::shared_ptr<player> play;

    std::shared_ptr<pkg2::pkg2_writter> writter;
};

static result_of<std::vector<capture_pipe>, std::string> init_capture(capture_configs& config, std::shared_ptr<pkg2::pkg2_writter> writter) {
    std::vector<capture_pipe> pipes;
    for(auto& obj : config.capture_objects) {
        auto r = obj.factory->create_capture_source(obj.action.capture_string.c_str());
        if(!r.ok()) {
            return fail(r.error());
        }

        auto dev = r.value();
        type_id source_type = dev->get_type();

        if(is_custom_type(source_type)) {
            capture_pipe pipe;
            pipe.tag = obj.action.capture_tags;
            pipe.type = source_type;
            pipe.writter = writter;
            pipe.source.reset(dev);
            pipe.trans.reset();
            pipe.play.reset();
            pipes.emplace_back(std::move(pipe));
            continue;
        }

        auto tfactory = find_translator_factory(source_type, obj.translator_tag.c_str());
        if(tfactory == nullptr) {
            return fail("failed to find translator factory");
        }

        auto trans = tfactory->create_translator("");
        if(trans == nullptr) {
            return fail("failed to create translator");
        }

        auto pfactory = find_player_factory(tfactory->get_descriptor().target_type);
        if(pfactory == nullptr) {
            return fail("failed to find player factory");
        }

        auto play = pfactory->create_player(obj.action.capture_tags.c_str());

        if(play == nullptr) {
            return fail("failed to create player");
        }

        capture_pipe pipe;
        pipe.tag = obj.action.capture_tags;
        pipe.type = source_type;
        pipe.writter = writter;
        pipe.source.reset(dev);
        pipe.trans.reset(trans);
        pipe.play.reset(play);
        pipes.emplace_back(std::move(pipe));

    }

    return ok(std::move(pipes));
}

static bool call_pipe(const capture_pipe& pipe, time_point references_time) {
   auto capture_result = pipe.source->capture(); 
    if(!capture_result.ok()) {
        print_capture_error("capture", capture_result.error().c_str());
        return false;
    }
    auto buff = std::move(capture_result.value());
    if(buff.size() == 0) {
        return true;
    }
    
    if(pipe.writter != nullptr) {
        size_t time_ns = std::chrono::duration_cast<std::chrono::microseconds>(references_time.time_since_epoch()).count();
        pipe.writter->write_data(pipe.tag.c_str(), pipe.type, time_ns, (const char*)buff.data(), buff.size());
    }

    if(pipe.trans != nullptr && pipe.play != nullptr) {
        translated_value* tr = pipe.trans->translate(buff, references_time);
        
        if(tr == nullptr) {
            return true;
        }

        pipe.play->play(tr);
        delete tr;
    }

    return true;
}

static void check_timeout(const std::vector<capture_pipe>& pipes, std::vector<time_point>& act_time, time_point now) {
    assert(pipes.size() == act_time.size());
    for(size_t i = 0; i < pipes.size(); i++) {
        if(act_time[i] + std::chrono::seconds(10) < now) {
            log_warning("pipe %s timeout", pipes[i].tag.c_str());
            act_time[i] = now;
        }
    }
}

#include <memory>
#include <sys/epoll.h>
#include <unistd.h>

static void start_capture(const std::vector<capture_pipe>& pipes) {
    int epoll_fd = epoll_create1(0);
    std::vector<time_point> act_time;

    for(auto& pipe : pipes) {
        pipe.source->start();

        int fd = pipe.source->get_waitable_object();
        if(fd < 0) {
            log_warning("failed to get waitable object for source");
            return;
        }

        struct epoll_event event;
        event.events = EPOLLIN;
        event.data.u64 = &pipe - &pipes[0];
        if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, fd, &event) < 0) {
            log_warning("failed to add source to epoll");
            return;
        }

        act_time.push_back(std::chrono::system_clock::now());
    }

    struct epoll_event events[16];
    while(true) {
        int epoll_result = epoll_wait(epoll_fd, events, 16, 100);
        
        // stop_source
        if(should_stop()) {
            break;
        }

        if(epoll_result < 0) {
            if(errno == EINTR || errno == EAGAIN) {
                continue;
            }
            log_warning("epoll_wait failed, %s(%d)", strerror(errno), errno);
            break;
        }

        time_point now = std::chrono::system_clock::now();

        if(epoll_result == 0) {
            check_timeout(pipes, act_time, now);

            do_spin(0);

            continue;
        }


        for (int i = 0; i < epoll_result; i++) {
            auto& event = events[i];
            if(event.events & EPOLLIN) {
                if(!call_pipe(pipes[event.data.u64], now)) {
                    return;
                }
            }

            act_time[event.data.u64] = now;
        }

        check_timeout(pipes, act_time, now);

    }

    for(auto& pipe : pipes) {
        pipe.source->stop();
    }

    close(epoll_fd);

}

static void capture(capture_configs& config, std::shared_ptr<pkg2::pkg2_writter> writter) {
    init_capture(config, writter).then(start_capture).or_else([](const std::string& error) {
        print_capture_error("capture", error.c_str());
    });
}


static int capture_main(int argc, const char* const * argv) {
    auto parse_result = parse_capture_command_line(argc, argv);
    if(!parse_result.ok()) {
        print_capture_error("capture", parse_result.error().c_str());
        return 1;
    }

    auto config = parse_result.value();
    if(config.capture_objects.empty()) {
        return 0;
    }

    auto config_result = check_capture_config(config);
    std::shared_ptr<pkg2::pkg2_writter> writter = nullptr;

    if(config_result == capture_config_result::failed) {
        return 1;
    }

    if(config_result == capture_config_result::output_required) {
        writter.reset(new pkg2::pkg2_writter());
        if(!config.yes_mode && std::filesystem::exists(config.output_filename)) {
            print_capture_error("capture", "output file already exists, use --yes or -y to force overwrite");
            return 1;
        }
        auto error_code = writter->open(config.output_filename.c_str());
        if(error_code != pkg2::pkg2_error::success) {
            print_capture_error("capture", "failed to open output file");
            return 1;
        }
        log_debug("writing to %s", config.output_filename.c_str());
    }

    capture(config, writter);
    return 0;
}

static void print_free_options(int argc) {
    printf("--point-type --output --yes");
    if(argc == 0) {
        printf("--help ");
    }

    auto capture_factory = get_capture_devices();

    for(auto var : capture_factory) {
        printf("%s ", var->get_device().command_line.c_str());
    }
}

static int capture_bash_completion(int argc, const char* const * argv, const char* current) {
    if(argc == 0) {
        print_free_options(argc);
        return 0;
    }

    const char* print_content = nullptr;
    int xargs = 0;
    for(int i = 0; i < argc; i++) {
        if(xargs > 0) {
            xargs--;
            continue;
        }

        if(strcmp(argv[i], "--point-type") == 0) {
            print_content = "XYZ XYZI XYZIRT XYZRGB ";
            xargs = 1;
            continue;
        } else if(strcmp(argv[i], "--help") == 0) {
            print_content = nullptr;
            return 0;
        } else if(strcmp(argv[i], "--output") == 0) {
            print_content = "#filedir";
            xargs = 1;
        } else {
            print_content = nullptr;
            xargs = 1;
        }
    }

    if(xargs == 0) {
        print_free_options(argc);
    } else if(print_content != nullptr) {
        printf("%s", print_content);
    }
    return 0;
}

REGISTER_SUBCOMMAND2(capture, &capture_main, &capture_bash_completion);

