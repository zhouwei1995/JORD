#include <launch/subcommand.h>
#include <pkg2_type.h>
#include <core/pkg2.h>

#include <fstream>
#include <map>
#include <service/misc.h>

static void print_time(size_t us) {
    struct tm t{};
    auto tt = time_t(us / 1000000);
    localtime_r(&tt, &t);
    printf("%04d-%02d-%02d %02d:%02d:%02d.%03lu(%lu.%03lu)", t.tm_year + 1900, t.tm_mon + 1, t.tm_mday, t.tm_hour, t.tm_min, t.tm_sec, us % 1000, us/1000, us % 1000);
}

static void print_duration(size_t us) {
    auto sec = (us / 1000000) ;
    auto min = sec / 60;
    auto hour = min / 60;

    if(hour > 0) {
        printf("%luhr %lumin %lus(%lus)", hour, min % 60, sec % 60, sec);
    } else if(min > 0) {
        printf("%lumin %lus(%lus)", min, sec % 60, sec);
    } else {
        printf("%lus", sec);
    }
}

static int info_command(int argc, const char* const* argv) {
    if(argc < 2) {
        log_info("usage: %s <pkg2 file>", argv[0]);
        return -1;
    }

    pkg2::pkg2_reader reader;
    auto err = reader.open(argv[1]);
    if(err != pkg2::pkg2_error::success) {
        log_error("cannot open : %s : %s", argv[1], pkg2::error_str(err));
        return -1;
    }
    if(reader.info.has_value()) {
        auto& info = reader.info.value();
        printf("File name: %s\n", argv[1]);
        printf("Start: ");
        print_time(info.min_time);
        printf("\nEnd: ");
        print_time(info.max_time);
        printf("\nDuration: ");
        print_duration(info.max_time - info.min_time);
        printf("\n tags:\n");

        for(size_t i = 0 ; i< info.tag_messages.size(); ++i){
            printf("\t%s: %s\n", reader.items[i]->tag_name, get_type_name(reader.items[i]->type_id));
        }
        printf("\n messages counts:\n");
        for(size_t i = 0 ; i< info.tag_messages.size(); ++i) {
            printf("\t%s: %zd\n", reader.items[i]->tag_name, info.tag_messages[i]);
        }
        return 0;
    }
    log_warning("\033[33m package %s is missing info block or not seekable. so we need to read all the data in the package.\nthis may take a while.\033[0m\n", argv[1]);
    std::map<std::string, int> tag_types;
    std::map<std::string, size_t> tag_count;

    size_t start_time = 0, end_time = 0;
    size_t block_count = 0;

    for(auto [tag, type, time, data] : reader){
        if(start_time == 0)
            start_time = time;
        end_time = std::max(time, end_time);
        tag_types[tag] = (int)type;
        tag_count[tag]++;  
        block_count++;
    }

    printf("File name: %s\n", argv[1]);
    printf("Start: ");
    print_time(start_time);
    printf("\nEnd: ");
    print_time(end_time);
    printf("\nDuration: ");
    print_duration(end_time - start_time);
    printf("\n tags:\n");
    for(auto [tag, type] : tag_types){
        printf("\t%s: %s\n", tag.c_str(), get_type_name(type));
    }

    printf("\n messages:\n");
    for(auto [tag, count] : tag_count){
        printf("\t%s: %zd\n", tag.c_str(), count);
    }

    return 0;
}

static int info_bash_completion(int argc, const char* const* argv, const char* current) {
    if(argc == 0) {
        printf("#filedir");
    }
    return 0;
}

REGISTER_SUBCOMMAND2(info, &info_command, &info_bash_completion);
