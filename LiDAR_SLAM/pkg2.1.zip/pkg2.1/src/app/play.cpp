#include <string>
#include <map>
#include <set>
#include <core/pkg2.h>
#include <utils/result_of>
#include <termios.h>
#include <chrono>
#include <thread>
#include <launch/subcommand.h>
#include <pkg2_type.h>
#include <memory>
#include <service/misc.h>
#include <filesystem>

static void print_usage(const char* cmd) {
    printf("usage : %s <pkg2 file> [options]... \n", cmd);
    printf("options : \n");
    printf("  -h, --help : print this message\n");
    printf("\t--point-type <topic> : subscribe to topic\n");
    printf("\t--exclude <tag> : don't play messages with <tag>\n");
    printf("\t--rename <tag> <topic> : rename <tag> to <topic>\n");
    printf("\t--speed <speed> play speed\n");
    print_configable_values(config_range::app_play);
}

struct play_config {
    std::string pkg2_file;
    std::string point_type;

    std::map<std::string, std::string> rename;
    std::set<std::string> exclude;

    double speed = 1.0;
    int livox_frametime = 0;
};

static result_of<play_config, std::string> parse_play_config(int argc, const char* const* argv) {
    play_config ret;

    for(int i = 1; i < argc; ++i) {
        if(strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            print_usage(argv[0]);
            if(argc != 2) {
                return fail("too many arguments");
            }
            return ok(ret);
        } else if(strcmp(argv[i], "--point-type") == 0) {
            if(i + 1 >= argc) {
                return fail("missing argument for --point-type");
            }
            ret.point_type = argv[++i];
        } else if(strcmp(argv[i], "--exclude") == 0) {
            if(i + 1 >= argc) {
                return fail("missing argument for --exclude");
            }
            ret.exclude.insert(argv[++i]);
        } else if(strcmp(argv[i], "--rename") == 0) {
            if(i + 2 >= argc) {
                return fail("missing argument for --rename");
            }
            ret.rename[argv[i + 1]] = argv[i + 2];
            i += 2;
        } else if(strcmp(argv[i], "--speed") == 0) {
            if(i + 1 >= argc) {
                return fail("missing argument for --speed");
            }
            ret.speed = atof(argv[++i]);
        } else if(argv[i][0] == '-' && argv[i][1] == '-') {
            int r = config_check(config_range::app_play, argc - i, argv + i) ;
            // for --clock , pkg2 do not support.

            if (strcmp(argv[i], "--clock") == 0)
            {
                log_error("pkg2和bag包不一样, 他不支持--clock参数。而且我目前不知道该怎么实现这个--clock.");
            }
            
            if (r <= 0) {
                return fail(string_format("invalid argument %s", argv[i]));
            }
            i += r - 1;
        } else {
            if(ret.pkg2_file.empty()) {
                ret.pkg2_file = argv[i];
            } else {
                return fail("too many arguments");
            }
        }
    }

    if(ret.pkg2_file.empty()) {
        return fail("missing pkg2 file");
    }

    if(ret.point_type.empty()) {
        ret.point_type = "XYZI";
    }

    return ok(ret);
}

struct terminal {
    fd_set __stdin_fd;
    int __max_fd ;
};

static void terminal_init(terminal* t) {
    const int fd = fileno(stdin);
    termios flags, orig_flags_;
    tcgetattr(fd, &orig_flags_);
    flags = orig_flags_;
    flags.c_lflag &= ~ICANON;      // set raw (unset canonical modes)
    flags.c_cc[VMIN]  = 0;         // i.e. min 1 char for blocking, 0 chars for non-blocking
    flags.c_cc[VTIME] = 0;         // block if waiting for char
    tcsetattr(fd, TCSANOW, &flags);

    FD_ZERO(&t->__stdin_fd);
    FD_SET(fd, &t->__stdin_fd);
    t->__max_fd = fd + 1;
}

static char read_from_terminal(terminal* t) {
    fd_set stdin_fd = t->__stdin_fd;

    timeval timeout;
    timeout.tv_sec = 0;
    timeout.tv_usec = 0;

    int ret = select(t->__max_fd, &stdin_fd, NULL, NULL, &timeout);
    if (ret == 0) {
        return 0;
    } else if (ret < 0) {
        return -1;
    } else {
        return getchar();
    }
}

struct play_control {
    using time_point = std::chrono::system_clock::time_point;

    time_point start_play_time, last_report_time;
    size_t offset;
    terminal t;
};

static void pc_start(play_control* control) {
    control->start_play_time = std::chrono::system_clock::now();
    control->last_report_time = control->start_play_time - std::chrono::seconds(100);
    control->offset = 0;

    terminal_init(&control->t);
}

static bool pc_pause(play_control* control) {
    auto start_pause_time = std::chrono::system_clock::now();
    printf("[PAUSED] ....................\r\n");
    while(!should_stop()) {
        switch(read_from_terminal(&control->t)) {
        case ' ': // do pause
            goto __resume;
        }
        do_spin(10);
    }

    return false;
__resume:
    printf("[RESUME] ....................\r\n");
    auto end_pause_time = std::chrono::system_clock::now();
    auto duration_us = std::chrono::duration_cast<std::chrono::microseconds>(end_pause_time - start_pause_time); 
    control->offset -= duration_us.count();
    return true;
}

static bool pc_spin(play_control* control) {
    switch(read_from_terminal(&control->t)) {
    case ' ': // do pause
        if(!pc_pause(control))
            return false;
        break;
    }
    do_spin(0);
    return true;
}

static bool pc_control(play_control* control, size_t time, float speed) {
    if(control->offset == 0) {
        control->offset = time;
    }
    auto sched_play_time = control->start_play_time + std::chrono::microseconds((size_t)((float)(time - control->offset) / speed));
    auto now = std::chrono::system_clock::now();
     if (sched_play_time > now) {
        while (sched_play_time - now > std::chrono::milliseconds(10)) {
            if(!pc_spin(control))
                return false;
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
            now = std::chrono::system_clock::now();
        }
        if (sched_play_time - now > std::chrono::milliseconds(5)) {
            if(!pc_spin(control))
                return false;
            std::this_thread::yield();
            now = std::chrono::system_clock::now();
        }
    } else {
        std::chrono::microseconds sched_diff = std::chrono::duration_cast<std::chrono::microseconds>(sched_play_time - now);
        if (sched_diff > std::chrono::milliseconds(5) && control->last_report_time + std::chrono::seconds(1) < now) {
            printf("warning: play time is too late %zu us\n", sched_diff.count());
            control->last_report_time = now;
        }
    }
    return true;
}

struct play_pipe {
    std::shared_ptr<translator> t;
    std::shared_ptr<player> p;
};

static void call_play_pipe(byte_buffer buff, time_point references_time, const play_pipe& pipe) {
    auto tr = pipe.t->translate(buff, references_time);
    if(tr != nullptr) {
        pipe.p->play(tr);
    }
    delete tr;
}

struct player_set {
    std::map<std::string, play_pipe> players;
};

static void player_play(player_set* ps, const char* tag, time_point references_time, byte_buffer data) {
    auto it = ps->players.find(tag); 
    if(it != ps->players.end()) {
        call_play_pipe(data, references_time, it->second);
    }
}

static bool add_player_topic(const std::string& topic, const play_config& cfg, type_id type, player_set* ps, const std::string& tag) {
    auto tf = find_translator_factory(type, cfg.point_type.c_str());
    if(tf == nullptr) {
        log_error("no translator for type %d", type);
        return false;
    }
    auto pf = find_player_factory(tf->get_descriptor().target_type);
    if(pf == nullptr) {
        log_error("no player for type %d", type);
        return false;
    }


    auto t = tf->create_translator("");
    if (t == nullptr) {
        log_error("failed to create translator for type %d", type);
        return false;
    }

    auto p = pf->create_player(topic.c_str());
    if (p == nullptr) {
        log_error("failed to create player for type %d", type);
        delete t;
        return false;
    }

    ps->players[tag] = {std::shared_ptr<translator>(t), std::shared_ptr<player>(p)};
    return true;
}

static bool setup_players(pkg2::pkg2_reader& reader, const play_config& cfg,  player_set* player) {
    auto err = reader.open(cfg.pkg2_file.c_str());
    if(err != pkg2::pkg2_error::success) {
        log_error("failed to open %s(%s)", cfg.pkg2_file.c_str(), pkg2::error_str(err));
        return false;
    }

    if(reader.items.empty()) {
        log_warning("no items in pkg2 file");
        return false;
    }
    for (auto& var : reader.items) {
        if (cfg.exclude.find(var->tag_name) != cfg.exclude.end())
            continue;
        if(var->type_id > pkg2::type_id_user_base) {
            continue;
        }

        if(is_custom_type(var->type_id))
            continue;
            
        std::string tag = var->tag_name;
        std::string topic = tag;
        if (cfg.rename.find(var->tag_name) != cfg.rename.end())
            topic = cfg.rename.at(std::string(var->tag_name));

        add_player_topic(topic, cfg, var->type_id, player, tag);
    }
    return true;
}

static int play_main(int argc, const char* const* argv) {
    pkg2::pkg2_reader reader;
    terminal t;
    auto parse_result = parse_play_config(argc, argv);
    if(!parse_result.ok()) {
        printf("%s\n", parse_result.error().c_str());
        return -1;
    }

    auto cfg = parse_result.value();
    if(cfg.pkg2_file.empty()) {
        return 0;
    }
    player_set players;
    if(!setup_players(reader, cfg, &players))
        return -1;
    terminal_init(&t);

    play_control control;

    pc_start(&control);
    for (const auto& [tag, type, time, data] : reader) {
        if (should_stop())
            break;
        if(type > pkg2::type_id_user_base)
            continue;
        if(!pc_control(&control, time, cfg.speed))
            break;
        
        time_point tp { std::chrono::microseconds(time) };
        player_play(&players, tag, tp, data);
        do_spin(0);
    }
    reader.close();
    return 0;
}


static void print_common_options(const char* current, const char* source) 
{
    if(current != nullptr && strncmp(current, "--", 2) != 0) {
        if(source == nullptr)
            printf("#filedir");
        return;
    }

    printf(" --speed --pkg2-file --point-type --rename --exclude ");

    if(source != nullptr) {
        return;
    }

    printf("http:// ");

    print_configable_values(config_range::app_play, true);
    for(auto files : std::filesystem::directory_iterator(".")) {
        if(files.path().extension() == ".pkg2") {
            printf(" %s", files.path().filename().c_str());
        }
        if(files.is_directory()) {
            printf(" %s/", files.path().filename().c_str());
        }
    }
}

static int play_bash_completion(int argc, const char* const * argv, const char* current) 
{
    const char* prev = complete_prev(argc, argv);
    if (prev == nullptr) {
        print_common_options(current, nullptr);
    }

    int left_words = 0;
    const char* source = nullptr;
    const char* print_content = nullptr;
    for(int i = 0; i < argc ; i++) {
        
        if(left_words > 0) {
            left_words--;
            continue;
        }

        if(strcmp(argv[i], "--point-type") == 0) {
            print_content = "XYZ XYZI XYZIRT XYZRGB ";
            left_words = 1;
        } else if(strcmp(argv[i], "--rename") == 0) {
            print_content = nullptr;
            left_words = 2;
        } else if(strcmp(argv[i], "--exclude") == 0) {
            print_content = nullptr;
            left_words = 1;
        } else if(strcmp(argv[i], "--speed") == 0) {
            print_content = nullptr;
            left_words = 1;
        } else if(source == nullptr && argv[i][0] != '-') {
            source = argv[i];
        } else {
            return 0;
        }
    } 

    if(left_words == 0) {
        print_common_options(current, source);
    } else if(print_content != nullptr) {
        printf("%s", print_content);
    }

    return 0;
}

REGISTER_SUBCOMMAND2(play, &play_main, &play_bash_completion);
