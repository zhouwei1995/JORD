
#include "subcommand.h"
#include <string>
#include <map>
#include <thread>
#include <signal.h>
#include <string.h>
#include <service/misc.h>

struct sub_command_call {
    sub_command func;
    complete_func complete;
};

static std::map<std::string, sub_command_call>& get_sub_commands() {
    static std::map<std::string, sub_command_call> sub_commands;
    return sub_commands;
}

void add_sub_command(const char *name, sub_command func, complete_func complete) {
    get_sub_commands()[name] = {func, complete};
}

sub_command get_sub_command(const char *name) {
    auto it = get_sub_commands().find(name);
    if(it == get_sub_commands().end())
        return nullptr;
    return it->second.func;
}

static int help_command(int , const char* const* argv) {
    auto m = get_sub_commands();
    for(auto& [name, func] : m) {
        printf("%s %s\n", argv[-1], name.c_str());
    }
    return 0;
}

REGISTER_SUBCOMMAND(help, help_command);

static int bash_complete(int argc, const char* const* argv) {
    auto m = get_sub_commands();
    // bash_complete executable ... [value] complete_current [value]

    if(argc < 3) {
        return 0;
    } 

    const char* current = argv[argc - 1];

    if(strcmp(argv[argc - 1], "complete_current") == 0) {
        current = nullptr;
        argc --;
    } else {
        if(strcmp(argv[argc - 2], "complete_current") != 0) {
            return 0;
        }
        argc -= 2;

        if(strcmp(argv[argc - 1], current) != 0) {
            return 0;
        } else {
            argc --;
        }
    }

    if(argc == 2) { // bash_complete ./pkg2 [something]^TAB
        // complete subcommand
        for(auto& [name, func] : m) {
            if(strcmp(name.c_str(), argv[0]) != 0)
                printf("%s ", name.c_str());
        }
        printf("\n");
        return 0;
    }

    if(argc < 3) {
        return 0;
    }
    
    auto it = m.find(argv[2]); // bash_complete ./pkg2 subcommand [something]^TAB
    if(it == m.end() || it->second.complete == nullptr) {
        return 0;
    }

    return it->second.complete(argc - 3, argv + 3, current);
}

REGISTER_SUBCOMMAND(bash_complete, &bash_complete);

static bool ctrlc_pressed = false;

void signal_handler(int sig) {
    ctrlc_pressed = true;
}

bool ctrlc_stop_callback(void*) {
    return ctrlc_pressed;
}

struct cleanup_callback {
    cleanup_function func;
    void* arg;
};

static cleanup_callback cleanup_funcs[10];
static size_t cleanup_func_count = 0;

void atexit_fn() {

}
void add_cleanup(cleanup_function f, void* arg) {
    if(cleanup_func_count >= sizeof(cleanup_funcs)/ sizeof(cleanup_callback)) {
        log_fatal("cleanup function full.");
    }
    cleanup_funcs[cleanup_func_count++] = cleanup_callback{f, arg};
}

int main(int argc, const char* const* argv) 
{
    if(argc < 2) {
        printf("usage: %s <subcommand> [args]\n", argv[0]);
        return 0;
    }

    log_init();

    auto func = get_sub_command(argv[1]);
    if(func == nullptr) {
        log_error("unknown subcommand: %s", argv[1]);
        return 0;
    }

    signal(SIGINT, &signal_handler);
    add_stop_source(&ctrlc_stop_callback, nullptr);

    int ret = func(argc - 1, argv + 1);

    for(int i = 0 ; i < cleanup_func_count; i++) {
        if(cleanup_funcs[i].func != nullptr) {
            cleanup_funcs->func(cleanup_funcs->arg);
        }
    }
    return ret;
}

struct stop_source_call {
    stop_source_function func;
    void* args;
};

static stop_source_call stop_sources[5];
static int stop_source_count = 0;

void add_stop_source(stop_source_function func, void* args) {
    if(stop_source_count >= 5) {
        log_fatal("too many stop sources");
        exit(1);
    }

    stop_sources[stop_source_count++] = {func, args};
}

bool should_stop() {
    for(int i = 0; i < stop_source_count; ++i) {
        if(stop_sources[i].func(stop_sources[i].args))
            return true;
    }
    return false;
}

struct spin_source_call {
    spin_source_function func;
    void* args;
};

static spin_source_call spin_sources[5];
static int spin_source_count = 0;

void add_spin_source(spin_source_function func, void* args) {
    if(spin_source_count >= 5) {
        log_fatal("too many spin sources");
        exit(1);
    }

    spin_sources[spin_source_count++] = {func, args};
}

void do_spin(int ms) {
    if(spin_source_count == 0) {
        std::this_thread::sleep_for(std::chrono::milliseconds(ms));
        return;
    }
    int ms_per_spin = ms / spin_source_count;
    for(int i = 0; i < spin_source_count; ++i) {
        spin_sources[i].func(ms_per_spin, spin_sources[i].args);
    }

}
