#ifndef _SUBCOMMAND_H_
#define _SUBCOMMAND_H_

using sub_command = int(*)(int, const char* const * argv);
using complete_func = int(*)(int, const char* const * argv, const char* current);

static inline const char* complete_prev(int argc, const char* const * argv) {
    if(argc == 0) {
        return nullptr;
    }
    return argv[argc - 1];
}

// TODO: use a better data structure.
// TODO: add subcommand help.
void add_sub_command(const char *name, sub_command func, complete_func complete = nullptr);

sub_command get_sub_command(const char *name);

#define REGISTER_SUBCOMMAND(name, subcommand)\
    struct subcommand_##name { \
        subcommand_##name() { \
            add_sub_command(#name, subcommand); \
        } \
    } subcommand_##name##_

#define REGISTER_SUBCOMMAND2(name, subcommand, complete)\
    struct subcommand_##name { \
        subcommand_##name() { \
            add_sub_command(#name, subcommand, complete); \
        } \
    } subcommand_##name##_
/*
all the pkg2 apps use the same structure:

int subcommand_entry(int argc, const char* const* argv) {

    subcommand_init(argc, argv);

    while(should_stop()) {
        subcommand_loop();
        do_spin(spin_time);
    }

    // cleanup() will called by main.
    return 0;
}

*/

/*
    if any stop source return true, the should_stop() will return true.
    if all stop source return false, the should_stop() will return false.
*/
using stop_source_function = bool(*)(void* args);
void add_stop_source(stop_source_function func, void* args);

bool should_stop();

/*
    do_spin() will call all spin source functions.
    the spin source function should return when the time is up.
*/
using spin_source_function = void (*)(int ms, void* args);
void add_spin_source(spin_source_function func, void* args);

void do_spin(int ms);

/*
    cleanup() will called by main.
*/
using cleanup_function = void(*)(void* arg);
void add_cleanup(cleanup_function func, void* arg);

#endif