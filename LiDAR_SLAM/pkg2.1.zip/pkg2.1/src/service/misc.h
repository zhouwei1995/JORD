#ifndef __MISC_H__
#define __MISC_H__

#include <string>
#include <utils/flags>

/*
    config is a map of string to string
    it is used to store the config key-value pairs
*/
void config_set(const char* key, const char* value);

/*
    config_get will return the value of the key
    if the key is not found, it will return the default value
*/
const char* config_get(const char* key, const char* default_value);

/*
    config_range is used to specify the range of the config 

    This range should be changed to be related to the configuration 
    content itself, and let the app choose the range it needs to use,
    rather than let the configuration content select the corresponding program.
    This is the structure that fits the bottom-up dependencies.
*/

enum class config_range {
    app_play,
    app_info,
    app_capture,
    app_split,
    app_export,
};

/*
    Configurables are key-value pairs that the application can accept.
    It consists of two types: those that accept a value, or that are just a flag bit.
    @param range: Range indicates when this configuration is useful.
    @param key: key represents the name of the configuration item, 
                and --key is considered to configure this configuration item on the command line
    @param posarg: posarg contains descriptions of the values of configuration items.
    @param desc: desc contains the description of the configuration item.
*/
void set_configable_value(flags<config_range> range, const char* key, const char* posarg, const char* desc);
void set_configable_flags(flags<config_range> range, const char* key, const char* desc);
bool is_configable_value(config_range range, const char* key);

/*
    print_configable_values will print all the configable values
    that are in the range. usually, it is used to print the help message.

    @param range: the range of the configable values to print
*/
void print_configable_values(config_range range, bool name_only = false);

/*
    config_check checks whether the next parameter is an acceptable configuration item.
    If so, he sets the corresponding value and returns the number of parameters consumed.
    If not, it returns 0.
    @param range: the range of the configable values to check
    @param argc: the number of parameters
    @param argv: the parameters

    @return: the number of parameters consumed，0 means no parameters consumed，< 0 means error
*/
int config_check(config_range range, int argc, const char* const * argv);

enum class log_level {
    verbose,
    debug,
    info,
    warning,
    error,
    fatal
};

/*
    log_init initializes the log system
    it should be called before any log output
*/
void log_init();

void xlog(log_level level, const char* fmt, ...);

#define log_verbose(fmt, ...) xlog(log_level::verbose, fmt, ##__VA_ARGS__)
#define log_debug(fmt, ...) xlog(log_level::debug, fmt, ##__VA_ARGS__)
#define log_info(fmt, ...) xlog(log_level::info, fmt, ##__VA_ARGS__)
#define log_warning(fmt, ...) xlog(log_level::warning, fmt, ##__VA_ARGS__)
#define log_error(fmt, ...) xlog(log_level::error, fmt, ##__VA_ARGS__)
#define log_fatal(fmt, ...) xlog(log_level::fatal, fmt, ##__VA_ARGS__)

#endif