#ifndef _V4L2_H_
#define _V4L2_H_
#include <functional>
#include <string>
#include <string_view>
#include <linux/videodev2.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <memory.h>
#include <functional>
#include <stdarg.h>

#include <utils/buffer>
#include <service/misc.h>

namespace jlurobot {
    
    struct v4l2_capture {
        int fd = -1;
        struct { unsigned char* start; size_t length; } buffers[8] {};

        bool open_video(const char *dev_name) {
            fd = open(dev_name, O_RDWR | O_NONBLOCK, 0);
            if (fd < 0) {
                log_error("open_video: open %s failed. %s", dev_name, strerror(errno));
            }
            return fd >= 0;
        }

        bool init_video() {
            struct v4l2_capability cap{};
            if (ioctl(fd, VIDIOC_QUERYCAP, &cap) < 0) {
                log_error("init_video: ioctl VIDIOC_QUERYCAP failed");
                return false;
            }
            if (!(cap.capabilities & V4L2_CAP_VIDEO_CAPTURE)) {
                log_error("init_video: %s is not a video capture device",
                              cap.driver);
                return false;
            }
            if (!(cap.capabilities & V4L2_CAP_STREAMING)) {
                log_error("init_video: %s does not support streaming i/o",
                              cap.driver);
                return false;
            }

            if(!check_mjpeg_support()){
                log_error("init_video: %s does not support mjpeg",
                              cap.driver);
                return false;
            }


            //get format
            struct v4l2_format fmt = {0};
            enum_frame_size(fmt.fmt.pix.width, fmt.fmt.pix.height);
            fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_MJPEG;
            if(ioctl(fd, VIDIOC_S_FMT, &fmt) < 0) {
                log_error("init_video: ioctl VIDIOC_S_FMT failed(%d)", errno);
                return false;
            }

            //setup frame rate
            struct v4l2_streamparm parm = {0};
            parm.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            parm.parm.capture.timeperframe.numerator = 1;
            if(!enum_frame_rate(parm.parm.capture.timeperframe.denominator))
                parm.parm.capture.timeperframe.denominator = 30;

            if(ioctl(fd, VIDIOC_S_PARM, &parm) < 0) {
                log_error("init_video: ioctl VIDIOC_S_PARM failed(%d)", errno);
                return false;
            }

            init_mmap_buffer();
            return true;
        }
        
        void init_mmap_buffer() {
            struct v4l2_requestbuffers req{};
            req.count = 4;
            req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            req.memory = V4L2_MEMORY_MMAP;
            if (ioctl(fd, VIDIOC_REQBUFS, &req) < 0) {
                log_error("init_mmap_buffer: ioctl VIDIOC_REQBUFS failed(%d)", errno);
            }

            struct v4l2_buffer buf{};
            for (int i = 0; i < req.count; i++) {
                memset(&buf, 0, sizeof(buf));
                buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
                buf.memory = V4L2_MEMORY_MMAP;
                buf.index = i;
                if (ioctl(fd, VIDIOC_QUERYBUF, &buf) < 0) {
                    log_error("init_mmap_buffer: ioctl VIDIOC_QUERYBUF failed(%d)", errno);
                    break;
                }
                buffers[i].length = buf.length;
                buffers[i].start = reinterpret_cast<unsigned char*>(mmap(nullptr, buf.length, PROT_READ | PROT_WRITE, MAP_SHARED, fd, buf.m.offset));
                if (buffers[i].start == MAP_FAILED) {
                    log_error("init_mmap_buffer: mmap failed(%d)", errno);
                    break;
                }
            }
        }

        //enum frame size
        bool enum_frame_size(unsigned int &width, unsigned int &height) const {
            struct v4l2_frmsizeenum fsize{};
            fsize.index = 0;
            fsize.pixel_format = V4L2_PIX_FMT_MJPEG;
            while (ioctl(fd, VIDIOC_ENUM_FRAMESIZES, &fsize) == 0) {
                if (fsize.type == V4L2_FRMSIZE_TYPE_DISCRETE) {
                    width = fsize.discrete.width;
                    height = fsize.discrete.height;
                    log_info("enum_frame_size: discrete: %d x %d", width, height);
                    return true;
                }
                fsize.index++;
            }
            return false;
        }

        //enum frame rate
        bool enum_frame_rate(unsigned int &fps) const {
            struct v4l2_frmivalenum fsize = { 0 };
            fsize.index = 0;
            fsize.pixel_format = V4L2_PIX_FMT_MJPEG;
            while (ioctl(fd, VIDIOC_ENUM_FRAMEINTERVALS, &fsize) == 0) {
                if (fsize.type == V4L2_FRMIVAL_TYPE_DISCRETE ) {
                    fps = fsize.discrete.denominator / fsize.discrete.numerator;
                    log_info("enum_frame_rate: discrete: %d", fps);
                    return true;
                }
                fsize.index++;
            }
            log_info("final enum_frame_rate: discrete: %d", fps);
            return false;
        }

        [[nodiscard]] bool check_mjpeg_support() const
        {
            struct v4l2_fmtdesc fmtdesc{};
            fmtdesc.index = 0;
            fmtdesc.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            while (ioctl(fd, VIDIOC_ENUM_FMT, &fmtdesc) == 0) {
                log_info("enum_format: %s, %d", fmtdesc.description, fmtdesc.pixelformat);
                if(fmtdesc.pixelformat == V4L2_PIX_FMT_MJPEG)
                    return true;
                fmtdesc.index++;
            }
            return false;
        }

        void start_capturing() const {
            for (int i = 0; i < 4; i++) {
                struct v4l2_buffer buf{};
                memset(&buf, 0, sizeof(buf));
                buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
                buf.memory = V4L2_MEMORY_MMAP;
                buf.index = i;
                if (ioctl(fd, VIDIOC_QBUF, &buf) < 0) {
                    log_error("start_capturing: ioctl VIDIOC_QBUF failed(%s)", strerror(errno));
                }
            }
            //set stream on
            enum v4l2_buf_type type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            if (ioctl(fd, VIDIOC_STREAMON, &type) < 0) {
                log_error("start_capturing: ioctl VIDIOC_STREAMON failed(%s)", strerror(errno));
            }
        }

        void stop_capturing() const {
            enum v4l2_buf_type type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            if (ioctl(fd, VIDIOC_STREAMOFF, &type) < 0) {
                log_error("stop_capturing: ioctl VIDIOC_STREAMOFF failed(%s)", strerror(errno));
            }
        }

        byte_buffer read_image() {
            struct v4l2_buffer buf{};
            memset(&buf, 0, sizeof(buf));
            buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            buf.memory = V4L2_MEMORY_MMAP;

            //select read
            if (ioctl(fd, VIDIOC_DQBUF, &buf) < 0) {
                log_error("read_image: ioctl VIDIOC_DQBUF failed(%s)", strerror(errno));
            }
            //TODO: avoid copy 
            byte_buffer image = byte_storage::create(buf.bytesused);
            memcpy(image.data(), buffers[buf.index].start, buf.bytesused);
            if (ioctl(fd, VIDIOC_QBUF, &buf) < 0) {
                log_error("read_image: ioctl VIDIOC_QBUF failed(%s)", strerror(errno));
            }
            return image;
        }

        void close_video() {
            if (fd > 0) {
                close(fd);
                fd = 0;
            }
        }
    };
}


#endif