#ifndef _SERIAL_HPP
#define _SERIAL_HPP

#if WIN32
#include <windows.h>
#include <stdio.h>
#else
#include <unistd.h>
#include <termios.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <fcntl.h>
#include <string>
#include <sys/types.h>
#include <sys/stat.h>

#include <ios>

namespace jlurobot
{
    enum serial_rate
    {
        R9600 = 9600,
        R19200 = 19200,
        R38400 = 38400,
        R57600 = 57600,
        R115200 = 115200,
        R230400 = 230400,
    };

    enum class serial_parity
    {
        NONE,
        EVEN,
        ODD,
    };

    enum class serial_stop_bits
    {
        ONE,
        TWO,
    };

    enum class serial_flow_control
    {
        NONE,
        HARDWARE,
        SOFTWARE,
    };

    class serial
    {
    public:
        serial() = default;
        serial(const char *port, serial_rate rate, serial_parity parity = serial_parity::NONE, serial_stop_bits stop_bits = serial_stop_bits::ONE, serial_flow_control flow_control = serial_flow_control::NONE);
        ~serial();

        bool open(std::ios_base::openmode mode = std::ios::in);
        void close();

        bool is_open();

        int read(char *buffer, size_t size);
        bool write(const char *buffer, size_t size);

        void flush();

        auto waitable_object() const
        {
#if WIN32
            return hComm;
#else
            return fd;
#endif
        }

    private:
        bool open_;
        std::string port;
        serial_rate rate;
        serial_parity parity;
        serial_stop_bits stop_bits;
        serial_flow_control flow_control;

#if WIN32
        HANDLE hComm;
#else
        int fd = -1;
#endif
    };

    class serial_exception : public std::exception
    {
    public:
        serial_exception(const char *message) : message(message) {}
        virtual const char *what() const throw() { return message; }

    private:
        const char *message;
    };

    inline serial::serial(const char *port, serial_rate rate, serial_parity parity, serial_stop_bits stop_bits, serial_flow_control flow_control)
    {
        printf("port %s", port); fflush(stdout);
        this->port = port;
        this->rate = rate;
        this->parity = parity;
        this->stop_bits = stop_bits;
        this->flow_control = flow_control;
    }

    inline serial::~serial()
    {
        close();
    }

    inline bool serial::open(std::ios::openmode mode)
    {
        mode &= std::ios::in | std::ios::out;
#ifdef WIN32
        HANDLE hComm;
        DCB dcb;
        COMMTIMEOUTS timeouts;

        switch (mode)
        {
        case std::ios::in:
            hComm = CreateFile(port.c_str(), GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;
        case std::ios::out:
            hComm = CreateFile(port.c_str(), GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;
        case std::ios::in | std::ios::out:
            hComm = CreateFile(port.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;
        }

        if (hComm == INVALID_HANDLE_VALUE)
        {
            throw serial_exception("Error opening serial port");
        }

        if (!GetCommState(hComm, &dcb))
        {
            CloseHandle(hComm);
            throw serial_exception("Error getting serial port state");
        }

        dcb.BaudRate = (DWORD)rate;
        dcb.fBinary = TRUE;
        dcb.fParity = TRUE;
        dcb.fOutxCtsFlow = FALSE;
        dcb.fOutxDsrFlow = FALSE;
        dcb.fDtrControl = DTR_CONTROL_DISABLE;
        dcb.fDsrSensitivity = FALSE;
        dcb.fTXContinueOnXoff = TRUE;
        dcb.fOutX = FALSE;
        dcb.fInX = FALSE;
        dcb.fErrorChar = FALSE;
        dcb.fNull = FALSE;
        dcb.fRtsControl = RTS_CONTROL_DISABLE;
        dcb.fAbortOnError = FALSE;
        dcb.ByteSize = (BYTE)stop_bits;
        dcb.Parity = (BYTE)parity;
        dcb.StopBits = (BYTE)stop_bits;

        if (!SetCommState(hComm, &dcb))
        {
            CloseHandle(hComm);
            throw serial_exception("Error setting serial port state");
        }

        timeouts.ReadIntervalTimeout = MAXDWORD;
        timeouts.ReadTotalTimeoutMultiplier = 0;
        timeouts.ReadTotalTimeoutConstant = 0;
        timeouts.WriteTotalTimeoutMultiplier = 0;
        timeouts.WriteTotalTimeoutConstant = 0;

        if (!SetCommTimeouts(hComm, &timeouts))
        {
            CloseHandle(hComm);
            throw serial_exception("Error setting serial port timeouts");
        }

        this->hComm = hComm;
#else
        
        switch (mode)
        {
        case std::ios::in:
            fd = ::open(port.c_str(), O_RDONLY | O_NOCTTY);
            break;
        case std::ios::out:
            fd = ::open(port.c_str(), O_WRONLY | O_NOCTTY);
            break;
        case std::ios::in | std::ios::out:
            fd = ::open(port.c_str(), O_RDWR | O_NOCTTY);
            break;
        }

        if (fd == -1)
        {
            throw serial_exception("Error opening serial port");
        }

        struct termios tty;
        memset(&tty, 0, sizeof(tty));

        if (tcgetattr(fd, &tty) != 0)
        {
            ::close(fd);
            throw serial_exception("Error getting serial port attributes");
        }

        tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
        tty.c_iflag &= ~IGNBRK;
        tty.c_lflag = 0;
        tty.c_oflag = 0;
        tty.c_cc[VMIN] = 10;
        tty.c_cc[VTIME] = 0;

        int r1 , r2;
        switch (rate)
        {
        case serial_rate::R9600:
            r1 = cfsetospeed(&tty, B9600);
            r2 = cfsetispeed(&tty, B9600);
            break;
        case serial_rate::R19200:
            r1 = cfsetospeed(&tty, B19200);
            r2 = cfsetispeed(&tty, B19200);
            break;
        case serial_rate::R38400:
            r1 = cfsetospeed(&tty, B38400);
            r2 = cfsetispeed(&tty, B38400);
            break;
        case serial_rate::R57600:
            r1 = cfsetospeed(&tty, B57600);
            r2 = cfsetispeed(&tty, B57600);
            break;
        case serial_rate::R115200:
            r1 = cfsetospeed(&tty, B115200);
            r2 = cfsetispeed(&tty, B115200);
            break;
        case serial_rate::R230400:
            r1 = cfsetospeed(&tty, B230400);
            r2 = cfsetispeed(&tty, B230400);
            break;
        default:
            throw serial_exception("Invalid serial port rate");
        }


        if(r1 == -1 || r2 == -1)
        {
            ::close(fd);
            throw serial_exception("Error setting serial port rate");
        }

        tty.c_cflag |= (CLOCAL | CREAD);
        tty.c_cflag &= ~(PARENB | PARODD);
        tty.c_cflag &= ~CSTOPB;
        tty.c_cflag &= ~CRTSCTS;

        switch (parity)
        {
        case serial_parity::NONE:
            tty.c_cflag &= ~PARENB;
            break;
        case serial_parity::EVEN:
            tty.c_cflag |= PARENB;
            tty.c_cflag &= ~PARODD;
            break;
        case serial_parity::ODD:
            tty.c_cflag |= PARENB;
            tty.c_cflag |= PARODD;
            break;
        }

        switch (stop_bits)
        {
        case serial_stop_bits::ONE:
            tty.c_cflag &= ~CSTOPB;
            break;
        case serial_stop_bits::TWO:
            tty.c_cflag |= CSTOPB;
            break;
        }

        switch (flow_control)
        {
        case serial_flow_control::NONE:
            tty.c_cflag &= ~CRTSCTS;
            break;
        case serial_flow_control::HARDWARE:
            tty.c_cflag |= CRTSCTS;
            break;
        case serial_flow_control::SOFTWARE:
            tty.c_iflag |= (IXON | IXOFF | IXANY);
            break;
        }

        fflush(stdout);
        if (tcsetattr(fd, TCSANOW, &tty) != 0)
        {
            ::close(fd);
            throw serial_exception("Error setting serial port attributes");
        }

        this->fd = fd;
#endif
        open_ = true;
        return true;
    }

    inline void serial::close()
    {
#ifdef WIN32
        if (hComm != INVALID_HANDLE_VALUE)
        {
            CloseHandle(hComm);
            hComm = INVALID_HANDLE_VALUE;
        }
#else

        if (fd != -1)
        {
            ::close(fd);
            fd = -1;
        }
#endif
        open_ = false;
    }

    inline bool serial::is_open()
    {
#ifdef WIN32
        return hComm != INVALID_HANDLE_VALUE;
#else
        return fd != -1;
#endif
    }

    inline int serial::read(char *buffer, size_t size)
    {
#ifdef WIN32
        DWORD dwRead;
        if (!ReadFile(hComm, buffer, (DWORD)size, &dwRead, NULL))
        {
            return false;
        }
        return dwRead;
#else
        return ::read(fd, buffer, size);
#endif
    }

    inline bool serial::write(const char *buffer, size_t size)
    {
        if (!is_open())
        {
            return false;
        }

#ifdef WIN32
        DWORD dwWritten;
        if (!WriteFile(hComm, buffer, (DWORD)size, &dwWritten, NULL))
        {
            return false;
        }
        return dwWritten == size;
#else
        int n = ::write(fd, buffer, size);
        return n == size;
#endif
    }

    inline void serial::flush()
    {
#ifdef WIN32
        PurgeComm(hComm, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR);
#else
        tcflush(fd, TCIOFLUSH);
#endif
    }
}

#endif
