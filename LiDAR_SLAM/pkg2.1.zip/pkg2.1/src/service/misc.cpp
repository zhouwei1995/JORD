#include "misc.h"

#include <stdarg.h>
#include <map>
#include <vector>
#include <string.h>
#include <chrono>

/*
 The function removes any trailing whitespace characters (spaces, newlines, and carriage returns)
 from the buffer by replacing them with null characters until the first non-whitespace 
 character is encountered. The function starts from the end of the buffer and works its 
 way backwards until it reaches the first non-whitespace character or the beginning of the buffer.

 @param buffer: the buffer to be trimmed
 @param size: the size of the buffer
*/
static void remove_empty_chars(char* buffer, size_t size)
{
    for(size_t i = size - 1; i > 0; i--) {
        if(buffer[i] == ' ' || buffer[i] == '\n' || buffer[i] == '\r') {
            buffer[i] = '\0';
        } else {
            break;
        }
    }
}

// system startup time
static std::chrono::system_clock::time_point system_startup_time;

// string formatter for time. kernel style
#define TIME_FORMAT "[%6zd.%03zd]"

void xlog(log_level level, const char* fmt, ...)
{
    /*
        if the content is larger than 1024 bytes, we will truncate it.
    */
    char log_content[1024];
    va_list args;
    va_start(args, fmt);
    vsnprintf(log_content, sizeof(log_content), fmt, args);
    va_end(args);

    auto now = std::chrono::system_clock::now();
    size_t seconds = std::chrono::duration_cast<std::chrono::seconds>(now - system_startup_time).count();
    size_t milliseconds = std::chrono::duration_cast<std::chrono::milliseconds>(now - system_startup_time).count() % 1000;

    /*
        we need to remove any trailing whitespace characters 
        so that the log will not be printed in multiple lines 
        if the log content ends with CR or LF

        if the log content is empty after removing the trailing
        whitespace characters, we will not print it
    */

    remove_empty_chars(log_content, strlen(log_content));

    if(log_content[0] == '\0') {
        return;
    }

    switch (level) {
    case log_level::verbose: // gray
        printf("\033[0;30m" TIME_FORMAT " V %s\033[0m\n", seconds, milliseconds, log_content);
        break;
    case log_level::debug: // green
        printf("\033[0;32m" TIME_FORMAT " D %s\033[0m\n", seconds, milliseconds, log_content);
        break;
    case log_level::info: // white
        printf("\033[0;37m" TIME_FORMAT " I %s\033[0m\n", seconds, milliseconds, log_content);
        break;
    case log_level::warning: // yellow
        printf("\033[0;33m" TIME_FORMAT " W %s\033[0m\n", seconds, milliseconds, log_content);
        break;
    case log_level::error: // red
        printf("\033[1;31m" TIME_FORMAT " E %s\033[0m\n", seconds, milliseconds, log_content);
        break;
    case log_level::fatal: // red, background white
        printf("\033[37;41m" TIME_FORMAT " F %s\033[0m\n", seconds, milliseconds, log_content);
        break;
    default:
        break;
    }
}

/*
    initialize the system startup time
*/
void log_init()
{
    system_startup_time = std::chrono::system_clock::now();
}


/*
    configures, which can be set by command line arguments.
    an argument can be a key-value pair, or just a key
    for flags, the value will be set to "true".


*/
using config_map = std::map<std::string, std::string>;

static config_map& get_config_map()
{
    static config_map config;
    return config;
}

void config_set(const char* key, const char* value)
{
    get_config_map()[key] = value;
}

const char* config_get(const char* key, const char* default_value)
{
    auto& config = get_config_map();
    auto it = config.find(key);
    if (it == config.end()) {
        /*
            if the key is not found, we will return the default value
        */
        log_debug("required config %s", key);
        return default_value;
    }
    return it->second.c_str();
}

/*
    key, posarg, desc should be static strings.
    they will be used in the whole life cycle of the app.
    so, we do not need to copy them.
*/
struct configable_value {
    flags<config_range> range;
    const char* key;
    const char* posarg;
    const char* desc;
};

using configable_value_list = std::map<std::string, configable_value>;

static configable_value_list& get_configable_value_list()
{
    static configable_value_list configable_values;
    return configable_values;
}


void set_configable_value(flags<config_range> range, const char* key, const char* posarg, const char* desc) {

    if(get_configable_value_list().find(key) != get_configable_value_list().end()) {
        /*
            if the configable value already exists, we will not add it again.
            apps should not add the same configable value twice.
            so, a fatal error will be logged.
        */
        log_fatal("configable value %s already exists", key);
        return;
    }

    // add the configable value
    get_configable_value_list()[key] = { range, key, posarg, desc };
}

bool is_configable_value(config_range range, const char* key) {
    auto& configable_values = get_configable_value_list();
    auto it = configable_values.find(key);
    if (it == configable_values.end()) {
        return false;
    }
    return (bool)(it->second.range & range);
}


void print_configable_values(config_range range, bool name_only) {
    auto& configable_values = get_configable_value_list();
    for(auto it = configable_values.begin(); it != configable_values.end(); it++) {
        if (it->second.range & range) {
            if (name_only) {
                printf("--%s ", it->second.key);
                continue;
            }
            if(it->second.posarg != nullptr)
                printf("\t--%s <%s>: %s\r\n", it->second.key, it->second.posarg, it->second.desc);
            else
                printf("\t--%s: %s\r\n", it->second.key, it->second.desc);
        }
    }
}

void set_configable_flags(flags<config_range> range, const char* key, const char* desc) {
    set_configable_value(range, key, nullptr, desc);
}

int config_check(config_range range, int argc, const char* const * argv) {
    if(argc == 0) { // no arguments
        return 0;
    }

    if(argv[0][0] != '-' || argv[0][1] != '-') { // not a configable value
        return 0;
    }

    auto& configable_values = get_configable_value_list();
    auto it = configable_values.find(&argv[0][2]);
    if (it == configable_values.end()) {
        // not a configable value
        return 0;
    }

    if(!(it->second.range & range)){
        // not in the range
        return 0;
    }

    if(it->second.posarg == nullptr) {
        // it is a flag, we will set value to true
        config_set(it->second.key, "true");
        return 1;
    }

    if(argc < 2) {
        // missing argument.
        log_fatal("config %s requires argument", it->second.key);
        return -1;
    }

    config_set(it->second.key, argv[1]);
    return 2;
}
