#ifndef _PKG2_H_
#define _PKG2_H_

#include <string>
#include <vector>
#include <tuple>
#include <map>
#include <cassert>
#include <cstring>
#include <iostream>
#include <sstream>
#include <optional>
#include "file.h"
#include <utils/buffer>

namespace pkg2::details
{
    inline bool check_for_write(const file* f) {
        return f != nullptr && f->ops != nullptr && f->ops->write != nullptr;
    }

    inline auto write_uleb(file* f, uint64_t value)
    {
        uint64_t v = value;
        do
        {
            uint8_t b = v & 0x7f;
            v >>= 7;
            if (v != 0)
            {
                b |= 0x80;
            }
            if(1 != write(f, &b, 1))
                return false;
        } while (v != 0);
        return true;
    }

    inline ssize_t read_uleb(file* is)
    {
        unsigned char buffer[10];
        size_t count = 0;
        do
        {
            if(read(is, buffer + count, 1) != 1)
                return -1;
            count++;
        } while ((buffer[count - 1] & 0x80) != 0);
        ssize_t result = 0;
        for (size_t i = 0; i < count; ++i)
        {
            result |= (ssize_t)(buffer[i] & 0x7F) << (7 * i);
        }
        return result;
    }

    template<typename base_type>
    inline auto write_value(file* os, base_type value)
    {
        return sizeof(base_type) == write(os, (const char *)&value, sizeof(base_type));
    }

    template <typename value_type>
    inline bool read_value(file* os, value_type *value)
    {
        return read(os, (char *)value, sizeof(value_type)) == sizeof(value_type);
    }

    template <typename buff_type>
    inline auto write_buff(file* os, const buff_type &str)
    {
        size_t len = str.size() * sizeof(typename buff_type::value_type);
        return write_uleb(os, len)&&
            write(os, reinterpret_cast<const char*>(str.data()), len) == len;
    }

    template <typename buff_type>
    inline bool read_buff(file* is, buff_type &buff)
    {
        size_t len = read_uleb(is);
        if(len < 0) {
            buff.clear();
            return false;
        }
        assert(len % sizeof(typename buff_type::value_type) == 0);
        buff.resize(len / sizeof(typename buff_type::value_type));
        if (read(is, reinterpret_cast<char*>(buff.data()), len) != len)
            return false;
        return true;
    }

    enum class pkg2_error {
        success,
        io_error,
        misuse,
        open_failed,
        invalid_header,
        signature_mismatch,
        version_not_supported,
        invalid_format,
    };

    constexpr uint32_t block_type_constant = 1,
        block_type_data = 2,
        block_type_info = 3,
        block_type_unknown = 0;

    struct pkg2_header {
        uint32_t signature = 1347110745;
        uint32_t version = 0x00010000;
        size_t info_block_offset = 0;
    };

    struct pkg2_constant_item {
        uint32_t flag = 0;
        uint32_t type_id = 0;
        char tag_name[4] = { 0 }; // maybe more than 4 bytes
    };

    struct pkg2_constant_block {
        uint32_t block_type = block_type_constant; // 1 for constant block
        uint32_t counts = 0;
        uint64_t next_offset = 0;
        char buff[1008];
    };

    static_assert(sizeof(pkg2_constant_block) == 1024);

    struct pkg2_info_block {
        size_t min_time = 0, max_time = 0;
        std::vector<size_t> tag_messages;
    };

    inline bool write_pkg2_header(file* os)
    {
        pkg2_header header;
        header.signature = 1347110745;
        header.version = 0x00010000;
        header.info_block_offset = 0;
        return write_value(os, header);
    }

    struct pkg2_writter {
        pkg2_constant_block cb;
        size_t cb_offset = 0;
        size_t cb_buf_offset = 0;
        file* fp = nullptr;
        std::map<std::string, uint64_t> tag_map;
        pkg2_info_block ib;
        pkg2_writter() = default;
        explicit pkg2_writter(const char* filename)
        {
            auto f = open_url(filename, "wb");
            if(f != nullptr) {
                if(!write_pkg2_header(f))
                    return;
                memset(&cb, 0, sizeof(cb));
                cb_offset = tell(f);
                if(!write_value(f, cb))
                    return;
            }
            fp = f;
        }

        ~pkg2_writter() {
            if(check_for_write(fp)) {
                write_info_tail();
                close();
            }
        }

        pkg2_writter(const pkg2_writter&) = delete;
        pkg2_writter(pkg2_writter&&) = delete;
        const pkg2_writter& operator=(const pkg2_writter&) = delete;
        const pkg2_writter& operator=(pkg2_writter&&) = delete;
        template<typename... Args>

        pkg2_error open(const char* url) {
            if(::is_open(fp)) {
                return pkg2_error::misuse;
            }
            auto f = open_url(url, "wb");
            if(f != nullptr) {
                if(!write_pkg2_header(f))
                    return pkg2_error::io_error;
                memset(&cb, 0, sizeof(cb));
                cb_offset = tell(f);
                if(!write_value(f, cb))
                    return pkg2_error::io_error;
            }
            fp = f;
            return pkg2_error::success;
        }

        [[nodiscard]] bool is_open() const {
            return ::is_open(fp);
        }

        auto write_data(const char* tag, uint32_t type_id, size_t time, const void* data, size_t length) {
            auto key = find_tag(tag, type_id);
            uint32_t block_type = 2;
            bool result = write_value(fp, block_type)
                && write_uleb(fp, key)
                && write_value(fp, time)
                && write_uleb(fp, length)
                && (write(fp, data, length) == length);

            if(result) {
                ib.tag_messages[key]++;
                if(ib.max_time == 0)
                    ib.max_time = time;
                else
                    ib.max_time = std::max(ib.max_time, time);

                if(ib.min_time == 0)
                    ib.min_time = time;
                else
                    ib.min_time = std::min(ib.min_time, time);
            } else {
                return pkg2_error::io_error;
            }
            return pkg2_error::success;
        }

        void close() {
            if(::is_open(fp)) {
                write_info_tail();
                ::close(fp);
            }
            fp = nullptr;
            ib.max_time = ib.min_time = 0;
            ib.tag_messages.clear();
            tag_map.clear();
            cb_offset = cb_buf_offset = 0;
        }

    private:
        uint64_t find_tag(const char* tag, unsigned int type_id) {
            auto it = tag_map.find(tag);
            if (it == tag_map.end()) {
                return write_tag(tag, type_id);
            }
            return it->second;
        }

        uint64_t write_tag(const char* tag, unsigned int type_id) {
            auto key = tag_map.size();
            tag_map[tag] = key;
            
            size_t size_need = strlen(tag) + 1 + 8;
            if (cb_buf_offset + size_need > sizeof(cb.buff)) {
                cb.next_offset = tell(fp);
                seek(fp, (int64_t)cb_offset, SEEK_SET);
                if(write_value(fp, cb))
                    return -1;
                seek(fp, (int64_t)cb.next_offset, SEEK_SET);
                cb_offset = tell(fp);
                cb.counts = 1;
                cb.next_offset = 0;
                auto item = (pkg2_constant_item*)cb.buff;
                item->flag = 0;
                item->type_id = type_id;
                strcpy(item->tag_name, tag);
                cb_buf_offset = sizeof(pkg2_constant_item) + strlen(tag) + 1 - 4;
                if(!write_value(fp, cb))
                    return -1;
            } else {
                auto item = (pkg2_constant_item*)(cb.buff + cb_buf_offset);
                item->flag = 0;
                item->type_id = type_id;
                strcpy(item->tag_name, tag);
                cb.counts++;
                cb_buf_offset += sizeof(pkg2_constant_item) + strlen(tag) + 1 - 4;
                auto cur = (size_t)tell(fp);
                seek(fp, (int64_t)cb_offset, SEEK_SET);
                if(!write_value(fp, cb))
                    return -1;
                seek(fp, cur, SEEK_SET);
            }
            ib.tag_messages.push_back(0);
            return key;
        }

        bool write_info_tail() {
            pkg2_header h;
            h.info_block_offset = tell(fp);

            file* fmem = open_url(":memory:", "wb");
            bool result = write_uleb(fmem, ib.min_time) &&
                    write_uleb(fmem, ib.max_time) &&
                    write_buff(fmem, ib.tag_messages);

            if(!result) return false;

            void* ptr = get_memory_ptr(fmem);
            size_t size = tell(fmem);

            result = write_value(fp, block_type_info) &&
                    write_buff(fp, std::string_view((const char*)ptr, size));

            ::close(fmem);

            if(!result) {
                seek(fp, h.info_block_offset);
                return false;
            }

            seek(fp, 0);
            result =  write_value(fp, h);
            seek(fp, 0, SEEK_END);
            return result;
        }
    };

    using pkg2_value_storage = std::tuple<const char*, uint32_t , size_t, byte_buffer>;
    using pkg2_value_type = std::tuple<const char*, uint32_t , size_t, byte_buffer>;

    template<typename reader_type>
    struct pkg2_block_iterator {
        using value_type = pkg2_value_type;
        using difference_type = std::ptrdiff_t;
        using pointer = const value_type *;
        using reference = const value_type &;
        using iterator_category = std::input_iterator_tag;

        reader_type& reader;
        value_type value;
        bool is_end = false;

        explicit pkg2_block_iterator(reader_type& reader, bool end = false) : reader(reader), is_end(end) {
            if (!end) {
                this->operator++();
            }
        }

        pkg2_block_iterator& operator++() {
            if(reader.more()) {
                value = reader.next();
                if(std::get<0>(value) == nullptr) {
                    is_end = true;
                }
            } else
                is_end = true;
                
            return *this;
        }

        bool operator==(const pkg2_block_iterator& other) const {
            return is_end == other.is_end;
        }

        bool operator!=(const pkg2_block_iterator& other) const {
            return !operator==(other);
        }

        value_type operator*() const {
            return value;
        }

        value_type operator->() const {
            return value;
        }
    };


    struct pkg2_reader  {
        file* fp = nullptr;
        std::vector<pkg2_constant_item*> items;
        std::string cb_data;

        std::optional<pkg2_info_block> info;

        using value_type = pkg2_value_storage;
        pkg2_reader() = default;
        explicit pkg2_reader(const char* url) {
            open(url);
        }

        pkg2_reader(const pkg2_reader&) = delete;
        pkg2_reader& operator=(const pkg2_reader&) = delete;
        pkg2_reader(pkg2_reader&&) = delete;
        pkg2_reader& operator=(pkg2_reader&&) = delete;

        ~pkg2_reader() {
            close();
        }

        [[nodiscard]] bool is_open() const {
            return ::is_open(fp);
        }

        pkg2_error open(const char* url) {
            if(is_open())
                return pkg2_error::misuse;
            fp = open_url(url, "rb");
            if(is_open())
                return read_pkg2();
            return pkg2_error::open_failed;
        }

        pkg2_error read_pkg2() {
            auto err = read_pkg2_header();
            if(err != pkg2_error::success)
                return err;

            pkg2_constant_block cb;
            if(!read_value(fp, &cb))
                return pkg2_error::io_error;
            
            unsigned int available_data = 0;
            for(size_t i = 0; i < cb.counts; i++) {
                available_data += strlen(cb.buff + available_data + 8) + 9;
            }
            cb_data.append(cb.buff, available_data);
            available_data = 0;
            for(size_t i = 0; i < cb.counts; i++) {
                auto item = (pkg2_constant_item*)(cb_data.data() + available_data);
                available_data += strlen(cb.buff + available_data + 8) + 9;
                items.push_back(item);
            }
                
            return pkg2_error::success;
        }

        pkg2_error read_pkg2_header()
        {
            pkg2_header header;
            if(!read_value(fp, &header))
                return pkg2_error::io_error;
            if(header.signature != 1347110745)
                return pkg2_error::signature_mismatch;
            if(header.version != 0x00010000)
                return pkg2_error::version_not_supported;
            if(header.info_block_offset != 0 && seekable(fp)) {
                auto cur = tell(fp);
                seek(fp, header.info_block_offset);
                pkg2_info_block info_block;
                auto block_type = block_type_unknown;
                if(!read_value(fp, &block_type))
                    return pkg2_error::io_error;
                if(block_type != block_type_info)
                    return pkg2_error::invalid_format;
                std::string buff;
                if(!read_buff(fp, buff))
                    return pkg2_error::io_error;
                seek(fp, cur);

                file* iss = open_memory(buff.data(), buff.size());
                info_block.min_time = read_uleb(iss);
                info_block.max_time = read_uleb(iss);
                if(info_block.min_time < 0 || info_block.max_time < 0)
                    return pkg2_error::invalid_format;
                if(!read_buff(iss, info_block.tag_messages)) {
                    ::close(iss);
                    return pkg2_error::io_error;
                }
                info = info_block;
                ::close(iss);
            }
            return pkg2_error::success;
        }

        value_type next() {
            uint32_t block_type = 0;
            if(!read_value(fp, &block_type)){
                if(eof(fp))
                    return {nullptr, 0, 0, {}};
            }
            if(block_type == block_type_constant) {
                auto length = read_uleb(fp);
                if(length < 0) {
                    return {nullptr, 0, 0, {}};
                }
                if(seekable(fp)) {
                    seek(fp, (int64_t)length, SEEK_CUR);
                } else {
                    char buff[1024];
                    while(length > 0) {
                        auto read_count = std::min(length, (ssize_t)1024);
                        if(!read(fp, buff, read_count))
                            return {nullptr, 0, 0, {}};
                        length -= read_count;
                    }
                }
                return next();
            } else if(block_type == block_type_info) {
                return {nullptr, 0, 0, {}};
            } else if(block_type == block_type_data) {
                auto key = read_uleb(fp);
                if(key < 0) {
                    return {nullptr, 0, 0, {}};
                }
                size_t time = 0;
                read_value(fp, &time);
                byte_buffer buff;
                read_buff(fp, buff);

                return std::make_tuple(items[key]->tag_name, items[key]->type_id, time,
                                       std::move(buff));
            } else {
                return {nullptr, 0, 0, {}};
            }
        }

        [[nodiscard]] bool more() const {
            return !eof(fp);
        }

        pkg2_block_iterator<pkg2_reader> begin() {
            return pkg2_block_iterator<pkg2_reader>(*this);
        }   

        pkg2_block_iterator<pkg2_reader> end() {
            return pkg2_block_iterator<pkg2_reader>(*this, true);
        }

        void close() {
            if(is_open())
                ::close(fp);
            fp = nullptr;
        }
    };
}


namespace pkg2 {

    using pkg2_reader = pkg2::details::pkg2_reader;
    using pkg2_writter = pkg2::details::pkg2_writter;

    using pkg2_error = details::pkg2_error;

    constexpr uint32_t type_id_VLP16 = 1;
    constexpr uint32_t type_id_HDL32 = 2;
    constexpr uint32_t type_id_RT3000 = 3;
    constexpr uint32_t type_id_NPOS220S = 4;
    constexpr uint32_t type_id_LIVOX_HAP = 5;
    constexpr uint32_t type_id_JPEG = 6;
    
    constexpr uint32_t type_id_user_base = 100;
    constexpr uint32_t type_id_LIVOX_HAP_LOG = type_id_user_base + 1;

    constexpr inline const char* error_str(details::pkg2_error error) {
        switch (error) {
            case details::pkg2_error::success:
                return "success";
            case details::pkg2_error::io_error:
                return "io error";
            case details::pkg2_error::signature_mismatch:
                return "signature mismatch";
            case details::pkg2_error::version_not_supported:
                return "version not supported";
            case details::pkg2_error::invalid_format:
                return "invalid format";
            case details::pkg2_error::misuse:
                return "misuse";
            case details::pkg2_error::open_failed:
                return "open failed";
            default:
                return "unknown error";
        }
    }
}


#endif