#include "file.h"

#include <arpa/inet.h>
#include <atomic>
#include <cassert>
#include <condition_variable>
#include <cstring>
#include <future>
#include <malloc.h>
#include <mutex>
#include <netdb.h>
#include <netinet/in.h>
#include <queue>
#include <stdexcept>
#include <string>
#include <sys/socket.h>
#include <unistd.h>

#include <service/misc.h>

#define N_1 // select network 1

struct fetch_queue {
    std::queue<std::string> public_queue, private_queue;
    std::mutex              mutex;
    volatile bool           finish_write      = false;
    size_t                  total_buffer_size = 0;
    size_t                  buff_size_limit   = 100 * 1024 * 1024; // 100MB
    std::condition_variable cond_full, cond_empty;
    size_t                  current_str_off   = 0;
    size_t                  content_size_left = 0;
    std::thread             fetch_thread;
};

static bool fq_copy(fetch_queue* fq) {
    if (fq->private_queue.empty()) {
        std::unique_lock<std::mutex> lk(fq->mutex);
        fq->cond_full.wait(lk, [&] {
            return !fq->public_queue.empty() || fq->finish_write;
        });
        if (fq->public_queue.empty())
            return false;
        fq->private_queue.swap(fq->public_queue);
        fq->total_buffer_size = 0;
        fq->cond_empty.notify_one();
    }
    return true;
}

static int fq_read_private(fetch_queue* fq, char* buff, size_t buff_size) {
    if (!fq_copy(fq))
        return 0;
    size_t read_size = 0ul;
    while (read_size < buff_size && !fq->private_queue.empty()) {
        auto& str       = fq->private_queue.front();
        auto  copy_size = std::min(str.size() - fq->current_str_off, buff_size - read_size);
        memcpy(buff + read_size, str.data() + fq->current_str_off, copy_size);
        read_size += copy_size;
        fq->current_str_off += copy_size;
        if (fq->current_str_off == str.size()) {
            fq->private_queue.pop();
            fq->current_str_off = 0;
        }
    }
    if (read_size != buff_size)
        return fq_read_private(fq, buff + read_size, buff_size - read_size) + (int)read_size;
    return (int)read_size;
}

static int fq_write_public(fetch_queue* fq, const char* buff, size_t buff_size) {
    std::unique_lock<std::mutex> lk(fq->mutex);
    fq->cond_empty.wait(lk, [&] {
        return fq->total_buffer_size < fq->buff_size_limit || fq->finish_write;
    });
    fq->public_queue.emplace(buff, buff_size);
    fq->total_buffer_size += buff_size;
    fq->cond_full.notify_one();
    return (int)buff_size;
}

static void fq_fetch_thread(fetch_queue* fq, int fd) {
    char buff[1024 * 1024];
    // recv timeout
    struct timeval tv {
        1, 0
    };
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof tv);

    while (!fq->finish_write && fq->content_size_left > 0) {
        auto fetch_len = std::min(fq->content_size_left, sizeof(buff));
        auto read_size = recv(fd, buff, fetch_len, MSG_NOSIGNAL);
        if (read_size <= 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)
                continue;
            break;
        }
        fq_write_public(fq, buff, read_size);
    }
    fq->finish_write = true;
}

static bool fq_eof(fetch_queue* fq) {
    if (fq->finish_write) {
        fq_copy(fq);
        return fq->private_queue.empty();
    }
    return false;
}

static bool fq_init(fetch_queue* fq, int fd) {
    fq->fetch_thread = std::thread(fq_fetch_thread, fq, fd);
    return true;
}

static bool fq_destroy(fetch_queue* fq) {
    fq->finish_write = true;
    fq->cond_full.notify_all();
    fq->cond_empty.notify_all();
    if (fq->fetch_thread.joinable())
        fq->fetch_thread.join();
    return true;
}

struct network_file_ev {
    fetch_queue fq;
    int         fd = -1;
};

static int network_file_read(file* file, void* data, size_t size);

static void network_file_close(file* file);
static bool network_file_eof(file* f);

static file_operations network_file_ops = {
    &network_file_read,
    nullptr,
    nullptr,
    nullptr,
    &network_file_close,
    &network_file_eof,
};

static int network_file_read(file* file, void* data, size_t size) {
    if (file == nullptr || file->ev_data == nullptr || data == nullptr || size == 0)
        return -1;
    if (file->ops != &network_file_ops)
        return -1;
    auto ev = (struct network_file_ev*)file->ev_data;
    return fq_read_private(&ev->fq, (char*)data, size);
}

static void network_file_close(file* file) {
    if (file == nullptr || file->ev_data == nullptr)
        return;
    if (file->ops != &network_file_ops)
        return;
    auto ev = (struct network_file_ev*)file->ev_data;
    close(ev->fd);
    fq_destroy(&ev->fq);
    delete ev;
    file->ev_data = nullptr;
}

static bool network_file_eof(file* f) {
    if (f == nullptr || f->ev_data == nullptr)
        return true;
    if (f->ops != &network_file_ops)
        return true;
    auto ev = (struct network_file_ev*)f->ev_data;
    return fq_eof(&ev->fq);
}

static bool network_init(network_file_ev* ev, int fd, size_t total_len, void* buff, size_t wd) {
    ev->fd = fd;
    ev->fq.private_queue.emplace((char*)buff, wd);
    ev->fq.content_size_left = total_len - wd;
    return fq_init(&ev->fq, fd);
}

//protocol ,hostname, path

static int  network2_file_read(file* file, void* data, size_t size);
static void network2_file_close(file* file);
static bool network2_file_eof(file* f);

static file_operations network2_file_ops = {
    &network2_file_read, nullptr, nullptr, nullptr, &network2_file_close, &network2_file_eof,
};

struct network2_ev {
    int         fd;
    std::string buff;
    size_t      buff_offset    = 0;
    size_t      content_length = 0;
};

static int network2_file_read(file* file, void* data, size_t size) {
    if (file == nullptr || file->ev_data == nullptr || data == nullptr || size == 0)
        return -1;
    if (file->ops != &network2_file_ops)
        return -1;
    auto ev = (struct network2_ev*)file->ev_data;

    size_t len = 0;
    if (ev->buff_offset < ev->buff.size()) {
        auto copy_len = std::min(size, ev->buff.size() - ev->buff_offset);
        memcpy(data, ev->buff.data() + ev->buff_offset, copy_len);
        ev->buff_offset += copy_len;
        len += copy_len;
    }
    if (len < size) {
        auto read_len = recv(ev->fd, (char*)data + len, size - len, MSG_WAITALL);
        if (read_len > 0)
            len += read_len;
        else
            return (int)read_len;
    }
    ev->content_length -= len;
    return (int)len;
}

static void network2_file_close(file* file) {
    if (file == nullptr || file->ev_data == nullptr)
        return;
    if (file->ops != &network2_file_ops)
        return;
    auto ev = (struct network2_ev*)file->ev_data;
    close(ev->fd);
    delete ev;
    file->ev_data = nullptr;
    delete file;
}

static bool network2_file_eof(file* f) {
    if (f == nullptr || f->ev_data == nullptr)
        return true;
    if (f->ops != &network2_file_ops)
        return true;
    auto ev = (struct network2_ev*)f->ev_data;
    return ev->content_length == 0;
}

file* network2_create(int sock_fd, const char* rest_buffer, size_t len, size_t content_length) {
    auto file          = new struct file;
    file->ops          = &network2_file_ops;
    file->ev_data      = new struct network2_ev;
    auto ev            = (struct network2_ev*)file->ev_data;
    ev->fd             = sock_fd;
    ev->buff           = std::string(rest_buffer, len);
    ev->content_length = content_length;

    int recvbuf = 50 * 1024 * 1024;
    setsockopt(sock_fd, SOL_SOCKET, SO_RCVBUF, (const char*)&recvbuf, sizeof(recvbuf));

    return file;
}

std::tuple<std::string, std::string, std::string> split_url(const std::string& url) {
    auto pos = url.find("://");
    if (pos == std::string::npos)
        return std::make_tuple("", "", "");
    auto protocol = url.substr(0, pos);
    auto rest     = url.substr(pos + 3);
    pos           = rest.find("/");
    if (pos == std::string::npos)
        return std::make_tuple(protocol, rest, "");
    auto hostname = rest.substr(0, pos);
    auto path     = rest.substr(pos);
    return std::make_tuple(protocol, hostname, path);
}

std::pair<uint32_t, uint16_t> get_ipaddress_and_port(const std::string& host) {
    /*
     * only work for ipv4 address, something like 192.168.x.xxx:xxxx
     */
    auto c = host.find(':');
    if (c != std::string::npos)
        return std::make_pair(inet_addr(host.substr(0, c).c_str()), (uint16_t)std::stoi(host.substr(c + 1)));
    return std::make_pair(inet_addr(host.c_str()), 80);
}

int create_socket_and_connect(uint32_t ipaddress, uint16_t port) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0)
        return -1;
    struct sockaddr_in addr {};
    addr.sin_family      = AF_INET;
    addr.sin_port        = htons(port);
    addr.sin_addr.s_addr = ipaddress;
    if (connect(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

int send_request(const char* url) {
    auto [protocol, hostname, path] = split_url(url);
    if (protocol.empty() || hostname.empty() || path.empty()) {
        log_error("\033[91m[network] invalid url: (%s, %s, %s)\033[0m\n", protocol.c_str(), hostname.c_str(), path.c_str());
        return -1;
    }
    auto [ip, port] = get_ipaddress_and_port(hostname);
    if (ip == 0 || port == 0) {
        log_error("\033[91m[network] invalid ipaddress or port: (%s, %d)\033[0m\n", inet_ntoa(*(struct in_addr*)&ip), port);
        return -1;
    }
    auto sock = create_socket_and_connect(ip, port);
    if (sock < 0) {
        log_error("\033[91m[network] connect failed: (%s, %d)\033[0m\n", inet_ntoa(*(struct in_addr*)&ip), port);
        return -1;
    }
    std::string request = "GET " + path + " HTTP/1.1\r\nHost: " + hostname + "\r\nAuthorization: Basic amx1cm9ib3Q6emhpbWFrYWltZW4=\r\n\r\n";
    if (send(sock, request.c_str(), request.size(), 0) <= 0) {
        log_error("\033[91m[network] send request failed.\n\033[0m");
        close(sock);
        return -1;
    }
    return sock;
}

struct line_buffer {
    int    current_lineno = 0;
    char   buffer[1024]   = {0};
    size_t buff_avaliable = 0;

    void reset() {
        current_lineno = 0;
        memset(buffer, 0, sizeof(buffer));
    }

    bool fetch(int fd) {
        auto len = recv(fd, buffer + buff_avaliable, sizeof(buffer) - buff_avaliable, 0);
        if (len <= 0) {
            log_error("\033[91m[network]  line buffer recv failed.\033[0m\n");
            return false;
        }
        std::string s(buffer, len + buff_avaliable);
        buff_avaliable += len;
        return true;
    }

    const char* get_line_after(const char* line) {
        if (line == nullptr) {
            return strstr(buffer, "\r\n") == nullptr ? nullptr : buffer;
        }
        const char* line_end = strstr(line, "\r\n");
        if (line_end == nullptr)
            return nullptr;
        return line_end + 2;
    }

    const char* previous_line = nullptr;

    const char* get_line(int fd) {
        auto line = get_line_after(previous_line);
        if (line == nullptr) {
            if (previous_line != nullptr) {
                std::move(previous_line, (const char*)buffer + buff_avaliable, buffer);
                buff_avaliable -= previous_line - buffer;
                previous_line = nullptr;
            }
            if (!fetch(fd))
                return nullptr;
            line = get_line_after(previous_line);
        }
        if (line == nullptr)
            return nullptr;
        previous_line = line;
        current_lineno++;
        return line;
    }
};

static size_t parse_response(int sock, char* cached_data, size_t* wlength) {
    line_buffer lb;
    size_t      content_length = 0;
    while (true) {
        auto line = lb.get_line(sock);
        if (line == nullptr)
            return 0;
        if (lb.current_lineno == 1) {
            int response_code = 0;
            if (sscanf(line, "HTTP/%*d.%*d %d", &response_code) != 1 || response_code > 299) {
                log_error("\033[33m[network2] response code: %d\n\033[0m", response_code);
                log_error("\033[33m[network2] response: %s\033[0m\n", line);
                return 0;
            }
        } else if (strncmp(line, "Content-Length: ", 16) == 0) {
            content_length = std::stoull(line + 16);
        } else if (strncmp(line, "\r\n", 2) == 0) {
            break;
        }
    }
    assert(strncmp(lb.previous_line, "\r\n", 2) == 0);
    *wlength = lb.buff_avaliable - (lb.previous_line - lb.buffer) - 2;
    std::copy(lb.previous_line + 2, (const char*)lb.buffer + lb.buff_avaliable, cached_data);
    return content_length;
}

file* network_file_open(const char* url) {
    int sock = send_request(url);
    if (sock < 0)
        return nullptr;
    char   temp_buff[1500];
    size_t wlength;
    auto   content_length = parse_response(sock, temp_buff, &wlength);
    if (content_length == 0) {
        close(sock);
        return nullptr;
    }
#ifdef N_1
    auto nf = new file();
    nf->ops = &network_file_ops;
    auto n  = new network_file_ev;
    network_init(n, sock, content_length, temp_buff, wlength);
    nf->ev_data = n;
#else
    auto nf = network2_create(sock, temp_buff, wlength, content_length);
#endif
    return nf;
}

static int     fs_file_read(file* file, void* data, size_t size);
static int     fs_file_write(file* file, const void* data, size_t size);
static int     fs_file_seek(file* file, int64_t offset, int whence);
static int64_t fs_file_tell(file* file);
static void    fs_file_close(file* file);
static bool    fs_file_eof(file* file);

static file_operations fs_file_ops = {
    fs_file_read,
    fs_file_write,
    fs_file_seek,
    fs_file_tell,
    fs_file_close,
    fs_file_eof,
};

#define check_fs_file(f)                                                                                                                                                                               \
    if (f->ops != &fs_file_ops)                                                                                                                                                                        \
        return -1;

static int fs_file_read(file* file, void* data, size_t size) {
    check_fs_file(file);
    auto* fp = (FILE*)file->ev_data;
    return (int)fread(data, 1, size, fp);
}

static int fs_file_write(file* file, const void* data, size_t size) {
    check_fs_file(file);
    auto* fp = (FILE*)file->ev_data;
    return (int)fwrite(data, 1, size, fp);
}

static int fs_file_seek(file* file, int64_t offset, int whence) {
    check_fs_file(file);
    auto* fp = (FILE*)file->ev_data;
    return fseeko64(fp, offset, whence);
}

static int64_t fs_file_tell(file* file) {
    check_fs_file(file);
    auto* fp = (FILE*)file->ev_data;
    return ftello64(fp);
}

static void fs_file_close(file* file) {
    if (file->ops != &fs_file_ops)
        return;
    auto* fp = (FILE*)file->ev_data;
    fclose(fp);
    delete file;
}

static bool fs_file_eof(file* file) {
    check_fs_file(file);
    auto* fp = (FILE*)file->ev_data;
    return feof(fp);
}

static file* fs_file_open(const char* path, const char* mode) {
    auto* fp = fopen(path, mode);
    if (fp == nullptr) {
        return nullptr;
    }
    auto* fs    = new file();
    fs->ops     = &fs_file_ops;
    fs->ev_data = fp;
    return fs;
}

struct mem_file_ev {
    size_t       size   = 0;
    size_t       offset = 0;
    mem_file_ev* next   = nullptr;
    char         data[0];
};

static int     mem_file_write(file* file, const void* data, size_t size);
static int64_t mem_file_tell(file* file);
static void    mem_file_close(file* file);

static file_operations mem_file_ops = {
    nullptr,
    mem_file_write,
    nullptr,
    mem_file_tell,
    mem_file_close,
    nullptr
};

inline bool is_mem_file(file* f) {
    return f->ops == &mem_file_ops;
}

static auto alloc_page_for(const void* data, size_t size) {
    size_t alloc_size = std::max(size, (size_t)4096);

    auto* page   = (mem_file_ev*)malloc(sizeof(mem_file_ev) + alloc_size);
    page->size   = alloc_size;
    page->offset = 0;
    page->next   = nullptr;
    if (data != nullptr) {
        std::copy((const char*)data, (const char*)data + size, page->data);
        page->offset = size;
    }
    return page;
}

static int mem_file_write(file* file, const void* data, size_t size) {
    if (!is_mem_file(file))
        return -1;
    auto* mfe = (mem_file_ev*)file->ev_data;
    if (mfe == nullptr) {
        file->ev_data = alloc_page_for(data, size);
        return (int)size;
    } else {
        auto* last = mfe;
        while (last->next != nullptr)
            last = last->next;

        if (last->size - last->offset >= size) {
            std::copy((const char*)data, (const char*)data + size, last->data + last->offset);
            last->offset += size;
        } else {
            std::copy((const char*)data, (const char*)data + last->size - last->offset, last->data + last->offset);
            size_t left  = size - (last->size - last->offset);
            last->offset = last->size;
            last->next   = alloc_page_for((const char*)data + (size - left), left);
        }
    }
    return (int)size;
}

static int64_t mem_file_tell(file* file) {
    if (!is_mem_file(file))
        return -1;
    auto* mfe = (mem_file_ev*)file->ev_data;
    if (mfe == nullptr)
        return 0;
    size_t off = 0;
    while (mfe != nullptr) {
        off += mfe->offset;
        mfe = mfe->next;
    }
    return (int64_t)off;
}

static void mem_file_close(file* file) {
    if (!is_mem_file(file))
        return;
    auto* mfe = (mem_file_ev*)file->ev_data;
    while (mfe != nullptr) {
        auto* next = mfe->next;
        free(mfe);
        mfe = next;
    }
    delete file;
}

static file* mem_file_open(const char* url) {
    auto* mf    = new file();
    mf->ops     = &mem_file_ops;
    mf->ev_data = nullptr;
    return mf;
}

file* open_url(const char* path, const char* mode) {
    if (strcmp(path, ":memory:") == 0) {
        return mem_file_open(path);
    }

    const char* s = strstr(path, "://");
    if (s == nullptr)
        return fs_file_open(path, mode);
    if (mode == nullptr || strcmp(mode, "rb") != 0)
        return nullptr;
    return network_file_open(path);
}

void* get_memory_ptr(file* file) {
    if (!is_mem_file(file))
        return nullptr;

    //combine all pages into one
    auto* mfe = (mem_file_ev*)file->ev_data;
    if (mfe == nullptr)
        return nullptr;
    if (mfe->next == nullptr) {
        // one page only
        return mfe->data;
    }

    size_t size = 0;
    while (mfe != nullptr) {
        size += mfe->offset;
        mfe = mfe->next;
    }
    auto new_page = alloc_page_for(nullptr, size);
    mfe           = (mem_file_ev*)file->ev_data;
    while (mfe != nullptr) {
        std::copy(mfe->data, mfe->data + mfe->offset, new_page->data + new_page->offset);
        new_page->offset += mfe->offset;
        auto next = mfe->next;
        free(mfe);
        mfe = next;
    }
    file->ev_data = new_page;
    return new_page->data;
}

void close(struct file* file) {
    file->ops->close(file);
}

struct memory_buff {
    const char* input_buff = nullptr;
    size_t      input_size = 0;
    size_t      offset     = 0;
};

static int     memory_read(file* file, void* data, size_t size);
static void    memory_close(file* file);
static int64_t memory_tell(file* file);
static int     memory_seek(file* file, int64_t offset, int whence);
static bool    memory_eof(file* file);

static file_operations memory_ops = {.read = memory_read, .write = nullptr, .seek = memory_seek, .tell = memory_tell, .close = memory_close, .eof = memory_eof};

static int memory_read(file* file, void* data, size_t size) {
    auto buff = (memory_buff*)file->ev_data;
    if (buff->offset + size > buff->input_size) {
        size = buff->input_size - buff->offset;
    }
    memcpy(data, buff->input_buff + buff->offset, size);
    buff->offset += size;
    return size;
}

static void memory_close(file* file) {
    auto buff = (memory_buff*)file->ev_data;
    delete buff;
    delete file;
}

static int64_t memory_tell(file* file) {
    auto buff = (memory_buff*)file->ev_data;
    return buff->offset;
}

static int memory_seek(file* file, int64_t offset, int whence) {
    auto buff       = (memory_buff*)file->ev_data;
    auto new_offset = buff->offset;
    switch (whence) {
    case SEEK_SET: new_offset = offset; break;
    case SEEK_CUR: new_offset += offset; break;
    case SEEK_END: new_offset = buff->input_size + offset; break;
    default: return -1;
    }
    if (new_offset < 0 || new_offset > buff->input_size) {
        return -1;
    }
    buff->offset = new_offset;
    return 0;
}

static bool memory_eof(file* file) {
    auto buff = (memory_buff*)file->ev_data;
    return buff->offset >= buff->input_size;
}

file* open_memory(const char* buff, size_t size) {
    auto file      = new struct file;
    auto mb        = new memory_buff;
    mb->input_buff = buff;
    mb->input_size = size;
    mb->offset     = 0;
    file->ops      = &memory_ops;
    file->ev_data  = mb;
    return file;
}
