//
// Created by jlurobot on 9/9/22.
//

#ifndef PKG2_FILE_H
#define PKG2_FILE_H
#include <istream>
#include <assert.h>
struct file;

struct file_operations {
    int (* read)(file* file, void* data, size_t size) = nullptr;
    int (* write)(file* file, const void* data, size_t size) = nullptr;
    int (* seek)(file* file, int64_t offset, int whence) = nullptr;
    int64_t (* tell)(file* file) = nullptr;
    void (* close)(file* file) = nullptr;
    bool (*eof)(file* f) = nullptr;
};

struct file {
    file_operations* ops = nullptr;
    void* ev_data = nullptr;
};

/*
 * @brief open a file
 * @param filename the file name
 * @param mode the mode to open the file
 *      if str begin with http:// or https://, it will open an url file
 *      if str equals to :memory:, it will open a memory file
 *
 */

struct file* open_url(const char *str, const char* mode = "");

void* get_memory_ptr(file* file);

void close(struct file* file);

file* open_memory(const char* buff, size_t size);

inline int read(struct file* file, void* data, size_t size) {
    assert(file != nullptr && file->ops != nullptr && file->ops->read != nullptr);
    return file->ops->read(file, data, size);
}

inline int write(struct file* file, const void* data, size_t size) {
    assert(file != nullptr && file->ops != nullptr && file->ops->write != nullptr);
    return file->ops->write(file, data, size);
}

inline int seek(struct file* file, int64_t offset, int whence = SEEK_SET) {
    assert(file != nullptr && file->ops != nullptr && file->ops->seek != nullptr);
    return file->ops->seek(file, offset, whence);
}

inline int64_t tell(struct file* file) {
    assert(file != nullptr && file->ops != nullptr && file->ops->tell != nullptr);
    return file->ops->tell(file);
}

inline bool seekable(struct file* file) {
    return file!= nullptr && file->ops != nullptr && file->ops->seek != nullptr;
}

inline bool is_open(file* f) {
    return f != nullptr && f->ops != nullptr;
}

inline bool eof(struct file* f) {
    return f == nullptr || f->ops == nullptr || f->ops->eof == nullptr || f->ops->eof(f);
}


#endif //PKG2_FILE_H
