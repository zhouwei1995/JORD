
# pkg2 completion                                 -*- shell-script -*-

__pkg2()
{
    local cur prev words cword
    _init_completion || return

    #if exists the executable file, use it
    if ! [[ -x $1 ]]; then
        return
    fi
    local complete_words=$($1 bash_complete ${COMP_WORDS[@]} complete_current $cur | sed -e 's/\\n/\n/g')
    if [[ $complete_words == "#filedir" ]]; then
        _filedir
        return
    fi
    COMPREPLY=( $( compgen -W "$complete_words" -- "$cur" ) )
} &&
complete -F __pkg2 ./pkg2

