./pkg2 capture livox-hap 192.168.1.2,SP,/livox_hap v4l2 /dev/video0,SP,/camera1 v4l2 /dev/video2,SP,/camera2 velodyne16 2102,SP,/u2102 npos220s /dev/ttyUSB0,SP,/npos220s

./pkg2 capture livox-hap 192.168.1.2,SP,/livox_hap v4l2 /dev/video0,SP,/camera1 v4l2 /dev/video2,SP,/camera2 velodyne16 2102,SP,/u2102 npos220s /dev/ttyUSB0,SP,/npos220s livox-hap-log 192.168.1.2,SP,/livox_hap_log



./pkg2 capture livox-hap 192.168.1.2,SP,/livox_hap v4l2 /dev/video0,SP,/camera1 v4l2 /dev/video2,SP,/camera2 velodyne16 2102,SP,/u2102 npos220s /dev/ttyUSB0,SP,/npos220s livox-hap-log 192.168.1.2,SP,/livox_hap_log --print-npos220s
